// Configuration Firebase - Solaire Nettoyage V3.0
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, onValue, set, get } from 'firebase/database';

// Configuration Firebase
const firebaseConfig = {
  apiKey: "AIzaSyCAH_1ql-9ckn_egrj1AjteNpAs2Vo5KNY",
  authDomain: "gestion-flotte-et-stoks.firebaseapp.com",
  databaseURL: "https://gestion-flotte-et-stoks-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "gestion-flotte-et-stoks",
  storageBucket: "gestion-flotte-et-stoks.firebasestorage.app",
  messagingSenderId: "824916805616",
  appId: "1:824916805616:web:8afc8c80285cb3fda43f35"
};

// Initialiser Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

// Fonctions de mise à jour Firebase - EXISTANTES (ne changent pas)
export const updateArticles = async (data) => {
  try {
    if (Array.isArray(data)) {
      for (const item of data) {
        if (item.id) {
          await set(ref(database, 'articles/' + item.id), item);
        }
      }
    }
  } catch (error) {
    console.error('Erreur sync articles:', error);
  }
};

export const updateEquipements = async (data) => {
  try {
    if (Array.isArray(data)) {
      for (const item of data) {
        if (item.id) {
          await set(ref(database, 'equipements/' + item.id), item);
        }
      }
    }
  } catch (error) {
    console.error('Erreur sync équipements:', error);
  }
};

export const updateDefauts = async (data) => {
  try {
    if (Array.isArray(data)) {
      for (const item of data) {
        if (item.id) {
          await set(ref(database, 'defauts/' + item.id), item);
        }
      }
    }
  } catch (error) {
    console.error('Erreur sync défauts:', error);
  }
};

export const updateInterventions = async (data) => {
  try {
    if (Array.isArray(data)) {
      for (const item of data) {
        if (item.id) {
          await set(ref(database, 'interventions/' + item.id), item);
        }
      }
    }
  } catch (error) {
    console.error('Erreur sync interventions:', error);
  }
};

export const updateMouvements = async (data) => {
  try {
    if (Array.isArray(data)) {
      for (const item of data) {
        if (item.id) {
          await set(ref(database, 'mouvements/' + item.id), item);
        }
      }
    }
  } catch (error) {
    console.error('Erreur sync mouvements:', error);
  }
};

// NOUVELLE FONCTION - Synchronisation des accessoires
export const updateAccessoires = async (data) => {
  try {
    // Les accessoires sont stockés par équipement
    await set(ref(database, 'accessoires'), data);
    console.log('✅ Accessoires synchronisés');
  } catch (error) {
    console.error('Erreur sync accessoires:', error);
  }
};

export { database, ref, onValue, set, get };
