// APP PRINCIPAL - Solaire Nettoyage V3.9
// Gestion centralisée de l'état et navigation + Authentification
import React, { useState, useRef, useEffect } from 'react';
import { database, ref, onValue, set, get, updateArticles, updateEquipements, updateDefauts, updateInterventions, updateMouvements, updateAccessoires, auth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from './firebase.config';

// Import du module Login
import Login from './Login';

// Import des modules
import Accueil from './modules/Accueil';
import Articles from './modules/Articles';
import Inventaire from './modules/Inventaire';
import Stock from './modules/Stock';
import Equipements from './modules/Equipements';
import Interventions from './modules/Interventions';
import FicheMateriel from './modules/FicheMateriel';
import Maintenance from './modules/Maintenance';
import Alertes from './modules/Alertes';
import FacturesDocuments from './modules/FacturesDocuments';
import Statistiques from './modules/Statistiques';

export default function SolaireNettoyageFlotte() {
  // ÉTATS AUTHENTIFICATION
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState('');

  // ÉTAT PRINCIPAL - IDENTIQUE À LA V2.2
  const [ongletActif, setOngletActif] = useState('accueil');
  const [equipementSelectionne, setEquipementSelectionne] = useState(1);
  const canvasRef = useRef(null);
  const videoRef = useRef(null);
  const scanningRef = useRef(false);
  const jsQRRef = useRef(null);
  const videoIntervention = useRef(null);
  const canvasIntervention = useRef(null);
  const scanningIntervention = useRef(false);
  const fileInputRef = useRef(null);
  
  // États pour le module Alertes - Ces états sont maintenant gérés localement dans le module Alertes
  // const [filtreAlerteSeverite, setFiltreAlerteSeverite] = useState('');
  // const [filtreAlerteFournisseur, setFiltreAlerteFournisseur] = useState('');
  // const [filtreAlerteDepot, setFiltreAlerteDepot] = useState('');
  // const [triAlertes, setTriAlertes] = useState('severite');
  // const [articleEnDetailsAlerte, setArticleEnDetailsAlerte] = useState(null);
  // const [articleEnTransfertAlerte, setArticleEnTransfertAlerte] = useState(null);
  // const [articleEnHistoriqueAlerte, setArticleEnHistoriqueAlerte] = useState(null);
  // const [transfertRapideData, setTransfertRapideData] = useState({ depotSource: 'Atelier', depotDestination: 'Porteur 26 T', quantite: '' });
  
  const operateurs = ['Axel', 'Jérôme', 'Sébastien', 'Joffrey', 'Fabien', 'Angelo'];
  const depots = ['Atelier', 'Porteur 26 T', 'Porteur 32 T', 'Semi Remorque'];
  
  const [operateurActif, setOperateurActif] = useState(
    localStorage.getItem('operateurActif') || null
  );

  // DONNÉES INITIALES
  const [articles, setArticles] = useState([
    { id: 1, code: 'BAC5X5', description: 'Barre pour clavette en acier 5x5', fournisseur: 'LE BON ROULEMENT', prixUnitaire: 5.05, stockParDepot: { 'Atelier': 3, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 2, equipementsAffectes: [] },
    { id: 2, code: 'BAC8X7', description: 'Barre pour clavette en acier 8x7', fournisseur: 'LE BON ROULEMENT', prixUnitaire: 9.07, stockParDepot: { 'Atelier': 3, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 2, equipementsAffectes: [] },
    { id: 3, code: '388518', description: 'Bague support pont avant', fournisseur: 'RURAL MASTER', prixUnitaire: 12.41, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [] },
    { id: 4, code: '605670', description: 'Washer 48.0x4.0 thrust', fournisseur: 'RURAL MASTER', prixUnitaire: 5.68, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [] },
    { id: 5, code: '606540', description: 'Nut M10x1.508 hex', fournisseur: 'RURAL MASTER', prixUnitaire: 2.06, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [] },
    { id: 6, code: '605669', description: 'Seal O ring 2.62x55.0', fournisseur: 'RURAL MASTER', prixUnitaire: 2.76, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [] },
    { id: 7, code: '606858', description: 'Grease nipple B M6', fournisseur: 'RURAL MASTER', prixUnitaire: 2.20, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [] },
    { id: 8, code: '605668', description: 'Dowel bush pillow block', fournisseur: 'RURAL MASTER', prixUnitaire: 3.59, stockParDepot: { 'Atelier': 2, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [] },
    { id: 9, code: '606739', description: 'Bolt M10x1.50x356.6P hex head', fournisseur: 'RURAL MASTER', prixUnitaire: 2.62, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [] },
    { id: 10, code: '388497', description: 'Support pont avant', fournisseur: 'RURAL MASTER', prixUnitaire: 53.02, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [] },
    { id: 11, code: '764617', description: 'Chambre Ã  air 20x108 STI', fournisseur: 'RURAL MASTER', prixUnitaire: 44.30, stockParDepot: { 'Atelier': 3, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 2, equipementsAffectes: [] },
    { id: 12, code: 'HIFSO 8055', description: 'Filtre Ã  huile', fournisseur: 'V6 AUTOPRO', prixUnitaire: 40.80, stockParDepot: { 'Atelier': 2, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [1] },
    { id: 13, code: 'HIFSN 916020', description: 'Filtre Ã  gasoil séparateur d\'eau', fournisseur: 'V6 AUTOPRO', prixUnitaire: 34.12, stockParDepot: { 'Atelier': 2, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [1] },
    { id: 14, code: 'WY119802-55710', description: 'Séparateur d\'eau', fournisseur: 'CLAAS LAGARRIGUE', prixUnitaire: 15.05, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [6] },
    { id: 15, code: 'WY123907-55810', description: 'Filtre combustible', fournisseur: 'CLAAS LAGARRIGUE', prixUnitaire: 36.88, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [6] },
    { id: 16, code: 'WY129150-35170', description: 'Filtre Ã  huile', fournisseur: 'CLAAS LAGARRIGUE', prixUnitaire: 14.17, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [6] },
    { id: 17, code: '44524021', description: 'Filtre TRANS (TTR/TRH 9800) PONT AV', fournisseur: 'CLAAS LAGARRIGUE', prixUnitaire: 31.65, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [6] },
    { id: 18, code: '44524020', description: 'Filtre HYDRAU PRESSION', fournisseur: 'CLAAS LAGARRIGUE', prixUnitaire: 62.71, stockParDepot: { 'Atelier': 1, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 1, equipementsAffectes: [6] },
    { id: 19, code: 'BF16', description: 'Huile BF16 (20L)', fournisseur: 'SARL QUIERS', prixUnitaire: 5.07, stockParDepot: { 'Atelier': 40, 'Porteur 26 T': 0, 'Porteur 32 T': 0, 'Semi Remorque': 0 }, stockMin: 10, equipementsAffectes: [6] },
  ]);

  const [mouvementsStock, setMouvementsStock] = useState([
    { id: 1, articleId: 1, type: 'entree', quantite: 3, date: '2025-09-29', raison: 'Facture 233440 - LE BON ROULEMENT', coutTotal: 15.15, depot: 'Atelier' },
    { id: 2, articleId: 2, type: 'entree', quantite: 3, date: '2025-09-29', raison: 'Facture 233440 - LE BON ROULEMENT', coutTotal: 27.20, depot: 'Atelier' },
  ]);
  const [factures, setFactures] = useState([]);


  const [equipements, setEquipements] = useState([
    { id: 1, immat: 'GT-316-FG', type: 'Camion Citerne', marque: 'IVECO', modele: 'S-WAY', annee: 2023, km: 0, heures: 0, carburant: 'Diesel', vin: 'ZCFCE62RU00C519482', ptac: 26000, poids: 13190, proprietaire: 'SOLAIRE NETTOYAGE', valeurAchat: 0, valeurActuelle: 133500, typeFinancement: 'Location', coutMensuel: 2104, dateDebut: '2023-12-22', dateFin: '2029-12-22', assurance: 80.10, dateContracteTechnique: '2024-12-22', notes: 'Contrat de location A1M75094 001' },
    { id: 2, immat: 'DX-780-QN', type: 'Tracteur Routier', marque: 'IVECO', modele: 'STRALIS 560', annee: 2015, km: 293992, heures: 0, carburant: 'Diesel', vin: 'WJMS2NWH60C329019', ptac: 26000, poids: 8518, proprietaire: 'SOLAIRE NETTOYAGE', valeurAchat: 45000, valeurActuelle: 42000, typeFinancement: 'Achat', coutMensuel: 0, dateDebut: '2020-09-18', dateFin: '', assurance: 85.00, dateContracteTechnique: '2020-10-17', notes: 'STRALIS 560 "¢ Type 6x2' },
    { id: 3, immat: 'CZ-022-DP', type: 'Semi-Remorque', marque: 'NICOLAS', modele: 'B3207C', annee: 2002, km: 0, heures: 0, carburant: 'N/A', vin: 'VF9B3207C02058032', ptac: 34000, poids: 12550, proprietaire: 'SOLAIRE NETTOYAGE', valeurAchat: 15000, valeurActuelle: 14000, typeFinancement: 'Achat', coutMensuel: 0, dateDebut: '2018-06-29', dateFin: '', assurance: 120.00, dateContracteTechnique: '2019-08-22', notes: 'Semi-Remorque NICOLAS B3207C' },
    { id: 4, immat: 'G3-415-BW', type: 'Micro-tracteur', marque: 'FARMTRAC', modele: 'F26VHE14HMNDWF', annee: 2022, km: 0, heures: 0, carburant: 'Essence', vin: 'M6SH09RLANF585383', ptac: 1800, poids: 1057, proprietaire: 'SOLAIRE NETTOYAGE', valeurAchat: 12325.00, valeurActuelle: 12325.00, typeFinancement: 'Achat', coutMensuel: 0, dateDebut: '2022-08-25', dateFin: '', assurance: 0, dateContracteTechnique: '2022-08-25', notes: 'TRACTEUR FARMTRAC - Immatriculation 25/08/2022' },
    { id: 5, immat: 'GM-843-SW', type: 'Micro-tracteur', marque: 'FARMTRAC', modele: 'F26VHE14HMNDWL', annee: 2023, km: 0, heures: 0, carburant: 'Essence', vin: 'M6SH09RLDNF610727', ptac: 1800, poids: 1057, proprietaire: 'SOLAIRE NETTOYAGE', valeurAchat: 12325.00, valeurActuelle: 12325.00, typeFinancement: 'Achat', coutMensuel: 0, dateDebut: '2023-03-16', dateFin: '', assurance: 0, dateContracteTechnique: '2023-03-16', notes: 'TRACTEUR FARMTRAC - Immatriculation 16/03/2023' },
    { id: 6, immat: 'DZ-609-JX', type: 'Tracteur', marque: 'ANTONIO CARRARO', modele: 'ERGIT-ST2088965A2', annee: 2016, km: 0, heures: 3170, carburant: 'Agricole', vin: 'T20ACATA000P471', ptac: 4800, poids: 2650, proprietaire: 'SOLAIRE NETTOYAGE', valeurAchat: 42000.00, valeurActuelle: 42000.00, typeFinancement: 'Achat', coutMensuel: 0, dateDebut: '2025-05-27', dateFin: '', assurance: 0, dateContracteTechnique: '2025-05-27', notes: 'TRACTEUR ANTONIO CARRARO MACH 4 CHENILLES' },
  ]);

  const [nouvelEquipement, setNouvelEquipement] = useState({
    immat: '',
    type: '',
    marque: '',
    modele: '',
    annee: '',
    km: 0,
    heures: 0,
    carburant: '',
    vin: '',
    ptac: 0,
    poids: 0,
    proprietaire: 'SOLAIRE NETTOYAGE',
    valeurAchat: 0,
    valeurActuelle: 0,
    typeFinancement: '',
    coutMensuel: 0,
    dateDebut: new Date().toISOString().split('T')[0],
    dateFin: '',
    assurance: 0,
    dateContracteTechnique: '',
    notes: ''
  });

  const [afficherFormulaireEquipement, setAfficherFormulaireEquipement] = useState(false);
  const [equipementEnEdition, setEquipementEnEdition] = useState(null);
  const [modeEdition, setModeEdition] = useState(false);

  const [accessoiresEquipement, setAccessoiresEquipement] = useState({
    1: [  // GT-316-FG - Camion avec carrosserie (structurel)
      { id: 1, nom: 'Carrosserie TEPEMATIC 26T', valeur: 51583, dateAjout: '2023-11-15', description: 'Plateau fixe porte matériel TP', actif: false },
      { id: 2, nom: 'Feux latéraux LED 24V (x4)', valeur: 65.16, dateAjout: '2023-11-22', description: 'Feu latéral orange Ã  LED 24V', actif: false },
    ],
    6: [  // DZ-609-JX - Tracteur avec brosse (opérationnel)
      { id: 9, nom: 'SunBrush mobil TrackFlex 3.0', valeur: 64277.00, dateAjout: '2025-05-14', description: 'SunBrush mobil TrackFlex 3.0 5,5m brush', actif: true },
    ]
  });

  const [interventions, setInterventions] = useState([]);

  const [nouvelleIntervention, setNouvelleIntervention] = useState({ 
    equipementId: '', 
    type: '', 
    date: new Date().toISOString().split('T')[0], 
    km: '', 
    heures: '', 
    description: '', 
    travauxEffectues: '',
    articlesPrevu: [], 
    depotPrelevement: 'Atelier' 
  });
  
  const [nouvelArticleIntervention, setNouvelArticleIntervention] = useState({ 
    articleId: '', 
    quantite: '' 
  });
  
  const [afficherArticlesEquipement, setAfficherArticlesEquipement] = useState(false);
  const [afficherScannerIntervention, setAfficherScannerIntervention] = useState(false);
  const [scanResultatIntervention, setScanResultatIntervention] = useState(null);
  const [quantiteScanIntervention, setQuantiteScanIntervention] = useState('');
  
  // NOUVEAUX ÉTATS POUR ÉDITION/SUPPRESSION INTERVENTIONS
  const [interventionEnEdition, setInterventionEnEdition] = useState(null);
  const [modeEditionIntervention, setModeEditionIntervention] = useState(false);
  const [articlePreselectionne, setArticlePreselectionne] = useState(null);

  const [defauts, setDefauts] = useState([
    { id: 1, equipementId: 6, accessoireId: 9, type: 'Fuite', severite: 'critique', description: 'Fuite hydraulique sur raccord du bras', localisation: 'Raccord du bras', dateConstatation: '2025-11-08', operateur: 'Jérôme', remarques: 'Liquid jaune observable', photos: [], statut: 'a_traiter', interventionLieeId: null, dateArchivage: null }
  ]);

  const [nouveauDefaut, setNouveauDefaut] = useState({
    equipementId: '', accessoireId: '', type: 'Fuite', severite: 'moyen', description: '', localisation: '', 
    dateConstatation: new Date().toISOString().split('T')[0], operateur: '', remarques: '', photosNoms: []
  });

  // FONCTIONS AUTHENTIFICATION
  const handleLogin = async (email, password) => {
    try {
      setAuthError('');
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
      console.error('Erreur connexion:', error);
      if (error.code === 'auth/invalid-credential' || error.code === 'auth/wrong-password' || error.code === 'auth/user-not-found') {
        setAuthError('Email ou mot de passe incorrect');
      } else if (error.code === 'auth/too-many-requests') {
        setAuthError('Trop de tentatives. Réessayez plus tard.');
      } else {
        setAuthError('Erreur de connexion. Vérifiez votre connexion internet.');
      }
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setUser(null);
    } catch (error) {
      console.error('Erreur déconnexion:', error);
    }
  };

  // EFFET - Vérifier l'état d'authentification au démarrage
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // EFFET - Initialiser l'opérateur dans nouveauDefaut avec operateurActif
  useEffect(() => {
    if (operateurActif && nouveauDefaut.operateur === '') {
      setNouveauDefaut(prev => ({ ...prev, operateur: operateurActif }));
    }
  }, [operateurActif]);

  const [defautSelectionne, setDefautSelectionne] = useState(null);
  const [photosSelectionnees, setPhotosSelectionnees] = useState([]);
  
  // NOUVEAUX ÉTATS POUR ÉDITION/SUPPRESSION DÉFAUTS
  const [defautEnEdition, setDefautEnEdition] = useState(null);
  const [modeEditionDefaut, setModeEditionDefaut] = useState(false);

  // États pour le module Articles
  const [afficherFormulaireArticle, setAfficherFormulaireArticle] = useState(false);
  const [articleFormEnEdition, setArticleFormEnEdition] = useState(null);
  const [modeEditionArticle, setModeEditionArticle] = useState(false);
  const [nouvelArticleForm, setNouvelArticleForm] = useState({
    code: '',
    description: '',
    fournisseur: '',
    prixUnitaire: 0,
    stockMin: 0
  });

  // États pour le module Inventaire
  const [panierCommande, setPanierCommande] = useState([]);
  const [articleEnEdition, setArticleEnEdition] = useState(null);

  // États pour le module Stock
  const [afficherScannerQR, setAfficherScannerQR] = useState(false);
  const [videoStream, setVideoStream] = useState(null);
  const [scanResultat, setScanResultat] = useState(null);
  const [actionScan, setActionScan] = useState(null);
  const [formScanEntree, setFormScanEntree] = useState({ 
    quantite: '', 
    prixUnitaire: '', 
    raison: '', 
    date: new Date().toISOString().split('T')[0], 
    depot: 'Atelier' 
  });
  const [formScanSortie, setFormScanSortie] = useState({ 
    quantite: '', 
    raison: '', 
    date: new Date().toISOString().split('T')[0], 
    depot: 'Atelier' 
  });
  const [formScanTransfert, setFormScanTransfert] = useState({ 
    quantite: '', 
    depotSource: 'Atelier', 
    depotDestination: 'Porteur 26 T' 
  });
  const [nouvelleEntreeStock, setNouvelleEntreeStock] = useState({ 
    articleId: '', 
    quantite: '', 
    prixUnitaire: '', 
    raison: '', 
    date: new Date().toISOString().split('T')[0], 
    depot: 'Atelier' 
  });
  const [nouveauMouvementSortie, setNouveauMouvementSortie] = useState({ 
    articleId: '', 
    quantite: '', 
    raison: '', 
    date: new Date().toISOString().split('T')[0], 
    depot: 'Atelier' 
  });
  const [nouveauTransfert, setNouveauTransfert] = useState({ 
    articleId: '', 
    quantite: '', 
    depotSource: 'Atelier', 
    depotDestination: 'Porteur 26 T', 
    raison: '', 
    date: new Date().toISOString().split('T')[0] 
  });

  // CHARGEMENT INITIAL DEPUIS FIREBASE
  useEffect(() => {
    // Charger jsQR
    if (window.jsQR) {
      jsQRRef.current = window.jsQR;
    } else {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js';
      script.async = true;
      script.onload = () => {
        jsQRRef.current = window.jsQR;
      };
      document.head.appendChild(script);
    }

    // Écoute temps réel des articles
    const articlesRef = ref(database, 'articles');
    onValue(articlesRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const articlesArray = Object.entries(data).map(([key, value]) => ({
          ...value,
          id: isNaN(parseInt(key)) ? key : parseInt(key),
          equipementsAffectes: value.equipementsAffectes || [],
          stockParDepot: value.stockParDepot || {}
        }));
        setArticles(articlesArray);
        console.log('✅ Articles synchronisés:', articlesArray.length);
      }
    });

    // Écoute temps réel des équipements
    const equipementsRef = ref(database, 'equipements');
    onValue(equipementsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const equipementsArray = Object.entries(data).map(([key, value]) => ({
          ...value,
          id: parseInt(key)
        }));
        setEquipements(equipementsArray);
        console.log('✅ Équipements synchronisés:', equipementsArray.length);
      }
    });

    // Écoute temps réel des défauts
    const defautsRef = ref(database, 'defauts');
    onValue(defautsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const defautsArray = Object.values(data);
        setDefauts(defautsArray);
      }
    });

    // Écoute temps réel des interventions
    const interventionsRef = ref(database, 'interventions');
    onValue(interventionsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const interventionsArray = Object.values(data);
        setInterventions(interventionsArray);
      }
    });

    // Écoute temps réel des mouvements
    const mouvementsRef = ref(database, 'mouvements');
    onValue(mouvementsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const mouvementsArray = Object.values(data);
        setMouvementsStock(mouvementsArray);
      }
    });


    // Écoute temps réel des factures
    const facturesRef = ref(database, 'factures');
    onValue(facturesRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const facturesArray = Object.values(data).map(facture => {
          // Convertir lignes en array si c'est un objet
          if (facture.lignes && !Array.isArray(facture.lignes)) {
            facture.lignes = Object.values(facture.lignes);
          }
          return facture;
        });
        setFactures(facturesArray);
        console.log('✅ Factures synchronisées:', facturesArray.length);
        console.log('   Factures:', facturesArray);
      } else {
        setFactures([]);
        console.log('📝 Aucune facture (nœud vide ou inexistant)');
      }
    });

    // Écoute temps réel des accessoires
    const accessoiresRef = ref(database, 'accessoires');
    onValue(accessoiresRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setAccessoiresEquipement(data);
        console.log('✅ Accessoires synchronisés');
      }
    });

    // Initialisation des accessoires s'ils n'existent pas dans Firebase
    const initAccessoires = async () => {
      const accessoiresSnapshot = await get(accessoiresRef);
      if (!accessoiresSnapshot.exists()) {
        const accessoiresInitiaux = {
          1: [  // GT-316-FG - Camion IVECO S-WAY
            { 
              id: 1, 
              nom: 'Carrosserie TEPEMATIC 26T', 
              valeur: 51583, 
              dateAjout: '2023-11-15', 
              description: 'Plateau fixe porte matériel TP', 
              actif: false  // PAS d'intervention sur la carrosserie (juste valeur)
            },
            { 
              id: 2, 
              nom: 'Feux latéraux LED 24V (x4)', 
              valeur: 65.16, 
              dateAjout: '2023-11-22', 
              description: 'Feu latéral orange Ã  LED 24V', 
              actif: false  // PAS d'intervention sur les feux (juste valeur)
            },
          ],
          2: [],  // DX-780-QN - IVECO STRALIS 560 - Pas d'accessoires
          3: [],  // CZ-022-DP - NICOLAS Semi-remorque - Pas d'accessoires
          4: [],  // G3-415-BW - FARMTRAC - Pas d'accessoires
          5: [],  // GM-843-SW - FARMTRAC - Pas d'accessoires
          6: [    // DZ-609-JX - Tracteur ANTONIO CARRARO
            { 
              id: 9, 
              nom: 'SunBrush mobil TrackFlex 3.0', 
              valeur: 64277.00, 
              dateAjout: '2025-05-14', 
              description: 'SunBrush mobil TrackFlex 3.0 5,5m brush', 
              actif: true  // OUI pour interventions de maintenance sur la brosse
            },
          ]
        };
        await set(accessoiresRef, accessoiresInitiaux);
        console.log('✅ Accessoires initiaux créés dans Firebase');
        console.log('  "¢ GT-316-FG : Carrosserie + Feux (structurels, pas d\'intervention)');
        console.log('  "¢ DZ-609-JX : SunBrush (opérationnel, maintenance possible)');
      }
    };
    initAccessoires();

    // Initialisation des factures s'elles n'existent pas dans Firebase
    const initFactures = async () => {
      const facturesSnapshot = await get(facturesRef);
      if (!facturesSnapshot.exists()) {
        await set(facturesRef, {});
        console.log('✅ Nœud factures initialisé dans Firebase');
      }
    };
    initFactures();
  }, []);

  // FONCTIONS UTILITAIRES
  const getStockTotal = (article) => {
    return depots.reduce((sum, depot) => sum + (article.stockParDepot[depot] || 0), 0);
  };

  // Fonction pour synchroniser les accessoires avec Firebase
  const updateAccessoiresFirebase = (nouvelleData) => {
    setAccessoiresEquipement(nouvelleData);
    updateAccessoires(nouvelleData); // Sync avec Firebase
  };

  // NOUVELLES FONCTIONS POUR ÉDITION/SUPPRESSION INTERVENTIONS
  const ouvrirEditionIntervention = (intervention) => {
    setInterventionEnEdition(intervention);
    setModeEditionIntervention(true);
    setNouvelleIntervention({
      equipementId: intervention.equipementId,
      type: intervention.type,
      date: intervention.date,
      km: intervention.km || '',
      heures: intervention.heures || '',
      description: intervention.description || '',
      travauxEffectues: intervention.travauxEffectues || '',
      articlesPrevu: intervention.articles || [],
      depotPrelevement: intervention.depotPrelevement || 'Atelier'
    });
  };

  const modifierIntervention = () => {
    if (!nouvelleIntervention.equipementId || !nouvelleIntervention.type) { 
      alert('Veuillez sélectionner un équipement et un type'); 
      return; 
    }
    
    console.log('🔵 MODIFICATION INTERVENTION');
    console.log('📋 Intervention éditée:', interventionEnEdition);
    console.log('📊 Statut:', interventionEnEdition.statut);
    
    // DÉCOMPTER LE STOCK pour les NOUVEAUX articles ajoutés (en_cours OU effectuée)
    const articlesAvant = interventionEnEdition.articles || [];
    const articlesApres = nouvelleIntervention.articlesPrevu;
    
    console.log('📦 Articles AVANT:', articlesAvant);
    console.log('📦 Articles APRÈS:', articlesApres);
    
    let nouvelStock = articles;
    
    // NOUVELLE LOGIQUE : Calculer les totaux par articleId
    const articlesParId = {};
    
    // Calculer les totaux AVANT par articleId
    articlesAvant.forEach(art => {
      if (!articlesParId[art.articleId]) {
        articlesParId[art.articleId] = { qteAvant: 0, qteApres: 0, code: art.code };
      }
      articlesParId[art.articleId].qteAvant += art.quantite;
    });
    
    // Calculer les totaux APRÈS par articleId
    articlesApres.forEach(art => {
      if (!articlesParId[art.articleId]) {
        articlesParId[art.articleId] = { qteAvant: 0, qteApres: 0, code: art.code };
      }
      articlesParId[art.articleId].qteApres += art.quantite;
    });
    
    console.log('\n📊 TOTAUX PAR ARTICLE:');
    
    // Décompter les différences
    Object.keys(articlesParId).forEach(articleId => {
      const { qteAvant, qteApres, code } = articlesParId[articleId];
      const qteDiff = qteApres - qteAvant;
      
      console.log(`🔍 ${code} (ID: ${articleId})`);
      console.log(`   TOTAL AVANT: ${qteAvant}, TOTAL APRÈS: ${qteApres}, DIFF: ${qteDiff}`);
      
      if (qteDiff > 0) {
        console.log(`   ✅ Décompte ${qteDiff} unités du stock`);
        nouvelStock = nouvelStock.map(a => a.id === parseInt(articleId) ? {
          ...a,
          stockParDepot: {
            ...a.stockParDepot,
            [nouvelleIntervention.depotPrelevement]: (a.stockParDepot[nouvelleIntervention.depotPrelevement] || 0) - qteDiff
          }
        } : a);
      } else if (qteDiff < 0) {
        console.log(`   ♻️ Remet ${-qteDiff} unités dans le stock`);
        nouvelStock = nouvelStock.map(a => a.id === parseInt(articleId) ? {
          ...a,
          stockParDepot: {
            ...a.stockParDepot,
            [nouvelleIntervention.depotPrelevement]: (a.stockParDepot[nouvelleIntervention.depotPrelevement] || 0) - qteDiff
          }
        } : a);
      }
    });
    
    // Mettre à jour le stock dans Firebase
    if (nouvelStock !== articles) {
      setArticles(nouvelStock);
      updateArticles(nouvelStock);
      
      // CRÉER LES MOUVEMENTS DE STOCK pour l'historique
      const nouveauxMouvements = [...mouvementsStock];
      const maxIdMouv = nouveauxMouvements.length > 0 ? Math.max(...nouveauxMouvements.map(m => m.id)) : 0;
      let indexMouv = 0;
      
      Object.keys(articlesParId).forEach(articleId => {
        const { qteAvant, qteApres, code } = articlesParId[articleId];
        const qteDiff = qteApres - qteAvant;
        
        if (qteDiff !== 0) {
          const article = articles.find(a => a.id === parseInt(articleId));
          nouveauxMouvements.push({
            id: maxIdMouv + indexMouv + 1,
            articleId: parseInt(articleId),
            code: code,
            description: article?.description || '',
            type: qteDiff > 0 ? 'sortie' : 'entree',
            quantite: Math.abs(qteDiff),
            depot: nouvelleIntervention.depotPrelevement,
            date: nouvelleIntervention.date,
            raison: `Modification intervention: ${nouvelleIntervention.type}`,
            coutUnitaire: article?.prixUnitaire || 0,
            coutTotal: Math.abs(qteDiff) * (article?.prixUnitaire || 0)
          });
          indexMouv++;
        }
      });
      
      updateMouvements(nouveauxMouvements);
    }
    
    const coutTotal = nouvelleIntervention.articlesPrevu.reduce((sum, art) => 
      sum + (art.quantite * art.prixUnitaire), 0
    );
    
    const interventionModifiee = {
      ...interventionEnEdition,
      equipementId: parseInt(nouvelleIntervention.equipementId),
      type: nouvelleIntervention.type,
      date: nouvelleIntervention.date,
      km: parseInt(nouvelleIntervention.km) || 0,
      heures: parseInt(nouvelleIntervention.heures) || 0,
      description: nouvelleIntervention.description,
      travauxEffectues: nouvelleIntervention.travauxEffectues || '',
      articles: nouvelleIntervention.articlesPrevu,
      coutTotal,
      depotPrelevement: nouvelleIntervention.depotPrelevement
    };
    
    const nouvellesInterventions = interventions.map(i => 
      i.id === interventionEnEdition.id ? interventionModifiee : i
    );
    
    setInterventions(nouvellesInterventions);
    updateInterventions(nouvellesInterventions);
    
    // Réinitialiser
    setInterventionEnEdition(null);
    setModeEditionIntervention(false);
    setNouvelleIntervention({
      equipementId: '',
      type: '',
      date: new Date().toISOString().split('T')[0],
      km: '',
      heures: '',
      description: '',
      travauxEffectues: '',
      articlesPrevu: [],
      depotPrelevement: 'Atelier'
    });
    
    alert('✅ Intervention modifiée avec succès!');
  };

  const annulerEditionIntervention = () => {
    setInterventionEnEdition(null);
    setModeEditionIntervention(false);
    setNouvelleIntervention({
      equipementId: '',
      type: '',
      date: new Date().toISOString().split('T')[0],
      km: '',
      heures: '',
      description: '',
      travauxEffectues: '',
      articlesPrevu: [],
      depotPrelevement: 'Atelier'
    });
  };

  const supprimerIntervention = async (interventionId) => {
    if (window.confirm('⚠️ Êtes-vous sûr de vouloir supprimer cette intervention ?')) {
      try {
        // Trouver l'intervention à supprimer
        const intervention = interventions.find(i => i.id === interventionId);
        
        if (intervention && intervention.articles && intervention.articles.length > 0) {
          console.log('🔄 Remise en stock des articles de l\'intervention supprimée');
          
          // REMETTRE LE STOCK
          let nouvelStock = articles;
          intervention.articles.forEach(art => {
            console.log(`   ♻️ Remet ${art.quantite} unités de ${art.code}`);
            nouvelStock = nouvelStock.map(a => a.id === art.articleId ? {
              ...a,
              stockParDepot: {
                ...a.stockParDepot,
                [intervention.depotPrelevement]: (a.stockParDepot[intervention.depotPrelevement] || 0) + art.quantite
              }
            } : a);
          });
          
          // Mettre à jour le stock
          setArticles(nouvelStock);
          updateArticles(nouvelStock);
          
          // CRÉER LES MOUVEMENTS "ENTRÉE" pour l'historique
          const nouveauxMouvements = [...mouvementsStock];
          const maxIdMouv = nouveauxMouvements.length > 0 ? Math.max(...nouveauxMouvements.map(m => m.id)) : 0;
          
          intervention.articles.forEach((art, index) => {
            const article = articles.find(a => a.id === art.articleId);
            nouveauxMouvements.push({
              id: maxIdMouv + index + 1,
              articleId: art.articleId,
              code: art.code,
              description: article?.description || art.description,
              type: 'entree',
              quantite: art.quantite,
              depot: intervention.depotPrelevement,
              date: new Date().toISOString().split('T')[0],
              raison: `Suppression intervention: ${intervention.type}`,
              coutUnitaire: art.prixUnitaire,
              coutTotal: art.quantite * art.prixUnitaire
            });
          });
          
          updateMouvements(nouveauxMouvements);
        }
        
        // Supprimer spécifiquement cette intervention dans Firebase
        await set(ref(database, 'interventions/' + interventionId), null);
        
        // Mettre à jour l'état local
        const nouvellesInterventions = interventions.filter(i => i.id !== interventionId);
        setInterventions(nouvellesInterventions);
        
        alert('✅ Intervention supprimée et stock remis à jour');
      } catch (error) {
        console.error('Erreur suppression intervention:', error);
        alert('❌ Erreur lors de la suppression');
      }
    }
  };

  // NOUVELLES FONCTIONS POUR ÉDITION/SUPPRESSION DÉFAUTS
  const ouvrirEditionDefaut = (defaut) => {
    setDefautEnEdition(defaut);
    setModeEditionDefaut(true);
    setNouveauDefaut({
      equipementId: defaut.equipementId,
      accessoireId: defaut.accessoireId || '',
      type: defaut.type,
      severite: defaut.severite,
      description: defaut.description,
      localisation: defaut.localisation || '',
      dateConstatation: defaut.dateConstatation,
      operateur: defaut.operateur,
      remarques: defaut.remarques || '',
      photosNoms: []
    });
    setPhotosSelectionnees(defaut.photos || []);
  };

  const modifierDefaut = () => {
    if (!nouveauDefaut.equipementId || !nouveauDefaut.type || !nouveauDefaut.description) {
      alert('Équipement, type et description requis');
      return;
    }
    
    const defautModifie = {
      ...defautEnEdition,
      equipementId: parseInt(nouveauDefaut.equipementId),
      accessoireId: nouveauDefaut.accessoireId ? parseInt(nouveauDefaut.accessoireId) : null,
      type: nouveauDefaut.type,
      severite: nouveauDefaut.severite,
      description: nouveauDefaut.description,
      localisation: nouveauDefaut.localisation,
      dateConstatation: nouveauDefaut.dateConstatation,
      operateur: nouveauDefaut.operateur,
      remarques: nouveauDefaut.remarques,
      photos: photosSelectionnees
    };
    
    const nouveauxDefauts = defauts.map(d => 
      d.id === defautEnEdition.id ? defautModifie : d
    );
    
    updateDefauts(nouveauxDefauts);
    
    // Réinitialiser
    setDefautEnEdition(null);
    setModeEditionDefaut(false);
    setNouveauDefaut({
      equipementId: '',
      accessoireId: '',
      type: 'Fuite',
      severite: 'moyen',
      description: '',
      localisation: '',
      dateConstatation: new Date().toISOString().split('T')[0],
      operateur: 'Axel',
      remarques: '',
      photosNoms: []
    });
    setPhotosSelectionnees([]);
    
    alert('✅ Défaut modifié avec succès!');
  };

  const annulerEditionDefaut = () => {
    setDefautEnEdition(null);
    setModeEditionDefaut(false);
    setNouveauDefaut({
      equipementId: '',
      accessoireId: '',
      type: 'Fuite',
      severite: 'moyen',
      description: '',
      localisation: '',
      dateConstatation: new Date().toISOString().split('T')[0],
      operateur: 'Axel',
      remarques: '',
      photosNoms: []
    });
    setPhotosSelectionnees([]);
  };

  const supprimerDefaut = async (defautId) => {
    if (window.confirm('⚠️ Êtes-vous sûr de vouloir supprimer ce défaut ?')) {
      try {
        // Supprimer spécifiquement ce défaut dans Firebase
        await set(ref(database, 'defauts/' + defautId), null);
        
        // Mettre à jour l'état local
        const nouveauxDefauts = defauts.filter(d => d.id !== defautId);
        setDefauts(nouveauxDefauts);
        
        alert('✅ Défaut supprimé');
      } catch (error) {
        console.error('Erreur suppression défaut:', error);
        alert('❌ Erreur lors de la suppression');
      }
    }
  };

  // NOUVELLE FONCTION POUR SUPPRIMER UN ARTICLE
  const supprimerArticle = async (articleId) => {
    if (window.confirm('⚠️ Êtes-vous sûr de vouloir supprimer cet article ? Cette action est irréversible !')) {
      try {
        // Supprimer spécifiquement cet article dans Firebase
        await set(ref(database, 'articles/' + articleId), null);
        
        // Mettre à jour l'état local
        const nouveauxArticles = articles.filter(a => a.id !== articleId);
        setArticles(nouveauxArticles);
        
        alert('✅ Article supprimé');
      } catch (error) {
        console.error('Erreur suppression article:', error);
        alert('❌ Erreur lors de la suppression');
      }
    }
  };

  const calculerAlertes = () => {
    const alertes = articles.map(article => {
      const total = getStockTotal(article);
      let severite = null;

      if (total === article.stockMin) {
        severite = 'critique';
      }
      else if (total < article.stockMin * 1.5) {
        severite = 'attention';
      }
      else if (depots.some(depot => article.stockParDepot[depot] === 0)) {
        severite = 'vigilance';
      }

      if (severite) {
        return {
          ...article,
          severite,
          depotsVides: depots.filter(d => article.stockParDepot[d] === 0),
          total
        };
      }
      return null;
    }).filter(a => a !== null);

    return alertes;
  };

  // CALCULS POUR LE TABLEAU DE BORD
  const alertesTotales = calculerAlertes();
  const alertesCritiques = alertesTotales.filter(a => a.severite === 'critique');
  const alertesAttention = alertesTotales.filter(a => a.severite === 'attention');
  const alertesVigilance = alertesTotales.filter(a => a.severite === 'vigilance');
  const valeurStockTotal = articles.reduce((sum, a) => sum + (getStockTotal(a) * a.prixUnitaire), 0);
  const interventionsEnCours = interventions.filter(i => i.statut === 'en_cours');

  return (
    <>
      {/* SI PAS CONNECTÉ : AFFICHER LOGIN */}
      {!user && (
        <Login 
          onLogin={handleLogin} 
          error={authError}
        />
      )}

      {/* SI CONNECTÉ : AFFICHER L'APPLICATION */}
      {user && (
        <div className="min-h-screen bg-gray-50">
          <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white p-4">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold">☀️ SOLAIRE NETTOYAGE - Gestion Flotte et Stocks</h1>
                <p className="text-yellow-100 text-sm">Flotte • Stock • Maintenance • Interventions • Fiches matériel</p>
              </div>
              <button
                onClick={handleLogout}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-bold transition shadow-lg flex items-center gap-2"
              >
                🚪 Déconnexion
              </button>
            </div>
          </div>

      <div className="bg-gradient-to-r from-gray-100 to-gray-50 border-b-2 border-gray-200 sticky top-0 z-10 overflow-x-auto shadow-md">
        <div className="flex gap-2 p-3">
          {[
            { id: 'accueil', label: '📊 Accueil' },
            { id: 'fiche', label: `📋 Fiche matériel (${equipements.length})` },
            { id: 'articles', label: `🔦 Articles (${articles.length})` },
            { id: 'inventaire', label: '📊 Inventaire' },
            { id: 'stock', label: '📥 Stock' },
            { id: 'equipements', label: `🚛 Équipements (${equipements.length})` },
            { id: 'factures', label: `💰 Factures & Documents (${factures.length})` },
            { id: 'interventions', label: `🔧 Interventions (${interventions.length})` },
            { id: 'maintenance', label: `⚙️ Maintenance (${defauts.filter(d => d.statut === 'a_traiter').length})` },
            { id: 'alertes', label: '🚨 Alertes' },
            { id: 'statistiques', label: '📈 Stats' },
          ].map(tab => (
            <button 
              key={tab.id} 
              onClick={() => setOngletActif(tab.id)} 
              className={`px-5 py-3 rounded-lg font-bold text-sm transition whitespace-nowrap shadow-md ${
                ongletActif === tab.id 
                  ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-lg transform scale-105' 
                  : 'bg-white text-gray-700 border-2 border-gray-200 hover:border-orange-300 hover:shadow-lg'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 max-w-7xl mx-auto">
        {/* RENDU DU MODULE ACCUEIL */}
        {ongletActif === 'accueil' && (
          <Accueil 
            operateurActif={operateurActif}
            setOperateurActif={setOperateurActif}
            interventions={interventions}
            defauts={defauts}
            articles={articles}
            equipements={equipements}
            alertesCritiques={alertesCritiques}
            alertesAttention={alertesAttention}
            alertesVigilance={alertesVigilance}
            valeurStockTotal={valeurStockTotal}
            interventionsEnCours={interventionsEnCours}
            setOngletActif={setOngletActif}
            getStockTotal={getStockTotal}
            setNouveauDefaut={setNouveauDefaut}
          />
        )}

        {/* PLACEHOLDER POUR LES AUTRES MODULES */}
        {ongletActif === 'fiche' && (
          <FicheMateriel
            equipements={equipements}
            articles={articles}
            accessoiresEquipement={accessoiresEquipement}
            setAccessoiresEquipement={updateAccessoiresFirebase}
            interventions={interventions}
            equipementSelectionne={equipementSelectionne}
            setEquipementSelectionne={setEquipementSelectionne}
            factures={factures}
            articles={articles}
            mouvementsStock={mouvementsStock}
          />
        )}

        {ongletActif === 'articles' && (
          <Articles
            articles={articles}
            setArticles={setArticles}
            modeEditionArticle={modeEditionArticle}
            setModeEditionArticle={setModeEditionArticle}
            articleFormEnEdition={articleFormEnEdition}
            setArticleFormEnEdition={setArticleFormEnEdition}
            afficherFormulaireArticle={afficherFormulaireArticle}
            setAfficherFormulaireArticle={setAfficherFormulaireArticle}
            nouvelArticleForm={nouvelArticleForm}
            setNouvelArticleForm={setNouvelArticleForm}
            getStockTotal={getStockTotal}
            updateArticles={updateArticles}
            database={database}
            ref={ref}
            set={set}
            supprimerArticle={supprimerArticle}
            setOngletActif={setOngletActif}
            setArticlePreselectionne={setArticlePreselectionne}
            mouvementsStock={mouvementsStock}
          />
        )}

        {ongletActif === 'inventaire' && (
          <Inventaire
            articles={articles}
            setArticles={setArticles}
            depots={depots}
            articleEnEdition={articleEnEdition}
            setArticleEnEdition={setArticleEnEdition}
            panierCommande={panierCommande}
            setPanierCommande={setPanierCommande}
            getStockTotal={getStockTotal}
            updateArticles={updateArticles}
            mouvementsStock={mouvementsStock}
          />
        )}

        {ongletActif === 'stock' && (
          <Stock
            articles={articles}
            setArticles={setArticles}
            equipements={equipements}
            depots={depots}
            mouvementsStock={mouvementsStock}
            setMouvementsStock={setMouvementsStock}
            afficherScannerQR={afficherScannerQR}
            setAfficherScannerQR={setAfficherScannerQR}
            scanResultat={scanResultat}
            setScanResultat={setScanResultat}
            actionScan={actionScan}
            setActionScan={setActionScan}
            formScanEntree={formScanEntree}
            setFormScanEntree={setFormScanEntree}
            formScanSortie={formScanSortie}
            setFormScanSortie={setFormScanSortie}
            formScanTransfert={formScanTransfert}
            setFormScanTransfert={setFormScanTransfert}
            nouvelleEntreeStock={nouvelleEntreeStock}
            setNouvelleEntreeStock={setNouvelleEntreeStock}
            nouveauMouvementSortie={nouveauMouvementSortie}
            setNouveauMouvementSortie={setNouveauMouvementSortie}
            nouveauTransfert={nouveauTransfert}
            setNouveauTransfert={setNouveauTransfert}
            getStockTotal={getStockTotal}
            updateArticles={updateArticles}
            updateMouvements={updateMouvements}
            videoRef={videoRef}
            canvasRef={canvasRef}
            scanningRef={scanningRef}
            jsQRRef={jsQRRef}
            videoStream={videoStream}
            setVideoStream={setVideoStream}
            articlePreselectionne={articlePreselectionne}
            setArticlePreselectionne={setArticlePreselectionne}
          />
        )}

        {ongletActif === 'equipements' && (
          <Equipements
            equipements={equipements}
            setEquipements={setEquipements}
            nouvelEquipement={nouvelEquipement}
            setNouvelEquipement={setNouvelEquipement}
            afficherFormulaireEquipement={afficherFormulaireEquipement}
            setAfficherFormulaireEquipement={setAfficherFormulaireEquipement}
            equipementEnEdition={equipementEnEdition}
            setEquipementEnEdition={setEquipementEnEdition}
            modeEdition={modeEdition}
            setModeEdition={setModeEdition}
            setOngletActif={setOngletActif}
            setEquipementSelectionne={setEquipementSelectionne}
            database={database}
            ref={ref}
            set={set}
          />
        )}


        {ongletActif === 'factures' && (
          <FacturesDocuments
            factures={factures}
            setFactures={setFactures}
            equipements={equipements}
            updateFactures={(nouvellesFactures) => {
              setFactures(nouvellesFactures);
              // Fonction pour nettoyer les undefined (Firebase n'accepte pas undefined)
              const nettoyerObjet = (obj) => {
                if (Array.isArray(obj)) {
                  return obj.map(item => nettoyerObjet(item));
                } else if (obj !== null && typeof obj === 'object') {
                  const cleaned = {};
                  Object.keys(obj).forEach(key => {
                    if (obj[key] !== undefined) {
                      cleaned[key] = nettoyerObjet(obj[key]);
                    }
                  });
                  return cleaned;
                }
                return obj;
              };
              
              // ✅ CORRECTION V3.12 - Écrire chaque facture individuellement
              // Compatible avec règles Firebase sécurisées ($factureId)
              
              // D'abord, récupérer les IDs actuels dans Firebase pour supprimer ceux qui ne sont plus là
              get(ref(database, 'factures')).then((snapshot) => {
                const facturesExistantes = snapshot.val();
                const idsExistants = facturesExistantes ? Object.keys(facturesExistantes) : [];
                const idsNouveaux = nouvellesFactures.map(f => String(f.id));
                
                // Supprimer les factures qui ne sont plus dans le nouveau tableau
                idsExistants.forEach(id => {
                  if (!idsNouveaux.includes(id)) {
                    set(ref(database, 'factures/' + id), null); // null = suppression
                  }
                });
                
                // Écrire/mettre à jour toutes les factures du nouveau tableau
                nouvellesFactures.forEach(f => {
                  set(ref(database, 'factures/' + f.id), nettoyerObjet(f));
                });
              });
            }}
          />
        )}

        {ongletActif === 'interventions' && (
          <Interventions
            interventions={interventions}
            setInterventions={setInterventions}
            equipements={equipements}
            articles={articles}
            setArticles={setArticles}
            depots={depots}
            accessoiresEquipement={accessoiresEquipement}
            nouvelleIntervention={nouvelleIntervention}
            setNouvelleIntervention={setNouvelleIntervention}
            nouvelArticleIntervention={nouvelArticleIntervention}
            setNouvelArticleIntervention={setNouvelArticleIntervention}
            afficherArticlesEquipement={afficherArticlesEquipement}
            setAfficherArticlesEquipement={setAfficherArticlesEquipement}
            afficherScannerIntervention={afficherScannerIntervention}
            setAfficherScannerIntervention={setAfficherScannerIntervention}
            scanResultatIntervention={scanResultatIntervention}
            setScanResultatIntervention={setScanResultatIntervention}
            quantiteScanIntervention={quantiteScanIntervention}
            setQuantiteScanIntervention={setQuantiteScanIntervention}
            updateArticles={updateArticles}
            updateInterventions={updateInterventions}
            mouvementsStock={mouvementsStock}
            updateMouvements={updateMouvements}
            videoIntervention={videoIntervention}
            canvasIntervention={canvasIntervention}
            scanningIntervention={scanningIntervention}
            jsQRRef={jsQRRef}
            // NOUVELLES PROPS POUR ÉDITION/SUPPRESSION
            interventionEnEdition={interventionEnEdition}
            modeEditionIntervention={modeEditionIntervention}
            ouvrirEditionIntervention={ouvrirEditionIntervention}
            modifierIntervention={modifierIntervention}
            annulerEditionIntervention={annulerEditionIntervention}
            supprimerIntervention={supprimerIntervention}
          />
        )}

        {ongletActif === 'maintenance' && (
          <Maintenance
            defauts={defauts}
            updateDefauts={updateDefauts}
            equipements={equipements}
            accessoiresEquipement={accessoiresEquipement}
            interventions={interventions}
            operateurs={operateurs}
            operateurActif={operateurActif}
            nouveauDefaut={nouveauDefaut}
            setNouveauDefaut={setNouveauDefaut}
            photosSelectionnees={photosSelectionnees}
            setPhotosSelectionnees={setPhotosSelectionnees}
            defautSelectionne={defautSelectionne}
            setDefautSelectionne={setDefautSelectionne}
            fileInputRef={fileInputRef}
            setOngletActif={setOngletActif}
            setNouvelleIntervention={setNouvelleIntervention}
            // NOUVELLES PROPS POUR ÉDITION/SUPPRESSION
            defautEnEdition={defautEnEdition}
            modeEditionDefaut={modeEditionDefaut}
            ouvrirEditionDefaut={ouvrirEditionDefaut}
            modifierDefaut={modifierDefaut}
            annulerEditionDefaut={annulerEditionDefaut}
            supprimerDefaut={supprimerDefaut}
          />
        )}

        {ongletActif === 'alertes' && (
          <Alertes
            articles={articles}
            updateArticles={updateArticles}
            mouvementsStock={mouvementsStock}
            updateMouvements={updateMouvements}
            depots={depots}
            panierCommande={panierCommande}
            setPanierCommande={setPanierCommande}
          />
        )}

        {ongletActif === 'statistiques' && (
          <Statistiques
            equipements={equipements}
            interventions={interventions}
            defauts={defauts}
            accessoiresEquipement={accessoiresEquipement}
            equipementSelectionne={equipementSelectionne}
            setEquipementSelectionne={setEquipementSelectionne}
            factures={factures}
            articles={articles}
            mouvementsStock={mouvementsStock}
          />
        )}
      </div>
        </div>
      )}
    </>
  );
}