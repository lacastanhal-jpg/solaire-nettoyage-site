import React from 'react';

const Statistiques = ({ 
  equipements,
  interventions,
  defauts,
  accessoiresEquipement,
  equipementSelectionne,
  setEquipementSelectionne,
  factures,
  articles,
  mouvementsStock
}) => {
  if (!factures) factures = [];
  if (!articles) articles = [];
  if (!mouvementsStock) mouvementsStock = [];


  // CALCULS GLOBAUX DE LA FLOTTE
  const valeurAchatTotale = equipements.reduce((sum, eq) => sum + (eq.valeurAchat || 0), 0);
  const valeurActuelleTotale = equipements.reduce((sum, eq) => sum + (eq.valeurActuelle || 0), 0);
  
  // Calculer la valeur totale de TOUS les accessoires
  const valeurAccessoiresTotale = Object.keys(accessoiresEquipement).reduce((sum, equipId) => {
    const accessoires = accessoiresEquipement[equipId] || [];
    return sum + accessoires.reduce((s, a) => s + (a.valeur || 0), 0);
  }, 0);
  
  const valeurTotaleFlotte = valeurActuelleTotale + valeurAccessoiresTotale;
  
  // Calculer la dépréciation totale
  const depreciationTotale = valeurAchatTotale - valeurActuelleTotale;
  const tauxDepreciation = valeurAchatTotale > 0 ? ((depreciationTotale / valeurAchatTotale) * 100) : 0;


  // ÉTATS - FILTRES
  const [filtreEquipement, setFiltreEquipement] = React.useState('');
  const [filtrePeriodeDebut, setFiltrePeriodeDebut] = React.useState('');
  const [filtrePeriodeFin, setFiltrePeriodeFin] = React.useState('');

  // FONCTIONS - FILTRAGE
  const interventionsFiltrees = interventions.filter(interv => {
    if (filtreEquipement && interv.equipementId !== parseInt(filtreEquipement)) return false;
    if (filtrePeriodeDebut && interv.date < filtrePeriodeDebut) return false;
    if (filtrePeriodeFin && interv.date > filtrePeriodeFin) return false;
    return true;
  });

  const defautsFiltres = defauts.filter(def => {
    if (filtreEquipement && def.equipementId !== parseInt(filtreEquipement)) return false;
    return true;
  });

  // STATS PAR ÉQUIPEMENT SÉLECTIONNÉ
  const equipSelectionne = equipements.find(e => e.id === equipementSelectionne);
  const eqInterventions = interventions.filter(i => i.equipementId === equipSelectionne?.id);
  const eqDefauts = defauts.filter(d => d.equipementId === equipSelectionne?.id);
  const eqAccessoires = accessoiresEquipement[equipementSelectionne] || [];
  
  // Factures de cet équipement
  const eqFactures = equipSelectionne && factures ? factures.flatMap(facture => {
    if (!facture || !facture.lignes || !Array.isArray(facture.lignes)) return [];
    return facture.lignes
      .filter(ligne => String(ligne.equipementId) === String(equipSelectionne.id))
      .map(ligne => ({
        ...facture,
        ligneConcernee: ligne
      }));
  }) : [];
  const eqTotalFactures = eqFactures.reduce((sum, f) => sum + (f.ligneConcernee?.total || 0), 0);


  const exporterPDF = () => {
    const coutTotal = eqInterventions.filter(i => i.statut === 'effectue').reduce((sum, i) => sum + (i.coutTotal || 0), 0);

    let html = `
      <html>
        <head>
          <meta charset="UTF-8">
          <title>Statistiques ${equipSelectionne?.immat}</title>
          <style>
            body { font-family: Arial; margin: 20px; color: #333; }
            h1 { color: #6B46C1; border-bottom: 3px solid #6B46C1; padding-bottom: 10px; }
            h2 { color: #7C3AED; margin-top: 25px; border-left: 5px solid #7C3AED; padding-left: 10px; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
            th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
            th { background-color: #7C3AED; color: white; }
            tr:nth-child(even) { background-color: #f9f5ff; }
            .summary { background-color: #f0e6ff; padding: 15px; border-radius: 8px; margin: 15px 0; }
            .summary-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
            .summary-box { background: white; padding: 10px; border-left: 4px solid #7C3AED; }
            .total { font-weight: bold; color: #6B46C1; }
            .date { font-size: 12px; color: #666; }
          </style>
        </head>
        <body>
          <h1>📊 STATISTIQUES ÉQUIPEMENT</h1>
          <p><strong>Équipement:</strong> ${equipSelectionne?.immat} - ${equipSelectionne?.marque} ${equipSelectionne?.modele}</p>
          <p><strong>Générée le:</strong> ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}</p>

          <div class="summary">
            <div class="summary-grid">
              <div class="summary-box">
                <p><strong>Interventions:</strong> ${eqInterventions.length}</p>
                <p class="date">${eqInterventions.filter(i => i.statut === 'effectue').length} effectuées</p>
              </div>
              <div class="summary-box">
                <p><strong>Défauts:</strong> ${eqDefauts.length}</p>
                <p class="date">${eqDefauts.filter(d => d.statut === 'resolu').length} résolus</p>
              </div>
              <div class="summary-box">
                <p><strong>Accessoires:</strong> ${eqAccessoires.length}</p>
                <p class="date">Valeur: ${eqAccessoires.reduce((s, a) => s + a.valeur, 0).toFixed(2)}€</p>
              </div>
              <div class="summary-box">
                <p class="total">💰 TOTAL INTERVENTIONS: ${coutTotal.toFixed(2)}€</p>
              </div>
            </div>
          </div>

          ${eqInterventions.length > 0 ? `
            <h2>🔧 INTERVENTIONS (${eqInterventions.length})</h2>
            <table>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>KM</th>
                <th>Coût</th>
                <th>Statut</th>
              </tr>
              ${eqInterventions.map(i => `
                <tr>
                  <td>${i.date}</td>
                  <td>${i.type}</td>
                  <td>${i.km}</td>
                  <td>${i.coutTotal}€</td>
                  <td>${i.statut === 'effectue' ? '✅ Effectuée' : '⏳ En cours'}</td>
                </tr>
              `).join('')}
            </table>
          ` : ''}

          ${eqDefauts.length > 0 ? `
            <h2>🚨 DÉFAUTS (${eqDefauts.length})</h2>
            <table>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Sévérité</th>
                <th>Opérateur</th>
                <th>Statut</th>
              </tr>
              ${eqDefauts.map(d => `
                <tr>
                  <td>${d.dateConstatation}</td>
                  <td>${d.type}</td>
                  <td>${d.severite === 'critique' ? '🔴 Critique' : d.severite === 'moyen' ? '🟠 Moyen' : '🟡 Mineur'}</td>
                  <td>${d.operateur}</td>
                  <td>${d.statut === 'resolu' ? '✅ Résolu' : '⏳ À traiter'}</td>
                </tr>
              `).join('')}
            </table>
          ` : ''}

          ${eqAccessoires.length > 0 ? `
            <h2>🎨 ACCESSOIRES (${eqAccessoires.length})</h2>
            <table>
              <tr>
                <th>Nom</th>
                <th>Valeur</th>
                <th>Date</th>
                <th>Statut</th>
              </tr>
              ${eqAccessoires.map(a => `
                <tr>
                  <td>${a.nom}</td>
                  <td>${a.valeur.toFixed(2)}€</td>
                  <td>${a.dateAjout}</td>
                  <td>${a.actif ? '✅ Actif' : '❌ Inactif'}</td>
                </tr>
              `).join('')}
            </table>
          ` : ''}

          <p style="margin-top: 30px; text-align: center; color: #999; font-size: 12px;">Document généré par Solaire Nettoyage</p>
        </body>
      </html>
    `;

    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write(html);
    printWindow.document.close();
    setTimeout(() => printWindow.print(), 250);
  };

  const exporterCSV = () => {
    let csv = `SOLAIRE NETTOYAGE - EXPORT STATISTIQUES\n`;
    csv += `Équipement,${equipSelectionne?.immat} - ${equipSelectionne?.marque} ${equipSelectionne?.modele}\n`;
    csv += `Généré le,${new Date().toLocaleDateString('fr-FR')} ${new Date().toLocaleTimeString('fr-FR')}\n\n`;

    csv += `INTERVENTIONS\n`;
    csv += `ID,Date,Type,KM,Heures,Description,Coût,Statut,Dépôt\n`;
    eqInterventions.forEach(i => {
      csv += `${i.id},"${i.date}","${i.type}",${i.km},${i.heures},"${i.description}",${i.coutTotal},"${i.statut}","${i.depotPrelevement}"\n`;
    });

    csv += `\n\nDÉFAUTS\n`;
    csv += `ID,Date,Type,Sévérité,Description,Opérateur,Localisation,Statut,Date Résolution\n`;
    eqDefauts.forEach(d => {
      csv += `${d.id},"${d.dateConstatation}","${d.type}","${d.severite}","${d.description}","${d.operateur}","${d.localisation}","${d.statut}","${d.dateArchivage || 'N/A'}"\n`;
    });

    csv += `\n\nRÉSUMÉ\n`;
    csv += `Interventions totales,${eqInterventions.length}\n`;
    csv += `Interventions effectuées,${eqInterventions.filter(i => i.statut === 'effectue').length}\n`;
    csv += `Coût total interventions,${eqInterventions.filter(i => i.statut === 'effectue').reduce((sum, i) => sum + (i.coutTotal || 0), 0).toFixed(2)}€\n`;
    csv += `Défauts totaux,${eqDefauts.length}\n`;
    csv += `Défauts résolus,${eqDefauts.filter(d => d.statut === 'resolu').length}\n`;

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv));
    element.setAttribute('download', `Statistiques_${equipSelectionne?.immat}_${new Date().toISOString().split('T')[0]}.csv`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);

    alert('✅ CSV téléchargé!');
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-black text-purple-700">📈 STATISTIQUES ÉQUIPEMENTS</h2>

      {/* ========== FILTRES GLOBAUX ========== */}
      <div className="bg-purple-50 border-2 border-purple-300 p-4 rounded-lg mb-6">
        <p className="font-bold text-purple-700 mb-3">🔍 FILTRES</p>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <select
            value={filtreEquipement}
            onChange={(e) => setFiltreEquipement(e.target.value)}
            className="border-2 border-purple-300 rounded px-3 py-2 text-sm font-medium"
          >
            <option value="">Tous les équipements</option>
            {equipements.map(eq => (
              <option key={eq.id} value={eq.id}>{eq.immat}</option>
            ))}
          </select>

          <input
            type="date"
            value={filtrePeriodeDebut}
            onChange={(e) => setFiltrePeriodeDebut(e.target.value)}
            className="border-2 border-purple-300 rounded px-3 py-2 text-sm font-medium"
            placeholder="Date début"
          />

          <input
            type="date"
            value={filtrePeriodeFin}
            onChange={(e) => setFiltrePeriodeFin(e.target.value)}
            className="border-2 border-purple-300 rounded px-3 py-2 text-sm font-medium"
            placeholder="Date fin"
          />

          <button
            onClick={() => { setFiltreEquipement(''); setFiltrePeriodeDebut(''); setFiltrePeriodeFin(''); }}
            className="bg-gray-500 text-white px-4 py-2 rounded font-bold text-sm hover:bg-gray-600"
          >
            ✕ Reset
          </button>
        </div>

      {/* ========== RÉSUMÉ FILTRÉ ========== */}
      {(filtreEquipement || filtrePeriodeDebut || filtrePeriodeFin) && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-blue-100 p-4 rounded-lg border-2 border-blue-400">
            <p className="text-xs font-bold text-blue-700">INTERVENTIONS</p>
            <p className="text-3xl font-black text-blue-600">{interventionsFiltrees.length}</p>
          </div>
          <div className="bg-green-100 p-4 rounded-lg border-2 border-green-400">
            <p className="text-xs font-bold text-green-700">COÛT TOTAL</p>
            <p className="text-3xl font-black text-green-600">
              {interventionsFiltrees.filter(i => i.statut === 'effectue').reduce((sum, i) => sum + (i.coutTotal || 0), 0).toLocaleString('fr-FR')}€
            </p>
          </div>
          <div className="bg-red-100 p-4 rounded-lg border-2 border-red-400">
            <p className="text-xs font-bold text-red-700">DÉFAUTS</p>
            <p className="text-3xl font-black text-red-600">{defautsFiltres.length}</p>
          </div>
          <div className="bg-yellow-100 p-4 rounded-lg border-2 border-yellow-400">
            <p className="text-xs font-bold text-yellow-700">DÉFAUTS OUVERTS</p>
            <p className="text-3xl font-black text-yellow-600">
              {defautsFiltres.filter(d => d.statut !== 'resolu' && d.statut !== 'archive').length}
            </p>
          </div>
        </div>
      )}

      </div>


      {/* ====== NOUVEAU : RÉSUMÉ GLOBAL DE LA FLOTTE ====== */}
      <div className="bg-gradient-to-r from-amber-100 via-orange-100 to-red-100 border-4 border-orange-500 p-6 rounded-xl shadow-xl">
        <h3 className="text-2xl font-black text-orange-700 mb-4 flex items-center">
          🚛 VALEUR TOTALE DE LA FLOTTE
        </h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {/* Nombre d'équipements */}
          <div className="bg-white p-4 rounded-lg border-2 border-blue-300 shadow-md">
            <p className="text-xs text-gray-600 font-bold">ÉQUIPEMENTS</p>
            <p className="text-4xl font-black text-blue-600">{equipements.length}</p>
            <p className="text-sm text-gray-700">unités au total</p>
          </div>

          {/* Valeur d'achat totale */}
          <div className="bg-white p-4 rounded-lg border-2 border-purple-300 shadow-md">
            <p className="text-xs text-gray-600 font-bold">VALEUR D'ACHAT</p>
            <p className="text-3xl font-black text-purple-600">{valeurAchatTotale.toLocaleString('fr-FR')}€</p>
            <p className="text-sm text-gray-700">investissement initial</p>
          </div>

          {/* Valeur actuelle totale */}
          <div className="bg-white p-4 rounded-lg border-2 border-green-300 shadow-md">
            <p className="text-xs text-gray-600 font-bold">VALEUR ACTUELLE</p>
            <p className="text-3xl font-black text-green-600">{valeurActuelleTotale.toLocaleString('fr-FR')}€</p>
            <p className="text-sm text-gray-700">véhicules seuls</p>
          </div>

          {/* Valeur accessoires totale */}
          <div className="bg-white p-4 rounded-lg border-2 border-indigo-300 shadow-md">
            <p className="text-xs text-gray-600 font-bold">ACCESSOIRES</p>
            <p className="text-3xl font-black text-indigo-600">{valeurAccessoiresTotale.toLocaleString('fr-FR')}€</p>
            <p className="text-sm text-gray-700">équipements additionnels</p>
          </div>
        </div>

        {/* Valeur totale + Dépréciation */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* VALEUR TOTALE (le plus important) */}
          <div className="bg-gradient-to-br from-orange-500 to-red-600 p-6 rounded-lg shadow-lg">
            <p className="text-sm text-orange-100 font-bold mb-2">💰 VALEUR TOTALE FLOTTE</p>
            <p className="text-5xl font-black text-white mb-2">
              {valeurTotaleFlotte.toLocaleString('fr-FR')}€
            </p>
            <p className="text-orange-100 text-sm">
              Véhicules + Accessoires
            </p>
          </div>

          {/* DÉPRÉCIATION */}
          <div className="bg-gradient-to-br from-gray-600 to-gray-800 p-6 rounded-lg shadow-lg">
            <p className="text-sm text-gray-300 font-bold mb-2">📉 DÉPRÉCIATION TOTALE</p>
            <p className="text-4xl font-black text-white mb-2">
              -{depreciationTotale.toLocaleString('fr-FR')}€
            </p>
            <p className="text-gray-300 text-sm">
              {tauxDepreciation.toFixed(1)}% du prix d'achat
            </p>
          </div>
        </div>
      </div>
      {/* ====== FIN RÉSUMÉ GLOBAL ====== */}

      {/* Sélection équipement (existant) */}
      <div className="bg-white p-4 rounded border-2 border-purple-300">
        <label className="block text-sm font-bold text-gray-700 mb-2">Sélectionner équipement pour détails</label>
        <select 
          value={equipementSelectionne} 
          onChange={(e) => setEquipementSelectionne(parseInt(e.target.value))}
          className="w-full border-2 border-purple-400 rounded px-3 py-2 font-bold text-lg"
        >
          {equipements.map(eq => (
            <option key={eq.id} value={eq.id}>
              {eq.immat} - {eq.marque} {eq.modele}
            </option>
          ))}
        </select>
      </div>

      {/* Statistiques par équipement (existant) */}
      {equipSelectionne && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-purple-100 to-indigo-100 border-4 border-purple-500 p-6 rounded-xl">
            <h3 className="text-2xl font-black text-purple-700 mb-4">📊 RÉSUMÉ - {equipSelectionne.immat}</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-lg border-2 border-purple-300">
                <p className="text-xs text-gray-600 font-bold">INTERVENTIONS</p>
                <p className="text-3xl font-black text-purple-600">{eqInterventions.length}</p>
                <p className="text-sm text-gray-700">{eqInterventions.filter(i => i.statut === 'effectue').length} effectuées</p>
              </div>
              <div className="bg-white p-4 rounded-lg border-2 border-red-300">
                <p className="text-xs text-gray-600 font-bold">DÉFAUTS</p>
                <p className="text-3xl font-black text-red-600">{eqDefauts.length}</p>
                <p className="text-sm text-gray-700">{eqDefauts.filter(d => d.statut === 'resolu').length} résolus</p>
              </div>
              <div className="bg-white p-4 rounded-lg border-2 border-green-300">
                <p className="text-xs text-gray-600 font-bold">ACCESSOIRES</p>
                <p className="text-3xl font-black text-green-600">{eqAccessoires.length}</p>
                <p className="text-sm text-gray-700">{eqAccessoires.reduce((sum, a) => sum + a.valeur, 0).toFixed(0)}€ total</p>
              </div>
              <div className="bg-white p-4 rounded-lg border-2 border-blue-300">
                <p className="text-xs text-gray-600 font-bold">COÛT INTERVENTIONS</p>
                <p className="text-3xl font-black text-blue-600">{eqInterventions.filter(i => i.statut === 'effectue').reduce((sum, i) => sum + (i.coutTotal || 0), 0).toFixed(0)}€</p>
              </div>
              <div className="bg-white p-4 rounded-lg border-2 border-orange-300">
                <p className="text-xs text-gray-600 font-bold">FACTURES & FRAIS</p>
                <p className="text-3xl font-black text-orange-600">{eqFactures.length}</p>
                <p className="text-sm text-gray-700">{eqTotalFactures.toFixed(2)}€ total</p>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <button onClick={() => exporterPDF()} className="flex-1 bg-red-600 text-white px-4 py-3 rounded-lg font-black hover:bg-red-700">
              📄 Exporter PDF
            </button>
            <button onClick={() => exporterCSV()} className="flex-1 bg-green-600 text-white px-4 py-3 rounded-lg font-black hover:bg-green-700">
              📊 Exporter CSV
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Statistiques;