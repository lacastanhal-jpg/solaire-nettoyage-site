// Module MAINTENANCE - Solaire Nettoyage V3.0
// MODIFIÉ : Ajout accessoires actifs dans menu + édition/suppression défauts
import React from 'react';

const Maintenance = ({ 
  defauts,
  updateDefauts,
  equipements,
  accessoiresEquipement,
  interventions,
  operateurs,
  operateurActif,
  nouveauDefaut,
  setNouveauDefaut,
  photosSelectionnees,
  setPhotosSelectionnees,
  defautSelectionne,
  setDefautSelectionne,
  fileInputRef,
  setOngletActif,
  setNouvelleIntervention,
  // NOUVELLES PROPS POUR ÉDITION/SUPPRESSION
  defautEnEdition,
  modeEditionDefaut,
  ouvrirEditionDefaut,
  modifierDefaut,
  annulerEditionDefaut,
  supprimerDefaut
}) => {

  // ÉTAT - RECHERCHE INTELLIGENTE
  const [rechercheDefauts, setRechercheDefauts] = React.useState('');

  // NOUVELLE FONCTION : GET ÉQUIPEMENTS ET ACCESSOIRES ACTIFS (comme dans Interventions)
  const getEquipementsEtAccessoires = () => {
    const liste = equipements.map(eq => ({
      id: eq.id,
      nom: `${eq.immat} - ${eq.marque} ${eq.modele}`,
      type: 'equipement'
    }));
    
    // Ajouter les accessoires actifs
    Object.entries(accessoiresEquipement).forEach(([eqId, accs]) => {
      accs.forEach(acc => {
        if (acc.actif) {
          const parentEq = equipements.find(e => e.id === parseInt(eqId));
          liste.push({
            id: parseInt(eqId),
            nom: `${acc.nom} (sur ${parentEq?.immat})`,
            type: 'accessoire',
            accessoireId: acc.id
          });
        }
      });
    });
    
    return liste;
  };

  // FONCTION - FILTRAGE INTELLIGENT MULTI-MOTS
  const filtrerDefauts = (recherche) => {
    const defautsATraiter = defauts.filter(d => d.statut === 'a_traiter');
    
    if (!recherche.trim()) return defautsATraiter;
    
    const mots = recherche.toLowerCase().trim().split(/\s+/);
    
    return defautsATraiter.filter(d => {
      const equipement = equipements.find(e => e.id === d.equipementId);
      const contenu = [
        d.type || '',
        equipement?.immat || '',
        equipement?.marque || '',
        equipement?.modele || '',
        d.description || '',
        d.localisation || '',
        d.operateur || '',
        d.severite || ''
      ].join(' ').toLowerCase();
      
      return mots.every(mot => contenu.includes(mot));
    });
  };

  const gererSelectionPhotos = (e) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target.result;
        setPhotosSelectionnees(prev => [...prev, { nom: file.name, base64 }]);
        setNouveauDefaut(prev => ({ 
          ...prev, 
          photosNoms: [...prev.photosNoms, { nom: file.name, base64 }] 
        }));
      };
      reader.readAsDataURL(file);
    });
  };

  const supprimerPhotoSelectionnee = (index) => {
    const newPhotos = photosSelectionnees.filter((_, i) => i !== index);
    setPhotosSelectionnees(newPhotos);
    setNouveauDefaut(prev => ({ ...prev, photosNoms: newPhotos }));
  };

  const declareDefaut = () => {
    if (modeEditionDefaut) {
      // Mode édition : utiliser la fonction de modification
      modifierDefaut();
    } else {
      // Mode création : logique existante
      if (!nouveauDefaut.equipementId || !nouveauDefaut.type || !nouveauDefaut.description) {
        alert('Équipement, type et description requis');
        return;
      }

      const newDefaut = {
        id: defauts.length > 0 ? Math.max(...defauts.map(d => d.id)) + 1 : 1,
        equipementId: parseInt(nouveauDefaut.equipementId),
        accessoireId: nouveauDefaut.accessoireId ? parseInt(nouveauDefaut.accessoireId) : null,
        type: nouveauDefaut.type,
        severite: nouveauDefaut.severite,
        description: nouveauDefaut.description,
        localisation: nouveauDefaut.localisation,
        dateConstatation: nouveauDefaut.dateConstatation,
        operateur: nouveauDefaut.operateur,
        remarques: nouveauDefaut.remarques,
        photos: photosSelectionnees,
        statut: 'a_traiter',
        interventionLieeId: null,
        dateArchivage: null
      };

      updateDefauts([...defauts, newDefaut]);
      setNouveauDefaut({ equipementId: '', accessoireId: '', type: 'Fuite', severite: 'moyen', description: '', localisation: '', dateConstatation: new Date().toISOString().split('T')[0], operateur: operateurActif || 'Axel', remarques: '', photosNoms: [] });
      setPhotosSelectionnees([]);
      alert('✅ Défaut signalé!');
    }
  };

  const resoudreDefaut = (defautId) => {
    updateDefauts(defauts.map(d => d.id === defautId ? { ...d, statut: 'resolu', dateArchivage: new Date().toISOString().split('T')[0] } : d));
  };

  const creerInterventionDepuisDefaut = (defaut) => {
    setNouvelleIntervention({
      equipementId: defaut.accessoireId ? '999' : defaut.equipementId.toString(),
      type: 'Réparation',
      date: new Date().toISOString().split('T')[0],
      km: '',
      heures: '',
      description: `Réparation - ${defaut.type}: ${defaut.description}`,
      articlesPrevu: [],
      depotPrelevement: 'Atelier'
    });
    setOngletActif('interventions');
    alert('✅ Intervention pré-remplie depuis le défaut');
  };

  const defautsATraiter = defauts.filter(d => d.statut === 'a_traiter');
  const defautsAffiches = rechercheDefauts ? filtrerDefauts(rechercheDefauts) : defautsATraiter;
  const defautsCritiques = defautsAffiches.filter(d => d.severite === 'critique');
  const defautsAtention = defautsAffiches.filter(d => d.severite === 'moyen');
  const defautsMineur = defautsAffiches.filter(d => d.severite === 'mineur');
  const defautsArchives = defauts.filter(d => d.statut === 'resolu');

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-red-50 to-orange-50 border-2 border-red-300 p-6 rounded-xl">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-black text-red-700">
            {modeEditionDefaut ? '✏️ MODIFIER DÉFAUT' : '🚨 DÉCLARER UN DÉFAUT'}
          </h2>
          {modeEditionDefaut && (
            <button
              onClick={annulerEditionDefaut}
              className="bg-gray-500 text-white px-4 py-2 rounded font-bold hover:bg-gray-600"
            >
              ❌ Annuler
            </button>
          )}
        </div>
        <div className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Équipement/Accessoire *</label>
              <select 
                value={nouveauDefaut.equipementId} 
                onChange={(e) => {
                  const selection = getEquipementsEtAccessoires().find(item => 
                    item.id === parseInt(e.target.value)
                  );
                  if (selection && selection.type === 'accessoire') {
                    setNouveauDefaut({
                      ...nouveauDefaut, 
                      equipementId: e.target.value,
                      accessoireId: selection.accessoireId
                    });
                  } else {
                    setNouveauDefaut({
                      ...nouveauDefaut, 
                      equipementId: e.target.value,
                      accessoireId: ''
                    });
                  }
                }} 
                className="w-full border-2 border-red-300 rounded px-3 py-2 font-semibold"
              >
                <option value="">Sélectionner équipement/accessoire</option>
                {getEquipementsEtAccessoires().map(item => 
                  <option 
                    key={`${item.id}-${item.accessoireId || ''}`} 
                    value={item.id}
                    className={item.type === 'accessoire' ? 'font-bold text-blue-600' : ''}
                  >
                    {item.nom}
                  </option>
                )}
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Opérateur *</label>
              <select value={nouveauDefaut.operateur} onChange={(e) => setNouveauDefaut({...nouveauDefaut, operateur: e.target.value})} className="w-full border-2 rounded px-3 py-2 font-semibold">
                {operateurs.map(op => <option key={op} value={op}>{op}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Type de défaut *</label>
              <select value={nouveauDefaut.type} onChange={(e) => setNouveauDefaut({...nouveauDefaut, type: e.target.value})} className="w-full border-2 rounded px-3 py-2 font-semibold">
                <option value="Fuite">Fuite</option>
                <option value="Bruit">Bruit anormal</option>
                <option value="Usure">Usure</option>
                <option value="Cassure">Cassure/Casse</option>
                <option value="Dysfonctionnement">Dysfonctionnement</option>
                <option value="Autre">Autre</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Sévérité *</label>
              <select value={nouveauDefaut.severite} onChange={(e) => setNouveauDefaut({...nouveauDefaut, severite: e.target.value})} className="w-full border-2 rounded px-3 py-2 font-semibold">
                <option value="mineur">🟢 Mineur</option>
                <option value="moyen">🟠 Moyen</option>
                <option value="critique">🔴 Critique</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Date constatation</label>
              <input type="date" value={nouveauDefaut.dateConstatation} onChange={(e) => setNouveauDefaut({...nouveauDefaut, dateConstatation: e.target.value})} className="w-full border-2 rounded px-3 py-2" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Description détaillée *</label>
            <textarea value={nouveauDefaut.description} onChange={(e) => setNouveauDefaut({...nouveauDefaut, description: e.target.value})} placeholder="Ex: Fuite hydraulique..." className="w-full border-2 border-red-300 rounded px-3 py-2 h-20 font-semibold" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Localisation</label>
              <input type="text" value={nouveauDefaut.localisation} onChange={(e) => setNouveauDefaut({...nouveauDefaut, localisation: e.target.value})} placeholder="Ex: Raccord bras avant" className="w-full border-2 rounded px-3 py-2" />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Remarques</label>
              <input type="text" value={nouveauDefaut.remarques} onChange={(e) => setNouveauDefaut({...nouveauDefaut, remarques: e.target.value})} placeholder="Observations..." className="w-full border-2 rounded px-3 py-2" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">📸 Photos (optionnel)</label>
            <input ref={fileInputRef} type="file" accept="image/*" multiple onChange={gererSelectionPhotos} className="mb-2" />
            {photosSelectionnees.length > 0 && (
              <div className="flex gap-2 flex-wrap">
                {photosSelectionnees.map((photo, idx) => (
                  <div key={idx} className="relative">
                    <img src={photo.base64} alt={photo.nom} className="w-20 h-20 object-cover rounded" />
                    <button onClick={() => supprimerPhotoSelectionnee(idx)} className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full w-5 h-5 text-xs">✕</button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <button 
            onClick={declareDefaut} 
            className={`w-full ${modeEditionDefaut ? 'bg-blue-600' : 'bg-red-600'} text-white px-6 py-3 rounded-lg font-black text-lg hover:opacity-90`}
          >
            {modeEditionDefaut ? '✓ MODIFIER DÉFAUT' : '🚨 SIGNALER DÉFAUT'}
          </button>
        </div>
      </div>

      <div>
        {/* BARRE DE RECHERCHE INTELLIGENTE */}
        <div className="mb-4">
          <input 
            type="text" 
            placeholder="🔍 Rechercher défaut (type, équipement, description, opérateur, sévérité)..." 
            value={rechercheDefauts}
            onChange={(e) => setRechercheDefauts(e.target.value)}
            className="w-full border-2 border-red-400 rounded-lg px-4 py-3 font-medium focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition"
          />
          {rechercheDefauts && (
            <div className="text-sm text-red-700 mt-2 font-medium flex items-center gap-2">
              🎯 {filtrerDefauts(rechercheDefauts).length} défaut(s) trouvé(s) sur {defautsATraiter.length}
              {filtrerDefauts(rechercheDefauts).length === 0 && (
                <span className="text-red-600">• Aucun résultat</span>
              )}
            </div>
          )}
        </div>

        <h2 className="text-2xl font-black text-gray-700 mb-4">📋 DÉFAUTS À TRAITER ({rechercheDefauts ? filtrerDefauts(rechercheDefauts).length : defautsATraiter.length})</h2>
        {defautsCritiques.length > 0 && (
          <div className="bg-red-50 border-4 border-red-500 p-4 rounded-lg mb-4">
            <h3 className="text-xl font-black text-red-700 mb-3">🔴 CRITIQUES ({defautsCritiques.length})</h3>
            <div className="space-y-3">
              {defautsCritiques.map(d => {
                const eq = equipements.find(e => e.id === d.equipementId);
                const acc = d.accessoireId ? Object.values(accessoiresEquipement).flat().find(a => a.id === d.accessoireId) : null;
                return (
                  <div key={d.id} className="bg-white rounded-lg p-4 border-2 border-red-300">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <h4 className="font-black text-lg text-red-700">{d.type}</h4>
                        <p className="text-sm text-gray-600">{eq?.immat} {acc ? `- ${acc.nom}` : ''}</p>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => ouvrirEditionDefaut(d)} className="bg-blue-600 text-white px-3 py-1 rounded font-bold text-sm">✏️</button>
                        <button onClick={() => supprimerDefaut(d.id)} className="bg-red-600 text-white px-3 py-1 rounded font-bold text-sm">🗑️</button>
                        <button onClick={() => setDefautSelectionne(d)} className="bg-gray-600 text-white px-3 py-1 rounded font-bold text-sm">👁️ Détails</button>
                      </div>
                    </div>
                    <p className="text-sm mb-3">{d.description}</p>
                    <p className="text-xs text-gray-500 mb-2">Signalé par <strong>{d.operateur}</strong> le {d.dateConstatation}</p>
                    <div className="flex gap-2">
                      <button onClick={() => creerInterventionDepuisDefaut(d)} className="flex-1 bg-orange-600 text-white px-3 py-2 rounded font-bold text-sm">🔧 Créer intervention</button>
                      <button onClick={() => resoudreDefaut(d.id)} className="flex-1 bg-green-600 text-white px-3 py-2 rounded font-bold text-sm">✔ Résolu</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {defautsAtention.length > 0 && (
          <div className="bg-orange-50 border-4 border-orange-500 p-4 rounded-lg mb-4">
            <h3 className="text-xl font-black text-orange-700 mb-3">🟠 MOYENS ({defautsAtention.length})</h3>
            <div className="space-y-3">
              {defautsAtention.map(d => {
                const eq = equipements.find(e => e.id === d.equipementId);
                const acc = d.accessoireId ? Object.values(accessoiresEquipement).flat().find(a => a.id === d.accessoireId) : null;
                return (
                  <div key={d.id} className="bg-white rounded-lg p-4 border-2 border-orange-300">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <h4 className="font-black text-lg text-orange-700">{d.type}</h4>
                        <p className="text-sm text-gray-600">{eq?.immat} {acc ? `- ${acc.nom}` : ''}</p>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => ouvrirEditionDefaut(d)} className="bg-blue-600 text-white px-3 py-1 rounded font-bold text-sm">✏️</button>
                        <button onClick={() => supprimerDefaut(d.id)} className="bg-red-600 text-white px-3 py-1 rounded font-bold text-sm">🗑️</button>
                        <button onClick={() => setDefautSelectionne(d)} className="bg-gray-600 text-white px-3 py-1 rounded font-bold text-sm">👁️ Détails</button>
                      </div>
                    </div>
                    <p className="text-sm mb-3">{d.description}</p>
                    <p className="text-xs text-gray-500 mb-2">Signalé par <strong>{d.operateur}</strong> le {d.dateConstatation}</p>
                    <div className="flex gap-2">
                      <button onClick={() => creerInterventionDepuisDefaut(d)} className="flex-1 bg-orange-600 text-white px-3 py-2 rounded font-bold text-sm">🔧 Créer intervention</button>
                      <button onClick={() => resoudreDefaut(d.id)} className="flex-1 bg-green-600 text-white px-3 py-2 rounded font-bold text-sm">✔ Résolu</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {defautsMineur.length > 0 && (
          <div className="bg-yellow-50 border-4 border-yellow-500 p-4 rounded-lg">
            <h3 className="text-xl font-black text-yellow-700 mb-3">🟡 MINEURS ({defautsMineur.length})</h3>
            <div className="space-y-3">
              {defautsMineur.map(d => {
                const eq = equipements.find(e => e.id === d.equipementId);
                const acc = d.accessoireId ? Object.values(accessoiresEquipement).flat().find(a => a.id === d.accessoireId) : null;
                return (
                  <div key={d.id} className="bg-white rounded-lg p-4 border-2 border-yellow-300">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <h4 className="font-black text-lg text-yellow-700">{d.type}</h4>
                        <p className="text-sm text-gray-600">{eq?.immat} {acc ? `- ${acc.nom}` : ''}</p>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => ouvrirEditionDefaut(d)} className="bg-blue-600 text-white px-3 py-1 rounded font-bold text-sm">✏️</button>
                        <button onClick={() => supprimerDefaut(d.id)} className="bg-red-600 text-white px-3 py-1 rounded font-bold text-sm">🗑️</button>
                        <button onClick={() => setDefautSelectionne(d)} className="bg-gray-600 text-white px-3 py-1 rounded font-bold text-sm">👁️ Détails</button>
                      </div>
                    </div>
                    <p className="text-sm mb-3">{d.description}</p>
                    <p className="text-xs text-gray-500 mb-2">Signalé par <strong>{d.operateur}</strong> le {d.dateConstatation}</p>
                    <div className="flex gap-2">
                      <button onClick={() => creerInterventionDepuisDefaut(d)} className="flex-1 bg-orange-600 text-white px-3 py-2 rounded font-bold text-sm">🔧 Créer intervention</button>
                      <button onClick={() => resoudreDefaut(d.id)} className="flex-1 bg-green-600 text-white px-3 py-2 rounded font-bold text-sm">✔ Résolu</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {defautsATraiter.length === 0 && (
          <div className="bg-green-50 border-4 border-green-500 p-6 rounded-lg text-center">
            <p className="text-2xl font-black text-green-700">✅ AUCUN DÉFAUT À TRAITER</p>
          </div>
        )}
      </div>

      {defautsArchives.length > 0 && (
        <div className="bg-green-50 border-2 border-green-300 p-4 rounded-lg">
          <h3 className="text-xl font-black text-green-700 mb-3">✅ DÉFAUTS RÉSOLUS ({defautsArchives.length})</h3>
          <div className="space-y-2">
            {defautsArchives.map(d => {
              const eq = equipements.find(e => e.id === d.equipementId);
              const acc = d.accessoireId ? Object.values(accessoiresEquipement).flat().find(a => a.id === d.accessoireId) : null;
              return (
                <div key={d.id} className="bg-white rounded p-3 border-l-4 border-green-500 flex justify-between items-center">
                  <div>
                    <p className="font-semibold">{d.type} - {eq?.immat} {acc ? `- ${acc.nom}` : ''}</p>
                    <p className="text-xs text-gray-500">Résolu le {d.dateArchivage}</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => ouvrirEditionDefaut(d)} className="bg-blue-600 text-white px-3 py-1 rounded font-bold text-sm">✏️</button>
                    <button onClick={() => supprimerDefaut(d.id)} className="bg-red-600 text-white px-3 py-1 rounded font-bold text-sm">🗑️</button>
                    <button onClick={() => setDefautSelectionne(d)} className="bg-gray-600 text-white px-3 py-1 rounded font-bold text-sm">👁️ Voir</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODAL DÉTAILS DÉFAUT */}
      {defautSelectionne && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-2xl font-black">📋 DÉTAILS DÉFAUT</h2>
              <button onClick={() => setDefautSelectionne(null)} className="text-2xl">✕</button>
            </div>

            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg border-2">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-gray-500 font-bold">TYPE</p>
                    <p className="text-lg font-black">{defautSelectionne.type}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 font-bold">SÉVÉRITÉ</p>
                    <p className="text-lg font-black">{defautSelectionne.severite === 'critique' ? '🔴' : defautSelectionne.severite === 'moyen' ? '🟠' : '🟡'} {defautSelectionne.severite.toUpperCase()}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 font-bold">ÉQUIPEMENT</p>
                    <p className="font-semibold">{equipements.find(e => e.id === defautSelectionne.equipementId)?.immat}</p>
                    {defautSelectionne.accessoireId && (
                      <p className="text-sm text-blue-600">
                        {Object.values(accessoiresEquipement).flat().find(a => a.id === defautSelectionne.accessoireId)?.nom}
                      </p>
                    )}
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 font-bold">OPÉRATEUR</p>
                    <p className="font-semibold">{defautSelectionne.operateur}</p>
                  </div>
                </div>
              </div>

              <div>
                <p className="text-xs text-gray-500 font-bold mb-1">DESCRIPTION</p>
                <p className="bg-blue-50 border-2 border-blue-300 p-3 rounded font-semibold">{defautSelectionne.description}</p>
              </div>

              <div>
                <p className="text-xs text-gray-500 font-bold mb-1">LOCALISATION</p>
                <p className="font-semibold">{defautSelectionne.localisation || 'Non spécifiée'}</p>
              </div>

              {defautSelectionne.remarques && (
                <div>
                  <p className="text-xs text-gray-500 font-bold mb-1">REMARQUES</p>
                  <p className="bg-yellow-50 border-2 border-yellow-300 p-3 rounded">{defautSelectionne.remarques}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-gray-500 font-bold">DATE CONSTATATION</p>
                  <p className="font-semibold">{defautSelectionne.dateConstatation}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 font-bold">STATUT</p>
                  <p className={`font-black ${defautSelectionne.statut === 'a_traiter' ? 'text-red-600' : 'text-green-600'}`}>
                    {defautSelectionne.statut === 'a_traiter' ? 'À TRAITER' : 'RÉSOLU'}
                  </p>
                </div>
              </div>

              {defautSelectionne.photos && defautSelectionne.photos.length > 0 && (
                <div>
                  <p className="text-xs text-gray-500 font-bold mb-2">PHOTOS ({defautSelectionne.photos.length})</p>
                  <div className="grid grid-cols-2 gap-2">
                    {defautSelectionne.photos.map((photo, idx) => (
                      <img key={idx} src={photo.base64} alt={photo.nom} className="w-full rounded border-2 border-gray-300" />
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button onClick={() => setDefautSelectionne(null)} className="mt-6 w-full bg-gray-600 text-white px-6 py-3 rounded-lg font-black">FERMER</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Maintenance;