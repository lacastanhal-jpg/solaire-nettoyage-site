// Module INVENTAIRE - Solaire Nettoyage V3.1
// AMÉLIORATIONS : Recherche intelligente + toutes fonctionnalités préservées
// Vue d'ensemble des stocks par dépôt avec panier commande
import React from 'react';

const Inventaire = ({
  articles,
  setArticles,
  depots,
  articleEnEdition,
  setArticleEnEdition,
  panierCommande,
  setPanierCommande,
  getStockTotal,
  updateArticles,
  mouvementsStock
}) => {

  // NOUVEL ÉTAT - RECHERCHE INTELLIGENTE
  const [rechercheInventaire, setRechercheInventaire] = React.useState('');
  const [articleEnHistorique, setArticleEnHistorique] = React.useState(null);

  // NOUVELLE FONCTION - FILTRAGE INTELLIGENT MULTI-MOTS
  const filtrerArticles = () => {
    if (!rechercheInventaire.trim()) return articles;
    
    // Découper la recherche en mots (séparés par espaces)
    const mots = rechercheInventaire.toLowerCase().trim().split(/\s+/);
    
    return articles.filter(a => {
      // Créer une chaîne avec tout le contenu de l'article
      const contenu = [
        a.code,
        a.description,
        a.fournisseur || ''
      ].join(' ').toLowerCase();
      
      // Vérifier que TOUS les mots sont présents
      return mots.every(mot => contenu.includes(mot));
    });
  };

  // FONCTIONS PANIER COMMANDE
  const genererTexteCommande = (article) => {
    const qteACommander = Math.max(0, article.stockMin - getStockTotal(article));
    const existant = panierCommande.find(item => item.articleId === article.id);
    if (existant) { 
      alert('Article déjà dans le panier !'); 
      return; 
    }
    setPanierCommande([...panierCommande, { 
      articleId: article.id, 
      qteEditable: qteACommander, 
      article 
    }]);
  };

  const supprimerDuPanier = (articleId) => {
    setPanierCommande(panierCommande.filter(item => item.articleId !== articleId));
  };

  const mettreAJourQte = (articleId, qte) => {
    setPanierCommande(panierCommande.map(item => 
      item.articleId === articleId ? { ...item, qteEditable: parseInt(qte) || 0 } : item
    ));
  };

  const regrouperParFournisseur = () => {
    const groupes = {};
    panierCommande.forEach(item => {
      const fournisseur = item.article.fournisseur;
      if (!groupes[fournisseur]) groupes[fournisseur] = [];
      groupes[fournisseur].push(item);
    });
    return groupes;
  };

  const copierToutCommandes = () => {
    const groupes = regrouperParFournisseur();
    const htmlTables = [];
    
    Object.keys(groupes).forEach(fournisseur => {
      const items = groupes[fournisseur];
      
      // Créer tableau HTML avec styles professionnels (SANS PRIX)
      const htmlTable = `
<div style="margin-bottom: 30px; font-family: Arial, sans-serif;">
  <h2 style="color: #2563eb; border-bottom: 3px solid #2563eb; padding-bottom: 10px; margin-bottom: 15px;">
    📋 COMMANDE - ${fournisseur}
  </h2>
  <table style="width: 100%; border-collapse: collapse; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
    <thead>
      <tr style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
        <th style="padding: 12px; text-align: left; border: 1px solid #ddd; font-weight: bold;">Code Article</th>
        <th style="padding: 12px; text-align: left; border: 1px solid #ddd; font-weight: bold;">Description</th>
        <th style="padding: 12px; text-align: center; border: 1px solid #ddd; font-weight: bold;">Quantité</th>
      </tr>
    </thead>
    <tbody>
      ${items.map((item, index) => `
      <tr style="background-color: ${index % 2 === 0 ? '#f9fafb' : '#ffffff'};">
        <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold; color: #1f2937;">${item.article.code}</td>
        <td style="padding: 10px; border: 1px solid #ddd; color: #4b5563;">${item.article.description}</td>
        <td style="padding: 10px; border: 1px solid #ddd; text-align: center; font-weight: bold; color: #2563eb;">${item.qteEditable}</td>
      </tr>
      `).join('')}
    </tbody>
  </table>
</div>`;
      
      htmlTables.push(htmlTable);
    });
    
    const htmlComplet = htmlTables.join('\n\n');
    
    // COPIER EN HTML (pas en texte brut) pour que le tableau s'affiche formaté
    const blob = new Blob([htmlComplet], { type: 'text/html' });
    const data = [new ClipboardItem({ 'text/html': blob })];
    
    navigator.clipboard.write(data).then(() => {
      alert('✅ Tableau(x) HTML copié(s) !\n\nCollez dans votre email (Cmd+V ou Ctrl+V)');
      setPanierCommande([]);
    }).catch(() => {
      alert('❌ Erreur lors de la copie');
    });
  };

  // FONCTIONS ÉDITION STOCK MIN
  const ouvrirEditionStockMin = (article) => {
    setArticleEnEdition({ ...article, stockMinTemp: article.stockMin });
  };

  const sauvegarderStockMin = () => {
    if (articleEnEdition && articleEnEdition.stockMinTemp >= 0) {
      updateArticles(articles.map(a => 
        a.id === articleEnEdition.id ? { ...a, stockMin: parseInt(articleEnEdition.stockMinTemp) } : a
      ));
      setArticleEnEdition(null);
    }
  };

  const annulerEditionStockMin = () => {
    setArticleEnEdition(null);
  };

  // Calculer les articles filtrés
  const articlesFiltres = filtrerArticles();

  return (
    <div className="space-y-4">
      {/* MODAL ÉDITION STOCK MIN */}
      {articleEnEdition && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-xl max-w-md w-full mx-4">
            <h3 className="text-lg font-black text-gray-800 mb-4">✏️ Modifier Stock Minimum</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Code</label>
                <input type="text" value={articleEnEdition.code} disabled className="w-full border rounded px-3 py-2 bg-gray-100" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Description</label>
                <input type="text" value={articleEnEdition.description} disabled className="w-full border rounded px-3 py-2 bg-gray-100" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Stock total</label>
                <input type="text" value={getStockTotal(articleEnEdition)} disabled className="w-full border rounded px-3 py-2 bg-gray-100" />
              </div>
              <div className="border-t pt-3">
                <label className="block text-sm font-bold text-orange-600 mb-1">Stock Minimum *</label>
                <input 
                  type="number" 
                  min="0" 
                  value={articleEnEdition.stockMinTemp} 
                  onChange={(e) => setArticleEnEdition({...articleEnEdition, stockMinTemp: e.target.value})} 
                  className="w-full border-2 border-orange-300 rounded px-3 py-2 outline-none text-lg font-bold" 
                />
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button onClick={sauvegarderStockMin} className="flex-1 bg-green-600 text-white px-4 py-2 rounded font-bold">✓ Sauvegarder</button>
              <button onClick={annulerEditionStockMin} className="flex-1 bg-gray-400 text-white px-4 py-2 rounded font-bold">✕ Annuler</button>
            </div>
          </div>
        </div>
      )}

      {/* PANIER COMMANDE */}
      {panierCommande.length > 0 && (
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-xl shadow-lg">
          <h3 className="text-2xl font-black mb-4">🛒 Panier ({panierCommande.length})</h3>
          <div className="space-y-3 mb-4">
            {Object.entries(regrouperParFournisseur()).map(([fournisseur, items]) => (
              <div key={fournisseur} className="bg-white bg-opacity-95 text-gray-800 rounded-lg p-4">
                <h4 className="font-black text-lg text-blue-600 mb-2">📦 {fournisseur}</h4>
                <div className="space-y-2">
                  {items.map(item => (
                    <div key={item.articleId} className="flex justify-between items-center bg-blue-50 p-3 rounded border border-blue-200">
                      <div className="flex-1">
                        <div className="font-bold text-blue-700">{item.article.code}</div>
                        <div className="text-sm">{item.article.description}</div>
                      </div>
                      <div className="flex items-center gap-3">
                        <input 
                          type="number" 
                          min="0" 
                          value={item.qteEditable} 
                          onChange={(e) => mettreAJourQte(item.articleId, e.target.value)} 
                          className="w-16 border-2 border-blue-300 rounded px-2 py-1 font-bold text-center" 
                        />
                        <div className="text-right min-w-20">
                          <div className="font-bold text-blue-600">{item.article.prixUnitaire}€</div>
                          <div className="text-sm text-green-600">{(item.qteEditable * item.article.prixUnitaire).toFixed(2)}€</div>
                        </div>
                        <button onClick={() => supprimerDuPanier(item.articleId)} className="bg-red-500 text-white px-3 py-1 rounded text-sm">✕</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <button onClick={copierToutCommandes} className="flex-1 bg-green-500 text-white px-6 py-3 rounded font-black hover:bg-green-600">✓ Copier Tout</button>
            <button onClick={() => setPanierCommande([])} className="flex-1 bg-red-500 text-white px-6 py-3 rounded font-black hover:bg-red-600">🗑️ Vider</button>
          </div>
        </div>
      )}

      {/* TABLEAU INVENTAIRE AVEC RECHERCHE */}
      <div className="bg-white p-4 rounded border overflow-x-auto">
        <h2 className="font-black text-xl mb-4">📊 INVENTAIRE - Stocks par Dépôt</h2>
        
        {/* BARRE DE RECHERCHE INTELLIGENTE */}
        <div className="mb-4">
          <input 
            type="text" 
            placeholder="🔍 Rechercher article (code, description, fournisseur)..." 
            value={rechercheInventaire}
            onChange={(e) => setRechercheInventaire(e.target.value)}
            className="w-full border-2 border-orange-400 rounded-lg px-4 py-3 font-medium focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition"
          />
          {rechercheInventaire && (
            <div className="text-sm text-orange-700 mt-2 font-medium flex items-center gap-2">
              🎯 {articlesFiltres.length} article(s) trouvé(s) sur {articles.length}
              {articlesFiltres.length === 0 && (
                <span className="text-red-600">• Aucun résultat</span>
              )}
            </div>
          )}
        </div>

        {articlesFiltres.length > 0 ? (
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-orange-100 to-yellow-100">
                <th className="px-3 py-3 text-left font-bold">Code</th>
                <th className="px-3 py-3 text-left font-bold">Description</th>
                <th className="px-3 py-3 text-right font-bold">Prix</th>
                {depots.map(depot => (
                  <th key={depot} className="px-3 py-3 text-center font-bold bg-white border-l">{depot}</th>
                ))}
                <th className="px-3 py-3 text-center font-bold bg-green-50">Total</th>
                <th className="px-3 py-3 text-center font-bold">Min</th>
                <th className="px-3 py-3 text-right font-bold">Valeur</th>
                <th className="px-3 py-3 text-center font-bold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {articlesFiltres.map(a => {
                const total = getStockTotal(a);
                const enAlerte = total < a.stockMin;
                return (
                  <tr key={a.id} className={`border-b ${enAlerte ? 'bg-red-50' : ''}`}>
                    <td className="px-3 py-3 font-bold text-orange-600">{a.code}</td>
                    <td className="px-3 py-3 text-sm">{a.description}</td>
                    <td className="px-3 py-3 text-right">{a.prixUnitaire}€</td>
                    {depots.map(depot => (
                      <td key={depot} className="px-3 py-3 text-center font-bold border-l">
                        <span className={`px-2 py-1 rounded text-xs ${
                          a.stockParDepot[depot] === 0 ? 'bg-gray-100' : 
                          a.stockParDepot[depot] <= 2 ? 'bg-orange-200' : 'bg-green-200'
                        }`}>
                          {a.stockParDepot[depot] || 0}
                        </span>
                      </td>
                    ))}
                    <td className="px-3 py-3 text-center font-black bg-green-50 text-green-700">{total}</td>
                    <td className="px-3 py-3 text-center">
                      <button 
                        onClick={() => ouvrirEditionStockMin(a)} 
                        className="text-blue-600 hover:underline font-bold"
                      >
                        {a.stockMin}
                      </button>
                    </td>
                    <td className="px-3 py-3 text-right font-bold">{(total * a.prixUnitaire).toFixed(2)}€</td>
                    <td className="px-3 py-3 text-center">
                      <div className="flex gap-1 justify-center">
                        <button 
                          onClick={() => genererTexteCommande(a)} 
                          className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-bold"
                          title="Commander"
                        >
                          🔧
                        </button>
                        <button 
                          onClick={() => setArticleEnHistorique(a)} 
                          className="bg-purple-600 text-white px-2 py-1 rounded text-xs font-bold"
                          title="Historique"
                        >
                          📊
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : rechercheInventaire ? (
          <div className="text-center py-12 text-gray-500">
            <div className="text-5xl mb-3">🔍</div>
            <div className="font-bold text-lg">Aucun article trouvé</div>
            <div className="text-sm mt-1">Essayez avec un autre terme de recherche</div>
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            <div className="text-5xl mb-3">📦</div>
            <div className="font-bold text-lg">Aucun article</div>
          </div>
        )}
      </div>

      {/* MODAL HISTORIQUE */}
      {articleEnHistorique && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-2xl font-black">📊 HISTORIQUE MOUVEMENTS</h2>
              <button onClick={() => setArticleEnHistorique(null)} className="text-2xl hover:text-red-600">✕</button>
            </div>
            
            <div className="bg-gray-50 p-3 rounded border-2 mb-4">
              <p className="font-bold text-lg">{articleEnHistorique.code}</p>
              <p className="text-sm text-gray-600">{articleEnHistorique.description}</p>
            </div>
            
            <div className="space-y-2">
              {mouvementsStock.filter(m => m.articleId === articleEnHistorique.id).length === 0 ? (
                <p className="text-gray-500 italic text-center py-8">Aucun mouvement enregistré</p>
              ) : (
                mouvementsStock.filter(m => m.articleId === articleEnHistorique.id).map(m => {
                  const isTransfert = m.type === 'transfert' || m.type === 'transfer';
                  let depotInfo = '';
                  
                  if (isTransfert && m.raison && m.raison.includes('→')) {
                    const [source, destination] = m.raison.split('→').map(d => d.trim());
                    depotInfo = `DE ${source} VERS ${destination}`;
                  } else if (m.type === 'entree') {
                    depotInfo = `DANS ${m.depot || 'dépôt inconnu'}`;
                  } else if (m.type === 'sortie') {
                    depotInfo = `DE ${m.depot || 'dépôt inconnu'}`;
                  }

                  return (
                    <div key={m.id} className={`p-3 rounded border-l-4 ${m.type === 'entree' ? 'bg-green-50 border-green-500' : m.type === 'sortie' ? 'bg-red-50 border-red-500' : 'bg-blue-50 border-blue-500'}`}>
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-bold text-lg">
                              {m.type === 'entree' ? '📥 Entrée' : m.type === 'sortie' ? '📤 Sortie' : '🔄 Transfert'}
                            </p>
                            <span className="text-xs bg-gray-200 px-2 py-1 rounded">{m.date}</span>
                          </div>
                          
                          <p className="text-sm font-bold text-blue-700 mb-1">
                            {depotInfo}
                          </p>
                          
                          {(!isTransfert || !m.raison.includes('→')) && m.raison && (
                            <p className="text-xs text-gray-600 italic">
                              📝 {m.raison}
                            </p>
                          )}
                          
                          {m.coutTotal && (
                            <p className="text-xs text-green-700 font-bold mt-1">
                              💰 {m.coutTotal.toFixed(2)}€ total
                              {m.quantite && ` (${(m.coutTotal / m.quantite).toFixed(2)}€/unité)`}
                            </p>
                          )}
                        </div>
                        
                        <div className="text-right">
                          <p className="font-black text-2xl">
                            {isTransfert ? '→' : m.type === 'entree' ? '+' : '-'} {m.quantite}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
            
            <button 
              onClick={() => setArticleEnHistorique(null)} 
              className="w-full bg-gray-600 text-white px-4 py-2 rounded font-bold mt-4 hover:bg-gray-700"
            >
              Fermer
            </button>
          </div>
        </div>
      )}

    </div>
  );
};

export default Inventaire;