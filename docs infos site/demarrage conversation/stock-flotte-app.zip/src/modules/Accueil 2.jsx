// Module ACCUEIL - Solaire Nettoyage V3.0
// Tableau de bord et sélection opérateur
import React from 'react';

const Accueil = ({
  operateurActif,
  setOperateurActif,
  interventions,
  defauts,
  articles,
  equipements,
  alertesCritiques,
  alertesAttention,
  alertesVigilance,
  valeurStockTotal,
  interventionsEnCours,
  setOngletActif,
  getStockTotal,
  setNouveauDefaut
}) => {
  
  const operateurs = ['Axel', 'Jérôme', 'Sébastien', 'Joffrey', 'Fabien', 'Angelo'];

  return (
    <div className="space-y-6">
      {/* SÉLECTION OPÉRATEUR SI PAS ENCORE FAIT */}
      {!operateurActif ? (
        <div>
          <h2 className="text-3xl font-black text-gray-800 text-center mb-8">
            👷 SÉLECTIONNEZ VOTRE PROFIL OPÉRATEUR
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {operateurs.map((operateur) => {
              // Calculer les stats par opérateur
              const interventionsOperateur = interventions.filter(i => 
                i.operateur === operateur || 
                (i.date === new Date().toISOString().split('T')[0] && !i.operateur)
              ).length;
              
              const defautsOperateur = defauts.filter(d => 
                d.operateur === operateur
              ).length;
              
              const defautsCritiquesOperateur = defauts.filter(d => 
                d.operateur === operateur && 
                d.severite === 'critique' && 
                d.statut === 'a_traiter'
              ).length;

              // Couleur par opérateur
              const couleurs = {
                'Axel': 'from-blue-500 to-blue-600',
                'Jérôme': 'from-green-500 to-green-600',
                'Sébastien': 'from-purple-500 to-purple-600',
                'Joffrey': 'from-orange-500 to-orange-600',
                'Fabien': 'from-red-500 to-red-600',
                'Angelo': 'from-indigo-500 to-indigo-600'
              };

              const avatars = {
                'Axel': '👨‍🔧',
                'Jérôme': '👨‍💼',
                'Sébastien': '👨‍🏭',
                'Joffrey': '👨‍🔧',
                'Fabien': '👷‍♂️',
                'Angelo': '👨‍🏭'
              };

              return (
                <button
                  key={operateur}
                  onClick={() => {
                    setOperateurActif(operateur);
                    localStorage.setItem('operateurActif', operateur);
                  }}
                  className={`bg-gradient-to-br ${couleurs[operateur]} text-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300`}
                >
                  <div className="text-6xl mb-4">{avatars[operateur]}</div>
                  <h3 className="text-2xl font-black mb-4">{operateur}</h3>
                  
                  <div className="bg-white bg-opacity-20 rounded-xl p-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Interventions:</span>
                      <span className="font-bold text-lg">{interventionsOperateur}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Défauts signalés:</span>
                      <span className="font-bold text-lg">{defautsOperateur}</span>
                    </div>
                    {defautsCritiquesOperateur > 0 && (
                      <div className="bg-red-600 bg-opacity-80 rounded-lg p-2 mt-2">
                        <span className="text-xs">⚠️ CRITIQUES: </span>
                        <span className="font-black">{defautsCritiquesOperateur}</span>
                      </div>
                    )}
                  </div>

                  <div className="mt-6 text-sm opacity-90">
                    Dernière connexion: Aujourd'hui
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-8 text-center">
            <p className="text-gray-500 text-sm">
              Sélectionnez votre profil pour accéder à votre tableau de bord personnalisé
            </p>
          </div>
        </div>
      ) : (
        /* TABLEAU DE BORD PERSONNALISÉ */
        <div>
          {/* EN-TÊTE OPÉRATEUR */}
          <div className="bg-gradient-to-r from-gray-700 to-gray-900 text-white p-6 rounded-xl mb-6 flex justify-between items-center">
            <div>
              <h2 className="text-3xl font-black">Bonjour {operateurActif} ! 👋</h2>
              <p className="text-gray-200 mt-2">
                {new Date().toLocaleDateString('fr-FR', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
            </div>
            <button
              onClick={() => {
                setOperateurActif(null);
                localStorage.removeItem('operateurActif');
              }}
              className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded-lg font-bold"
            >
              🔄 Changer d'opérateur
            </button>
          </div>

          {/* ALERTES PERSONNALISÉES */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {/* Défauts à traiter assignés */}
            <div className="bg-red-50 border-2 border-red-300 p-4 rounded-xl">
              <h3 className="font-bold text-red-700 mb-2">🚨 Mes défauts à traiter</h3>
              <div className="text-3xl font-black text-red-600">
                {defauts.filter(d => d.operateur === operateurActif && d.statut === 'a_traiter').length}
              </div>
              <button 
                onClick={() => setOngletActif('maintenance')}
                className="mt-2 text-sm text-red-600 hover:underline"
              >
                Voir les défauts →
              </button>
            </div>

            {/* Interventions du jour */}
            <div className="bg-blue-50 border-2 border-blue-300 p-4 rounded-xl">
              <h3 className="font-bold text-blue-700 mb-2">📅 Interventions aujourd'hui</h3>
              <div className="text-3xl font-black text-blue-600">
                {interventions.filter(i => 
                  i.date === new Date().toISOString().split('T')[0] && 
                  (i.operateur === operateurActif || !i.operateur)
                ).length}
              </div>
              <button 
                onClick={() => setOngletActif('interventions')}
                className="mt-2 text-sm text-blue-600 hover:underline"
              >
                Gérer interventions →
              </button>
            </div>

            {/* Articles en alerte */}
            <div className="bg-orange-50 border-2 border-orange-300 p-4 rounded-xl">
              <h3 className="font-bold text-orange-700 mb-2">⚠️ Articles critiques</h3>
              <div className="text-3xl font-black text-orange-600">
                {alertesCritiques.length}
              </div>
              <button 
                onClick={() => setOngletActif('alertes')}
                className="mt-2 text-sm text-orange-600 hover:underline"
              >
                Voir les alertes →
              </button>
            </div>
          </div>

          {/* STATISTIQUES PERSONNELLES */}
          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-300 p-6 rounded-xl mb-6">
            <h3 className="text-xl font-black text-purple-700 mb-4">📊 MES STATISTIQUES DU MOIS</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-lg border-2 border-purple-200">
                <p className="text-xs text-gray-600 font-bold">INTERVENTIONS RÉALISÉES</p>
                <p className="text-2xl font-black text-purple-600">
                  {interventions.filter(i => 
                    i.operateur === operateurActif && 
                    i.statut === 'effectue'
                  ).length}
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg border-2 border-green-200">
                <p className="text-xs text-gray-600 font-bold">DÉFAUTS SIGNALÉS</p>
                <p className="text-2xl font-black text-green-600">
                  {defauts.filter(d => d.operateur === operateurActif).length}
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg border-2 border-blue-200">
                <p className="text-xs text-gray-600 font-bold">DÉFAUTS RÉSOLUS</p>
                <p className="text-2xl font-black text-blue-600">
                  {defauts.filter(d => 
                    d.operateur === operateurActif && 
                    d.statut === 'resolu'
                  ).length}
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg border-2 border-orange-200">
                <p className="text-xs text-gray-600 font-bold">TAUX RÉSOLUTION</p>
                <p className="text-2xl font-black text-orange-600">
                  {defauts.filter(d => d.operateur === operateurActif).length > 0
                    ? Math.round(
                        (defauts.filter(d => d.operateur === operateurActif && d.statut === 'resolu').length / 
                         defauts.filter(d => d.operateur === operateurActif).length) * 100
                      )
                    : 0}%
                </p>
              </div>
            </div>
          </div>

          {/* RACCOURCIS RAPIDES */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button 
              onClick={() => {setOngletActif('maintenance'); setNouveauDefaut(prev => ({...prev, operateur: operateurActif}));}}
              className="bg-red-500 hover:bg-red-600 text-white p-4 rounded-xl font-bold"
            >
              🚨 Signaler défaut
            </button>
            
            <button 
              onClick={() => setOngletActif('interventions')}
              className="bg-blue-500 hover:bg-blue-600 text-white p-4 rounded-xl font-bold"
            >
              🔧 Nouvelle intervention
            </button>
            
            <button 
              onClick={() => setOngletActif('stock')}
              className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-xl font-bold"
            >
              📤 Sortie stock
            </button>
            
            <button 
              onClick={() => setOngletActif('fiche')}
              className="bg-purple-500 hover:bg-purple-600 text-white p-4 rounded-xl font-bold"
            >
              📋 Fiches matériel
            </button>
          </div>

          {/* STATS GLOBALES EN BAS */}
          <div className="mt-6 grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="bg-blue-50 p-4 rounded border border-blue-200">
              <div className="text-3xl font-bold text-blue-600">{articles.length}</div>
              <div className="text-sm">Articles</div>
            </div>
            <div className="bg-green-50 p-4 rounded border border-green-200">
              <div className="text-3xl font-bold text-green-600">{articles.reduce((s,a)=>s+getStockTotal(a),0)}</div>
              <div className="text-sm">Pièces total</div>
            </div>
            <div className="bg-indigo-50 p-4 rounded border border-indigo-200">
              <div className="text-2xl font-bold text-indigo-600">{valeurStockTotal.toFixed(0)}€</div>
              <div className="text-sm">Valeur stock</div>
            </div>
            <div className="bg-purple-50 p-4 rounded border border-purple-200">
              <div className="text-3xl font-bold text-purple-600">{equipements.length}</div>
              <div className="text-sm">Équipements</div>
            </div>
            <div className="bg-orange-50 p-4 rounded border border-orange-200">
              <div className="text-3xl font-bold text-orange-600">{interventionsEnCours.length}</div>
              <div className="text-sm">Interv. en cours</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Accueil;
