// Module INTERVENTIONS - Solaire Nettoyage V3.0
// Gestion complète des interventions terrain
// MODIFIÉ : Ajout édition et suppression d'interventions
import React, { useEffect, useCallback } from 'react';

const Interventions = ({
  interventions,
  setInterventions,
  equipements,
  articles,
  setArticles,
  depots,
  accessoiresEquipement,
  nouvelleIntervention,
  setNouvelleIntervention,
  nouvelArticleIntervention,
  setNouvelArticleIntervention,
  afficherArticlesEquipement,
  setAfficherArticlesEquipement,
  afficherScannerIntervention,
  setAfficherScannerIntervention,
  scanResultatIntervention,
  setScanResultatIntervention,
  quantiteScanIntervention,
  setQuantiteScanIntervention,
  updateArticles,
  updateInterventions,
  mouvementsStock,
  updateMouvements,
  videoIntervention,
  canvasIntervention,
  scanningIntervention,
  jsQRRef,
  // NOUVELLES PROPS POUR ÉDITION/SUPPRESSION
  interventionEnEdition,
  modeEditionIntervention,
  ouvrirEditionIntervention,
  modifierIntervention,
  annulerEditionIntervention,
  supprimerIntervention
}) => {


  // ÉTAT - RECHERCHE INTELLIGENTE ARTICLES
  const [rechercheArticles, setRechercheArticles] = React.useState('');

  // ÉTAT - MODAL DÉTAILS
  const [interventionEnDetails, setInterventionEnDetails] = React.useState(null);

  // ÉTATS - TYPES PERSONNALISÉS
  const [typesInterventionPersonnalises, setTypesInterventionPersonnalises] = React.useState(() => {
    const saved = localStorage.getItem('typesInterventionPersonnalises');
    return saved ? JSON.parse(saved) : [];
  });
  const [nouveauTypeInterventionEnCours, setNouveauTypeInterventionEnCours] = React.useState(false);
  const [nouveauTypeInterventionTexte, setNouveauTypeInterventionTexte] = React.useState('');

  // Types d'intervention par défaut
  const typesInterventionParDefaut = [
    'Vidange moteur', 
    'Révision complète', 
    'Changement pneus', 
    'Nettoyage', 
    'Maintenance', 
    'Contrôle hydraulique', 
    'Réparation', 
    'Autre'
  ];
  const typesIntervention = [...typesInterventionParDefaut, ...typesInterventionPersonnalises];

  // FONCTION - AJOUTER UN TYPE D'INTERVENTION PERSONNALISÉ
  const ajouterTypeInterventionPersonnalise = () => {
    if (!nouveauTypeInterventionTexte.trim()) {
      alert('⚠️ Veuillez saisir un type d\'intervention');
      return;
    }
    
    const typeNormalise = nouveauTypeInterventionTexte.trim();
    
    // Vérifier si le type existe déjà
    if (typesIntervention.includes(typeNormalise)) {
      alert('⚠️ Ce type d\'intervention existe déjà');
      return;
    }
    
    // Ajouter à la liste
    const nouveauxTypes = [...typesInterventionPersonnalises, typeNormalise];
    setTypesInterventionPersonnalises(nouveauxTypes);
    localStorage.setItem('typesInterventionPersonnalises', JSON.stringify(nouveauxTypes));
    
    // Mettre à jour l'intervention avec ce nouveau type
    setNouvelleIntervention({...nouvelleIntervention, type: typeNormalise});
    
    // Réinitialiser
    setNouveauTypeInterventionEnCours(false);
    setNouveauTypeInterventionTexte('');
    
    alert('✅ Type d\'intervention ajouté !');
  };

  // FONCTION GET ÉQUIPEMENTS ET SUNBRUSH
  const getEquipementsEtSunbrush = () => {
    const liste = equipements.map(eq => ({
      id: eq.id,
      nom: `${eq.immat} - ${eq.marque} ${eq.modele}`,
      type: 'equipement'
    }));
    
    Object.entries(accessoiresEquipement).forEach(([eqId, accs]) => {
      accs.forEach(acc => {
        if (acc.actif) {
          // Chercher l'équipement parent (tester string et number)
          const parentEq = equipements.find(e => e.id === parseInt(eqId) || e.id.toString() === eqId || e.immat === eqId);
          liste.push({
            id: parseInt(eqId),
            nom: `${acc.nom} (sur ${parentEq?.immat || 'équipement introuvable'})`,
            type: 'accessoire',
            accessoireId: acc.id
          });
        }
      });
    });
    
    return liste;
  };

  // FONCTION GET ARTICLES DISPONIBLES
  const getArticlesDisponiblesCallback = useCallback(() => {
    if (afficherArticlesEquipement && nouvelleIntervention.equipementId) {
      const selectedId = parseInt(nouvelleIntervention.equipementId);
      if (selectedId === 999) {
        return articles.filter(a => 
          (a.equipementsAffectes || []).includes(6) || 
          (a.equipementsAffectes || []).includes(999)
        );
      }
      return articles.filter(a => 
        (a.equipementsAffectes || []).includes(selectedId)
      );
    }
    return articles;
  }, [articles, afficherArticlesEquipement, nouvelleIntervention.equipementId]);

  const getArticlesDisponibles = () => {
    return getArticlesDisponiblesCallback();
  };

  // FONCTION - FILTRAGE INTELLIGENT ARTICLES
  const filtrerArticlesDisponibles = () => {
    const articlesBase = getArticlesDisponibles();
    if (!rechercheArticles.trim()) return articlesBase;
    
    const mots = rechercheArticles.toLowerCase().trim().split(/\s+/);
    
    return articlesBase.filter(a => {
      const contenu = [
        a.code,
        a.description,
        a.fournisseur || ''
      ].join(' ').toLowerCase();
      
      return mots.every(mot => contenu.includes(mot));
    });
  };

  // FONCTION TRAITER SCAN QR INTERVENTION
  const traiterScanQRIntervention = useCallback((code) => {
    const article = getArticlesDisponiblesCallback().find(a => a.code === code);
    if (article) {
      setScanResultatIntervention({ article, code });
    } else {
      alert(`Article non trouvé: ${code}`);
    }
  }, [getArticlesDisponiblesCallback, setScanResultatIntervention]);

  // SCANNER QR INTERVENTION EFFECT
  useEffect(() => {
    if (!afficherScannerIntervention || !videoIntervention.current || !canvasIntervention.current || scanningIntervention.current) return;

    const loadJsQR = async () => {
      if (!jsQRRef.current) {
        try {
          const module = await import('jsqr');
          jsQRRef.current = module.default;
          console.log('✅ jsQR chargé pour interventions');
        } catch (err) {
          console.error('❌ Erreur chargement jsQR:', err);
          return;
        }
      }

      navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
        .then(stream => {
          videoIntervention.current.srcObject = stream;
          videoIntervention.current.play();
          scanningIntervention.current = true;
          scanQRIntervention();
        })
        .catch(err => {
          console.error("❌ Erreur caméra:", err);
          alert("Impossible d'accéder à la caméra");
        });
    };

    const scanQRIntervention = () => {
      if (!videoIntervention.current || !canvasIntervention.current || !scanningIntervention.current) return;
      
      if (videoIntervention.current.readyState === videoIntervention.current.HAVE_ENOUGH_DATA) {
        const canvas = canvasIntervention.current;
        const context = canvas.getContext('2d');
        canvas.height = videoIntervention.current.videoHeight;
        canvas.width = videoIntervention.current.videoWidth;
        context.drawImage(videoIntervention.current, 0, 0, canvas.width, canvas.height);
        
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQRRef.current(imageData.data, imageData.width, imageData.height);
        
        if (code) {
          console.log('📱 QR Code détecté:', code.data);
          traiterScanQRIntervention(code.data);
        }
      }
      
      if (scanningIntervention.current) {
        requestAnimationFrame(scanQRIntervention);
      }
    };

    loadJsQR();

    return () => {
      if (videoIntervention.current && videoIntervention.current.srcObject) {
        videoIntervention.current.srcObject.getTracks().forEach(track => track.stop());
        scanningIntervention.current = false;
      }
    };
  }, [afficherScannerIntervention, traiterScanQRIntervention, videoIntervention, canvasIntervention, scanningIntervention, jsQRRef]);

  // FONCTION TOGGLE SCANNER INTERVENTION
  const toggleScannerIntervention = () => {
    if (afficherScannerIntervention && videoIntervention.current && videoIntervention.current.srcObject) {
      videoIntervention.current.srcObject.getTracks().forEach(track => track.stop());
      scanningIntervention.current = false;
    }
    setAfficherScannerIntervention(!afficherScannerIntervention);
  };

  // FONCTION AJOUTER ARTICLE SCANNÉ
  const ajouterArticleScanne = () => {
    if (!scanResultatIntervention || !quantiteScanIntervention) {
      alert('Scannez un article et indiquez une quantité');
      return;
    }

    const article = scanResultatIntervention.article;
    const quantite = parseInt(quantiteScanIntervention);
    
    if ((article.stockParDepot[nouvelleIntervention.depotPrelevement] || 0) < quantite) {
      alert('Stock insuffisant dans ce dépôt');
      return;
    }

    setNouvelleIntervention({
      ...nouvelleIntervention,
      articlesPrevu: [...nouvelleIntervention.articlesPrevu, {
        articleId: article.id,
        quantite,
        prixUnitaire: article.prixUnitaire,
        description: article.description,
        code: article.code,
        articleScanned: true
      }]
    });

    setScanResultatIntervention(null);
    setQuantiteScanIntervention('');
  };

  // FONCTION AJOUTER ARTICLE MANUEL
  const ajouterArticlePrevu = () => {
    if (nouvelArticleIntervention.articleId && nouvelArticleIntervention.quantite) {
      const article = articles.find(a => a.id === parseInt(nouvelArticleIntervention.articleId));
      const quantite = parseInt(nouvelArticleIntervention.quantite);
      if ((article.stockParDepot[nouvelleIntervention.depotPrelevement] || 0) < quantite) { 
        alert('Stock insuffisant'); 
        return; 
      }
      const nouvelArticle = { 
        articleId: parseInt(nouvelArticleIntervention.articleId), 
        quantite, 
        prixUnitaire: article.prixUnitaire, 
        description: article.description, 
        code: article.code 
      };
      console.log('➕ Article ajouté:', nouvelArticle);
      console.log('📦 Article trouvé dans base:', article);
      
      setNouvelleIntervention({
        ...nouvelleIntervention, 
        articlesPrevu: [...nouvelleIntervention.articlesPrevu, nouvelArticle]
      });
      setNouvelArticleIntervention({ articleId: '', quantite: '' });
    }
  };

  // FONCTION SUPPRIMER ARTICLE PRÉVU
  const supprimerArticlePrevu = (index) => {
    setNouvelleIntervention({
      ...nouvelleIntervention, 
      articlesPrevu: nouvelleIntervention.articlesPrevu.filter((_, i) => i !== index)
    });
  };

  // FONCTION CRÉER INTERVENTION (modifiée pour gérer aussi l'édition)
  const creerIntervention = () => {
    if (modeEditionIntervention) {
      // Mode édition : utiliser la fonction de modification
      modifierIntervention();
    } else {
      // Mode création : logique existante
      if (!nouvelleIntervention.equipementId || !nouvelleIntervention.type) { 
        alert('Veuillez sélectionner un équipement et un type'); 
        return; 
      }
      
      const interventionId = interventions.length > 0 ? Math.max(...interventions.map(i => i.id)) + 1 : 1;
      const coutTotal = nouvelleIntervention.articlesPrevu.reduce((sum, art) => sum + (art.quantite * art.prixUnitaire), 0);
      
      let nouvelStock = articles;
      // CORRECTION : Décompter le stock pour TOUS les articles (scannés ET manuels)
      nouvelleIntervention.articlesPrevu.forEach(art => {
        nouvelStock = nouvelStock.map(a => a.id === art.articleId ? { 
          ...a, 
          stockParDepot: { 
            ...a.stockParDepot, 
            [nouvelleIntervention.depotPrelevement]: (a.stockParDepot[nouvelleIntervention.depotPrelevement] || 0) - art.quantite 
          } 
        } : a);
      });
      
      updateArticles(nouvelStock);
      
      // CRÉER LES MOUVEMENTS DE STOCK pour l'historique
      const nouveauxMouvements = [...mouvementsStock];
      const maxIdMouv = nouveauxMouvements.length > 0 ? Math.max(...nouveauxMouvements.map(m => m.id)) : 0;
      
      nouvelleIntervention.articlesPrevu.forEach((art, index) => {
        const article = articles.find(a => a.id === art.articleId);
        nouveauxMouvements.push({
          id: maxIdMouv + index + 1,
          articleId: art.articleId,
          code: art.code,
          description: article?.description || art.description,
          type: 'sortie',
          quantite: art.quantite,
          depot: nouvelleIntervention.depotPrelevement,
          date: nouvelleIntervention.date,
          raison: `Intervention: ${nouvelleIntervention.type}`,
          coutUnitaire: art.prixUnitaire,
          coutTotal: art.quantite * art.prixUnitaire
        });
      });
      
      updateMouvements(nouveauxMouvements);
      
      updateInterventions([...interventions, { 
        id: interventionId, 
        equipementId: parseInt(nouvelleIntervention.equipementId), 
        type: nouvelleIntervention.type, 
        date: nouvelleIntervention.date, 
        km: parseInt(nouvelleIntervention.km) || 0, 
        heures: parseInt(nouvelleIntervention.heures) || 0, 
        description: nouvelleIntervention.description, 
        travauxEffectues: nouvelleIntervention.travauxEffectues || '',
        articles: nouvelleIntervention.articlesPrevu, 
        statut: 'en_cours', 
        coutTotal, 
        depotPrelevement: nouvelleIntervention.depotPrelevement 
      }]);
      
      setNouvelleIntervention({ 
        equipementId: '', 
        type: '', 
        date: new Date().toISOString().split('T')[0], 
        km: '', 
        heures: '', 
        description: '', 
        travauxEffectues: '',
        articlesPrevu: [], 
        depotPrelevement: 'Atelier' 
      });
      
      // Réinitialiser les états du nouveau type
      setNouveauTypeInterventionEnCours(false);
      setNouveauTypeInterventionTexte('');
      
      alert('✅ Intervention créée avec succès!');
    }
  };

  // FONCTION CLÔTURER INTERVENTION
  const cloturerIntervention = (interventionId) => {
    updateInterventions(interventions.map(i => 
      i.id === interventionId ? { ...i, statut: 'effectue' } : i
    ));
    alert('✅ Intervention terminée!');
  };

  const interventionsEnCours = interventions.filter(i => i.statut === 'en_cours');
  const interventionsEffectuees = interventions.filter(i => i.statut === 'effectue');

  return (
    <div className="space-y-4">
      {/* FORMULAIRE CRÉATION/ÉDITION INTERVENTION */}
      <div className="bg-white p-4 rounded border">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-bold text-lg">
            {modeEditionIntervention ? '✏️ Modifier intervention' : '🔧 Créer intervention'}
          </h3>
          {modeEditionIntervention && (
            <button
              onClick={annulerEditionIntervention}
              className="bg-gray-500 text-white px-4 py-2 rounded font-bold hover:bg-gray-600"
            >
              ❌ Annuler
            </button>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-2">
          <select 
            value={nouvelleIntervention.equipementId} 
            onChange={(e) => setNouvelleIntervention({...nouvelleIntervention, equipementId: e.target.value})} 
            className="border-2 rounded px-2 py-2"
          >
            <option value="">Équipement *</option>
            {getEquipementsEtSunbrush().map(item => 
              <option key={`${item.id}-${item.accessoireId || ''}`} value={item.id}>
                {item.nom}
              </option>
            )}
          </select>
          
          <div>
            <select 
              value={nouveauTypeInterventionEnCours ? '➕_NOUVEAU' : nouvelleIntervention.type} 
              onChange={(e) => {
                if (e.target.value === '➕_NOUVEAU') {
                  setNouveauTypeInterventionEnCours(true);
                  setNouvelleIntervention({...nouvelleIntervention, type: ''});
                } else {
                  setNouveauTypeInterventionEnCours(false);
                  setNouvelleIntervention({...nouvelleIntervention, type: e.target.value});
                }
              }} 
              className="border-2 rounded px-2 py-2 w-full"
            >
              <option value="">Type *</option>
              {typesIntervention.map(t => 
                <option key={t} value={t}>{t}</option>
              )}
              <option value="➕_NOUVEAU">➕ Nouveau type...</option>
            </select>
            
            {/* CHAMP POUR NOUVEAU TYPE */}
            {nouveauTypeInterventionEnCours && (
              <div className="mt-2 p-2 bg-blue-50 border-2 border-blue-400 rounded">
                <label className="block text-xs font-bold text-blue-700 mb-1">Nouveau type :</label>
                <input
                  type="text"
                  value={nouveauTypeInterventionTexte}
                  onChange={(e) => setNouveauTypeInterventionTexte(e.target.value)}
                  placeholder="Ex: Graissage, Calibrage..."
                  className="w-full border-2 border-blue-300 rounded px-2 py-1 text-sm mb-1"
                  autoFocus
                />
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={ajouterTypeInterventionPersonnalise}
                    className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-bold hover:bg-blue-700"
                  >
                    ✓ Ajouter
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setNouveauTypeInterventionEnCours(false);
                      setNouveauTypeInterventionTexte('');
                      setNouvelleIntervention({...nouvelleIntervention, type: ''});
                    }}
                    className="bg-gray-400 text-white px-2 py-1 rounded text-xs font-bold hover:bg-gray-500"
                  >
                    ✗ Annuler
                  </button>
                </div>
              </div>
            )}
          </div>
          
          <input 
            type="date" 
            value={nouvelleIntervention.date} 
            onChange={(e) => setNouvelleIntervention({...nouvelleIntervention, date: e.target.value})} 
            className="border-2 rounded px-2 py-2" 
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-3">
          <input 
            type="number" 
            placeholder="KM" 
            value={nouvelleIntervention.km} 
            onChange={(e) => setNouvelleIntervention({...nouvelleIntervention, km: e.target.value})} 
            className="border-2 rounded px-2 py-2" 
          />
          
          <input 
            type="number" 
            placeholder="Heures" 
            value={nouvelleIntervention.heures} 
            onChange={(e) => setNouvelleIntervention({...nouvelleIntervention, heures: e.target.value})} 
            className="border-2 rounded px-2 py-2" 
          />
          
          <input 
            type="text" 
            placeholder="Description" 
            value={nouvelleIntervention.description} 
            onChange={(e) => setNouvelleIntervention({...nouvelleIntervention, description: e.target.value})} 
            className="border-2 rounded px-2 py-2" 
          />
          
          <textarea 
            placeholder="Travaux effectués / Réparation" 
            value={nouvelleIntervention.travauxEffectues || ''} 
            onChange={(e) => setNouvelleIntervention({...nouvelleIntervention, travauxEffectues: e.target.value})} 
            className="border-2 rounded px-2 py-2 min-h-[80px]" 
            rows="3"
          />
        </div>
        
        {/* DÉPÔT DE PRÉLÈVEMENT */}
        <div className="bg-purple-50 border-2 border-purple-300 p-3 rounded mb-3">
          <h4 className="font-semibold text-sm mb-2">🏠 Dépôt de prélèvement</h4>
          <select 
            value={nouvelleIntervention.depotPrelevement} 
            onChange={(e) => setNouvelleIntervention({...nouvelleIntervention, depotPrelevement: e.target.value})} 
            className="w-full border-2 border-purple-300 rounded px-3 py-2 mb-2"
          >
            {depots.map(d => 
              <option key={d} value={d}>{d}</option>
            )}
          </select>
        </div>
        
        {/* ARTICLES */}
        <div className="bg-blue-50 border-2 border-blue-300 p-3 rounded mb-3">
          <h4 className="font-semibold text-sm mb-2">📦 Articles</h4>
          
          <div className="mb-2 flex gap-2">
            <button 
              onClick={() => setAfficherArticlesEquipement(!afficherArticlesEquipement)} 
              className={`px-3 py-1 rounded text-xs font-bold ${
                afficherArticlesEquipement ? 'bg-blue-600 text-white' : 'bg-gray-300'
              }`}
            >
              {afficherArticlesEquipement ? 'Équipement' : 'Tous'}
            </button>
            
            <button 
              onClick={toggleScannerIntervention} 
              className={`px-3 py-1 rounded text-xs font-bold ${
                afficherScannerIntervention ? 'bg-red-600 text-white' : 'bg-indigo-600 text-white'
              }`}
            >
              {afficherScannerIntervention ? '❌ Fermer' : '📷 Scanner QR'}
            </button>
          </div>
          
          {/* SCANNER QR */}
          {afficherScannerIntervention && (
            <div className="bg-white rounded p-3 mb-3 border">
              <div className="text-center mb-2">
                <video ref={videoIntervention} className="w-full max-w-sm mx-auto rounded border" />
                <canvas ref={canvasIntervention} className="hidden" />
              </div>
              
              {scanResultatIntervention && (
                <div className="bg-green-50 p-3 rounded mb-2">
                  <div className="font-bold text-green-700">✅ Article scanné:</div>
                  <div className="text-sm">{scanResultatIntervention.article.code} - {scanResultatIntervention.article.description}</div>
                  <div className="text-xs text-gray-600">Stock dépôt: {scanResultatIntervention.article.stockParDepot[nouvelleIntervention.depotPrelevement] || 0}</div>
                  
                  <div className="flex gap-2 mt-2">
                    <input 
                      type="number" 
                      placeholder="Quantité" 
                      value={quantiteScanIntervention}
                      onChange={(e) => setQuantiteScanIntervention(e.target.value)}
                      className="border rounded px-2 py-1 flex-1"
                    />
                    <button 
                      onClick={ajouterArticleScanne} 
                      className="bg-green-600 text-white px-3 py-1 rounded text-sm font-bold"
                    >
                      + Ajouter
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* RECHERCHE INTELLIGENTE */}
          <div className="mb-2">
            <input
              type="text"
              placeholder="🔍 Rechercher article (code, description, fournisseur)..."
              value={rechercheArticles}
              onChange={(e) => setRechercheArticles(e.target.value)}
              className="w-full border-2 border-blue-300 rounded px-3 py-2 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {rechercheArticles && (
              <div className="text-xs text-blue-700 mt-1 font-medium">
                🎯 {filtrerArticlesDisponibles().length} article(s) trouvé(s)
              </div>
            )}
          </div>

          {/* SÉLECTION MANUELLE */}
          <div className="grid grid-cols-6 gap-2 mb-2">
            <select 
              value={nouvelArticleIntervention.articleId} 
              onChange={(e) => setNouvelArticleIntervention({...nouvelArticleIntervention, articleId: e.target.value})} 
              className="border-2 border-blue-300 rounded px-2 py-2 text-sm col-span-3"
            >
              <option value="">Article</option>
              {filtrerArticlesDisponibles().map(a => 
                <option key={a.id} value={a.id}>
                  {a.code} - {a.description.substring(0, 30)} ({a.stockParDepot[nouvelleIntervention.depotPrelevement] || 0})
                </option>
              )}
            </select>
            
            <input 
              type="number" 
              placeholder="Qté" 
              value={nouvelArticleIntervention.quantite} 
              onChange={(e) => setNouvelArticleIntervention({...nouvelArticleIntervention, quantite: e.target.value})} 
              className="border-2 border-blue-300 rounded px-2 py-2 text-sm"
            />
            
            <button 
              onClick={ajouterArticlePrevu} 
              className="bg-blue-600 text-white px-3 py-2 rounded text-sm font-bold col-span-2"
            >
              + Ajouter
            </button>
          </div>
          
          {/* ARTICLES PRÉVUS */}
          {nouvelleIntervention.articlesPrevu.length > 0 && (
            <div className="bg-white rounded p-2 mb-2 space-y-1 border">
              <div className="text-xs font-bold mb-2">Prévus:</div>
              {nouvelleIntervention.articlesPrevu.map((art, idx) => {
                const total = art.quantite * art.prixUnitaire;
                return (
                  <div key={idx} className="flex justify-between items-center text-xs bg-gray-50 p-2 rounded">
                    <div className="flex-1">
                      <div className="font-bold">{art.code}</div>
                      <div className="text-gray-700 text-xs">{art.description}</div>
                      <div className="text-gray-600">
                        {art.quantite}x @ {art.prixUnitaire.toFixed(2)}€ = <span className="font-bold text-blue-600">{total.toFixed(2)}€</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => supprimerArticlePrevu(idx)} 
                      className="text-red-600 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        
        <button 
          onClick={creerIntervention} 
          className={`w-full ${modeEditionIntervention ? 'bg-blue-500' : 'bg-orange-500'} text-white px-4 py-3 rounded font-bold text-lg`}
        >
          {modeEditionIntervention ? '✓ MODIFIER INTERVENTION' : '✓ CRÉER INTERVENTION'}
        </button>
      </div>

      {/* INTERVENTIONS EN COURS */}
      {interventionsEnCours.length > 0 && (
        <div>
          <h3 className="font-bold text-lg mb-2">⏳ En cours ({interventionsEnCours.length})</h3>
          {interventionsEnCours.map(i => {
            const eq = equipements.find(e => e.id === i.equipementId);
            return (
              <div key={i.id} className="bg-yellow-50 border-2 border-yellow-400 p-4 rounded mb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-lg">{i.type}</h4>
                    <p className="text-sm">{eq?.immat} - {i.date}</p>
                    {i.description && <p className="text-sm mt-1">📋 Problème: {i.description}</p>}
                    {i.travauxEffectues && (
                      <p className="text-sm mt-1 bg-green-50 border-l-4 border-green-500 pl-2 py-1">
                        ✅ Travaux: {i.travauxEffectues}
                      </p>
                    )}
                    {(i.articles || []).length > 0 && (
                      <p className="text-xs text-gray-600 mt-2">
                        {(i.articles || []).length} articles - {i.coutTotal.toFixed(2)}€
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => ouvrirEditionIntervention(i)} 
                      className="bg-blue-600 text-white px-3 py-2 rounded font-bold"
                    >
                      ✏️ Éditer
                    </button>
                    <button 
                      onClick={() => supprimerIntervention(i.id)} 
                      className="bg-red-600 text-white px-3 py-2 rounded font-bold"
                    >
                      🗑️
                    </button>
                    <button 
                      onClick={() => cloturerIntervention(i.id)} 
                      className="bg-green-600 text-white px-4 py-2 rounded font-bold"
                    >
                      Terminer
                    </button>
                    <button 
                      onClick={() => setInterventionEnDetails(i)} 
                      className="bg-purple-600 text-white px-3 py-2 rounded font-bold"
                    >
                      📋 Détails
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* INTERVENTIONS EFFECTUÉES */}
      {interventionsEffectuees.length > 0 && (
        <div>
          <h3 className="font-bold text-lg mb-2">✅ Effectuées ({interventionsEffectuees.length})</h3>
          {interventionsEffectuees.map(i => {
            const eq = equipements.find(e => e.id === i.equipementId);
            return (
              <div key={i.id} className="p-4 bg-green-50 rounded mb-3 border">
                <div className="flex justify-between">
                  <div>
                    <div className="font-bold text-lg">{i.type}</div>
                    <p className="text-sm">
                      <strong>{eq?.immat}</strong> • {i.date}
                      {i.km > 0 && ` • ${i.km} km`}
                      {i.heures > 0 && ` • ${i.heures} h`}
                    </p>
                    {i.description && <p className="text-sm mt-1">📋 Problème: {i.description}</p>}
                    {i.travauxEffectues && (
                      <p className="text-sm mt-1 bg-green-100 border-l-4 border-green-600 pl-2 py-1">
                        ✅ Travaux: {i.travauxEffectues}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-2xl font-black text-green-600">
                      {(i.coutTotal || 0).toFixed(2)}€
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => ouvrirEditionIntervention(i)} 
                        className="bg-blue-600 text-white px-3 py-2 rounded font-bold"
                      >
                        ✏️
                      </button>
                      <button 
                        onClick={() => supprimerIntervention(i.id)} 
                        className="bg-red-600 text-white px-3 py-2 rounded font-bold"
                      >
                        🗑️
                      </button>
                      <button 
                        onClick={() => setInterventionEnDetails(i)} 
                        className="bg-purple-600 text-white px-3 py-2 rounded font-bold"
                      >
                        📋
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL DÉTAILS INTERVENTION */}
      {interventionEnDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-2xl font-black text-purple-700">📋 DÉTAILS INTERVENTION</h2>
              <button onClick={() => setInterventionEnDetails(null)} className="text-2xl hover:text-red-600">✕</button>
            </div>
            
            <div className="space-y-4">
              {/* ÉQUIPEMENT */}
              <div className="bg-gray-50 p-3 rounded border-2">
                <p className="text-xs text-gray-600 font-bold">ÉQUIPEMENT</p>
                <p className="font-bold text-lg">
                  {equipements.find(e => e.id === interventionEnDetails.equipementId)?.immat || 'Non trouvé'}
                </p>
              </div>

              {/* TYPE ET STATUT */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-gray-600 font-bold">TYPE D'INTERVENTION</p>
                  <p className="font-semibold">{interventionEnDetails.type}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 font-bold">STATUT</p>
                  <p className="font-semibold">
                    {interventionEnDetails.statut === 'en_cours' ? '⏳ En cours' : '✅ Effectuée'}
                  </p>
                </div>
              </div>

              {/* DATE / KM / HEURES */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <p className="text-xs text-gray-600 font-bold">DATE</p>
                  <p className="font-semibold">{interventionEnDetails.date}</p>
                </div>
                {interventionEnDetails.km > 0 && (
                  <div>
                    <p className="text-xs text-gray-600 font-bold">KILOMÉTRAGE</p>
                    <p className="font-semibold">{interventionEnDetails.km} km</p>
                  </div>
                )}
                {interventionEnDetails.heures > 0 && (
                  <div>
                    <p className="text-xs text-gray-600 font-bold">HEURES</p>
                    <p className="font-semibold">{interventionEnDetails.heures} h</p>
                  </div>
                )}
              </div>

              {/* DÉPÔT DE PRÉLÈVEMENT */}
              {interventionEnDetails.depotPrelevement && (
                <div>
                  <p className="text-xs text-gray-600 font-bold">DÉPÔT DE PRÉLÈVEMENT</p>
                  <p className="font-semibold">{interventionEnDetails.depotPrelevement}</p>
                </div>
              )}

              {/* DESCRIPTION PROBLÈME */}
              {interventionEnDetails.description && (
                <div className="bg-red-50 p-3 rounded border-l-4 border-red-500">
                  <p className="text-xs text-gray-600 font-bold mb-1">📋 PROBLÈME CONSTATÉ</p>
                  <p className="text-sm">{interventionEnDetails.description}</p>
                </div>
              )}

              {/* TRAVAUX EFFECTUÉS */}
              {interventionEnDetails.travauxEffectues && (
                <div className="bg-green-50 p-3 rounded border-l-4 border-green-500">
                  <p className="text-xs text-gray-600 font-bold mb-1">✅ TRAVAUX EFFECTUÉS</p>
                  <p className="text-sm">{interventionEnDetails.travauxEffectues}</p>
                </div>
              )}

              {/* ARTICLES UTILISÉS */}
              {interventionEnDetails.articles && interventionEnDetails.articles.length > 0 && (
                <div className="border-t pt-4">
                  <p className="text-xs text-gray-600 font-bold mb-2">🔧 ARTICLES UTILISÉS</p>
                  <div className="space-y-2">
                    {interventionEnDetails.articles.map((art, idx) => {
                      const article = articles.find(a => a.id === art.articleId);
                      const prixUnitaire = art.prixUnitaire || 0;
                      const total = prixUnitaire * art.quantite;
                      return (
                        <div key={idx} className="flex justify-between items-center p-2 bg-gray-100 rounded">
                          <div className="flex-1">
                            <p className="font-semibold text-sm">{article?.code || 'N/A'}</p>
                            <p className="text-xs text-gray-600">{article?.description || 'Article non trouvé'}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-sm">
                              {prixUnitaire.toFixed(2)}€ × {art.quantite} = {total.toFixed(2)}€
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* COÛTS */}
              <div className="bg-blue-50 p-4 rounded border-2 border-blue-300">
                <div className="flex justify-between">
                  <span className="font-bold text-lg">TOTAL:</span>
                  <span className="text-3xl font-black text-blue-600">
                    {interventionEnDetails.coutTotal?.toFixed(2) || '0.00'}€
                  </span>
                </div>
              </div>

              <button 
                onClick={() => setInterventionEnDetails(null)} 
                className="w-full bg-gray-600 text-white px-4 py-2 rounded font-bold hover:bg-gray-700"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Interventions;