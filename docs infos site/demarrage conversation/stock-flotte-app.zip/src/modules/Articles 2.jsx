// Module ARTICLES - Solaire Nettoyage V3.1+
// AMÉLIORATIONS : Recherche intelligente + Actions rapides Stock + Modal après création
import React from 'react';

const Articles = ({
  articles,
  setArticles,
  modeEditionArticle,
  setModeEditionArticle,
  articleFormEnEdition,
  setArticleFormEnEdition,
  afficherFormulaireArticle,
  setAfficherFormulaireArticle,
  nouvelArticleForm,
  setNouvelArticleForm,
  getStockTotal,
  updateArticles,
  database,
  ref,
  set,
  supprimerArticle,
  setOngletActif,
  setArticlePreselectionne,
  mouvementsStock
}) => {

  // ÉTATS - RECHERCHE INTELLIGENTE
  const [rechercheArticles, setRechercheArticles] = React.useState('');
  const [articleHistorique, setArticleHistorique] = React.useState(null);
  
  // NOUVEAUX ÉTATS - ACTIONS RAPIDES
  const [articleDeplie, setArticleDeplie] = React.useState(null);
  const [afficherModalCreation, setAfficherModalCreation] = React.useState(false);
  const [articleCree, setArticleCree] = React.useState(null);

  // ÉTATS - PHOTOS ARTICLES
  const [photoAgrandie, setPhotoAgrandie] = React.useState(null);

  const ouvrirHistorique = (article) => { setArticleHistorique(article); };

  // FONCTION - GÉRER SÉLECTION PHOTO ARTICLE
  const gererSelectionPhoto = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('⚠️ Veuillez sélectionner une image');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setNouvelArticleForm({
        ...nouvelArticleForm,
        photo: event.target.result
      });
    };
    reader.readAsDataURL(file);
  };

  // FONCTION - FILTRAGE INTELLIGENT MULTI-MOTS
  const filtrerArticles = () => {
    if (!rechercheArticles.trim()) return articles;
    
    const mots = rechercheArticles.toLowerCase().trim().split(/\s+/);
    
    return articles.filter(a => {
      const contenu = [
        a.code,
        a.description,
        a.fournisseur || ''
      ].join(' ').toLowerCase();
      
      return mots.every(mot => contenu.includes(mot));
    });
  };

  // NOUVELLE FONCTION - NAVIGUER VERS STOCK AVEC ARTICLE
  const allerVersStock = (article, action) => {
    if (setArticlePreselectionne && setOngletActif) {
      setArticlePreselectionne({ article, action }); // action = 'entree', 'sortie', ou 'transfert'
      setOngletActif('stock');
    }
  };

  // ✅ FONCTION CRÉER/MODIFIER ARTICLE - AVEC MODAL
  const creerOuModifierArticle = async () => {
    if (!nouvelArticleForm.code || !nouvelArticleForm.description) {
      alert('⚠️ Code et Description sont obligatoires!');
      return;
    }

    const codeExiste = articles.some(a => 
      a.code === nouvelArticleForm.code && 
      (!modeEditionArticle || a.id !== articleFormEnEdition.id)
    );
    
    if (codeExiste) {
      alert('⚠️ Ce code article existe déjà !');
      return;
    }

    if (modeEditionArticle) {
      // MODE ÉDITION
      const articlesModifies = articles.map(a => 
        a.id === articleFormEnEdition.id ? {
          id: a.id,
          code: nouvelArticleForm.code,
          description: nouvelArticleForm.description,
          fournisseur: nouvelArticleForm.fournisseur || '',
          prixUnitaire: parseFloat(nouvelArticleForm.prixUnitaire) || 0,
          stockParDepot: a.stockParDepot,
          stockMin: parseInt(nouvelArticleForm.stockMin) || 0,
          equipementsAffectes: a.equipementsAffectes || [],
          photo: nouvelArticleForm.photo || a.photo || ''
        } : a
      );
      
      for (const article of articlesModifies) {
        await set(ref(database, 'articles/' + article.id), article);
      }
      alert('✅ Article modifié avec succès!');
      
    } else {
      // MODE CRÉATION - AVEC MODAL
      let nouvelId = 1;
      
      if (articles && articles.length > 0) {
        const maxId = Math.max(...articles.map(a => {
          const id = parseInt(a.id);
          return isNaN(id) ? 0 : id;
        }));
        nouvelId = maxId + 1;
      }
      
      if (isNaN(nouvelId)) {
        nouvelId = Date.now();
      }
      
      const nouvelArticle = {
        id: nouvelId,
        code: nouvelArticleForm.code,
        description: nouvelArticleForm.description,
        fournisseur: nouvelArticleForm.fournisseur || '',
        prixUnitaire: parseFloat(nouvelArticleForm.prixUnitaire) || 0,
        stockParDepot: { 
          'Atelier': 0, 
          'Porteur 26 T': 0, 
          'Porteur 32 T': 0, 
          'Semi Remorque': 0 
        },
        stockMin: parseInt(nouvelArticleForm.stockMin) || 0,
        equipementsAffectes: [],
        photo: nouvelArticleForm.photo || ''
      };

      try {
        await set(ref(database, 'articles/' + nouvelId), nouvelArticle);
        
        // AFFICHER MODAL AU LIEU DE L'ALERT
        setArticleCree(nouvelArticle);
        setAfficherModalCreation(true);
        
      } catch (error) {
        console.error('Erreur création article:', error);
        alert('❌ Erreur lors de la création!');
      }
    }

    // Réinitialiser formulaire
    setNouvelArticleForm({
      code: '',
      description: '',
      fournisseur: '',
      prixUnitaire: 0,
      stockMin: 0,
      photo: ''
    });

    setArticleFormEnEdition(null);
    setModeEditionArticle(false);
    setAfficherFormulaireArticle(false);
  };

  // ✅ FONCTION OUVRIR ÉDITION ARTICLE
  const ouvrirEditionArticle = (article) => {
    setArticleFormEnEdition(article);
    setModeEditionArticle(true);
    setNouvelArticleForm({
      code: article.code,
      description: article.description,
      fournisseur: article.fournisseur,
      prixUnitaire: article.prixUnitaire,
      stockMin: article.stockMin,
      photo: article.photo || ''
    });
    setAfficherFormulaireArticle(true);
  };

  // ✅ FONCTION ANNULER ÉDITION ARTICLE
  const annulerEditionArticle = () => {
    setArticleFormEnEdition(null);
    setModeEditionArticle(false);
    setNouvelArticleForm({
      code: '',
      description: '',
      fournisseur: '',
      prixUnitaire: 0,
      stockMin: 0,
      photo: ''
    });
    setAfficherFormulaireArticle(false);
  };

  // ✅ FONCTION GÉNÉRER PDF QR CODES (basée sur la recherche)
  const genererQRCodesPDF = () => {
    // Utiliser les articles FILTRÉS par la recherche
    const articlesAGenerer = filtrerArticles();
    
    // Vérifier qu'il y a des articles
    if (!articlesAGenerer || articlesAGenerer.length === 0) {
      alert('❌ Aucun article à générer !\n\nAstuce : Vide la recherche pour générer tous les articles.');
      return;
    }

    try {
      // Créer un canvas temporaire pour générer les QR codes
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 200;
      canvas.height = 200;

      // Préparer le contenu HTML pour le PDF
      let htmlContent = `
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .qr-container { 
              display: inline-block; 
              width: 250px; 
              margin: 20px; 
              text-align: center; 
              page-break-inside: avoid;
              border: 2px solid #333;
              padding: 15px;
            }
            .qr-code { 
              width: 150px; 
              height: 150px; 
              margin: 0 auto;
              background: white;
            }
            .article-info { 
              margin-top: 10px; 
              font-size: 12px;
            }
            .article-code { 
              font-weight: bold; 
              font-size: 16px;
              margin-bottom: 5px;
            }
            .article-desc { 
              color: #666; 
              font-size: 11px;
            }
            @media print {
              .qr-container { page-break-inside: avoid; }
            }
          </style>
        </head>
        <body>
          <h1 style="text-align: center;">QR Codes - Articles Solaire Nettoyage</h1>
          <p style="text-align: center;">Date: ${new Date().toLocaleDateString('fr-FR')}</p>
          <div style="display: flex; flex-wrap: wrap; justify-content: center;">
      `;

      // Générer un QR code pour chaque article filtré
      articlesAGenerer.forEach(article => {
        // Utiliser un service en ligne pour générer le QR code (Google Charts API)
        const qrData = encodeURIComponent(article.code);
        const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${qrData}`;
        
        htmlContent += `
          <div class="qr-container">
            <img src="${qrUrl}" class="qr-code" alt="QR Code ${article.code}">
            <div class="article-info">
              <div class="article-code">${article.code}</div>
              <div class="article-desc">${article.description}</div>
              <div class="article-desc" style="color: #999; margin-top: 5px;">Stock min: ${article.stockMin}</div>
            </div>
          </div>
        `;
      });

      htmlContent += `
          </div>
        </body>
        </html>
      `;

      // Ouvrir dans une nouvelle fenêtre pour impression
      const printWindow = window.open('', '_blank');
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      
      // Attendre que les images soient chargées puis proposer l'impression
      setTimeout(() => {
        printWindow.focus();
        printWindow.print();
      }, 1500);

      alert(`✅ PDF généré avec ${articlesAGenerer.length} QR code(s) !\n\nUne nouvelle fenêtre s'ouvre pour l'impression.`);

    } catch (error) {
      console.error('Erreur génération QR codes:', error);
      alert('❌ Erreur lors de la génération des QR codes!');
    }
  };

  const articlesFiltres = filtrerArticles();

  return (
    <div className="space-y-6">
      {/* MODAL APRÈS CRÉATION */}
      {afficherModalCreation && articleCree && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-8 rounded-xl shadow-2xl max-w-md w-full mx-4">
            <div className="text-center">
              <div className="text-6xl mb-4">✅</div>
              <h3 className="text-2xl font-black text-green-600 mb-2">Article créé avec succès !</h3>
              <div className="bg-purple-50 p-4 rounded-lg mb-6 border-2 border-purple-300">
                <div className="font-bold text-lg text-purple-700">{articleCree.code}</div>
                <div className="text-sm text-gray-700 mt-1">{articleCree.description}</div>
              </div>
              
              <p className="text-gray-700 mb-6 font-medium">Que voulez-vous faire maintenant ?</p>
              
              <div className="space-y-3">
                <button 
                  onClick={() => {
                    allerVersStock(articleCree, 'entree');
                    setAfficherModalCreation(false);
                  }}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-4 rounded-lg font-bold text-lg hover:from-green-600 hover:to-green-700 transition flex items-center justify-center gap-2"
                >
                  📥 Ajouter du stock dans ce nouvel article
                </button>
                
                <button 
                  onClick={() => {
                    setAfficherModalCreation(false);
                    setAfficherFormulaireArticle(true);
                  }}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-4 rounded-lg font-bold text-lg hover:from-purple-600 hover:to-pink-600 transition flex items-center justify-center gap-2"
                >
                  📝 Créer un autre article
                </button>
                
                <button 
                  onClick={() => setAfficherModalCreation(false)}
                  className="w-full bg-gray-500 text-white px-6 py-4 rounded-lg font-bold text-lg hover:bg-gray-600 transition"
                >
                  ✓ Terminer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FORMULAIRE CRÉATION/ÉDITION */}
      <div className="bg-white p-4 rounded border">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-black text-xl">
            {modeEditionArticle ? '✏️ MODIFIER ARTICLE' : '➕ CRÉER UN NOUVEL ARTICLE'}
          </h2>
          <button 
            onClick={() => setAfficherFormulaireArticle(!afficherFormulaireArticle)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded font-bold hover:from-purple-700 hover:to-pink-700 transition"
          >
            {afficherFormulaireArticle ? '❌ Fermer' : '➕ Nouveau'}
          </button>
        </div>
        
        {afficherFormulaireArticle && (
          <div className="space-y-4 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border-2 border-purple-300">
            {/* SECTION 1 - IDENTITÉ */}
            <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-300">
              <h4 className="font-bold text-yellow-700 mb-3">📦 IDENTITÉ ARTICLE</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-700">Code article *</label>
                  <input 
                    type="text" 
                    placeholder="Ex: BAC5X5" 
                    value={nouvelArticleForm.code}
                    onChange={(e) => setNouvelArticleForm({...nouvelArticleForm, code: e.target.value})}
                    className="w-full border-2 border-yellow-300 rounded px-3 py-2 mt-1 font-bold text-lg"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Description *</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Barre pour clavette" 
                    value={nouvelArticleForm.description}
                    onChange={(e) => setNouvelArticleForm({...nouvelArticleForm, description: e.target.value})}
                    className="w-full border-2 border-yellow-300 rounded px-3 py-2 mt-1"
                  />
                </div>
              </div>
            </div>

            {/* SECTION 2 - INFOS COMMERCIALES */}
            <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-300">
              <h4 className="font-bold text-blue-700 mb-3">💰 INFOS COMMERCIALES</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-700">Fournisseur</label>
                  <input 
                    type="text" 
                    placeholder="Ex: LE BON ROULEMENT" 
                    value={nouvelArticleForm.fournisseur}
                    onChange={(e) => setNouvelArticleForm({...nouvelArticleForm, fournisseur: e.target.value})}
                    className="w-full border-2 border-blue-300 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Prix unitaire (€)</label>
                  <input 
                    type="number" 
                    step="0.01"
                    placeholder="0" 
                    value={nouvelArticleForm.prixUnitaire}
                    onChange={(e) => setNouvelArticleForm({...nouvelArticleForm, prixUnitaire: e.target.value})}
                    className="w-full border-2 border-blue-300 rounded px-3 py-2 mt-1"
                  />
                </div>
              </div>
            </div>

            {/* SECTION 3 - STOCK */}
            <div className="bg-green-50 p-4 rounded-lg border-2 border-green-300">
              <h4 className="font-bold text-green-700 mb-3">📊 STOCK</h4>
              <div className="grid grid-cols-1 md:grid-cols-1 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-700">Stock minimum</label>
                  <input 
                    type="number" 
                    placeholder="0" 
                    value={nouvelArticleForm.stockMin}
                    onChange={(e) => setNouvelArticleForm({...nouvelArticleForm, stockMin: e.target.value})}
                    className="w-full border-2 border-green-300 rounded px-3 py-2 mt-1"
                  />
                </div>
              </div>
            </div>

            {/* SECTION 4 - PHOTO */}
            <div className="bg-purple-50 p-4 rounded-lg border-2 border-purple-300">
              <h4 className="font-bold text-purple-700 mb-3">📸 PHOTO ARTICLE</h4>
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-gray-700">Ajouter une photo</label>
                  <input 
                    type="file" 
                    accept="image/*"
                    onChange={gererSelectionPhoto}
                    className="w-full border-2 border-purple-300 rounded px-3 py-2 mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">📱 Sur mobile: Prendre photo ou Choisir fichier</p>
                </div>
                {nouvelArticleForm.photo && (
                  <div className="flex gap-3 items-center">
                    <img 
                      src={nouvelArticleForm.photo} 
                      alt="Aperçu" 
                      className="w-24 h-24 object-cover rounded border-2 border-purple-400"
                    />
                    <button
                      type="button"
                      onClick={() => setNouvelArticleForm({...nouvelArticleForm, photo: ''})}
                      className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
                    >
                      🗑️ Supprimer photo
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* BOUTONS CRÉER/SAUVEGARDER */}
            <div className="flex gap-2">
              <button 
                onClick={creerOuModifierArticle}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-4 rounded-lg font-black text-lg hover:from-purple-700 hover:to-pink-700 transition"
              >
                {modeEditionArticle ? '💾 SAUVEGARDER MODIFICATIONS' : '✅ CRÉER ARTICLE'}
              </button>
              {modeEditionArticle && (
                <button 
                  onClick={annulerEditionArticle}
                  className="flex-1 bg-gray-500 text-white px-6 py-4 rounded-lg font-black text-lg hover:bg-gray-600 transition"
                >
                  ❌ ANNULER
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* LISTE DES ARTICLES AVEC RECHERCHE ET ACTIONS RAPIDES */}
      <div className="bg-white p-4 rounded border">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-black text-xl">📦 Articles ({articles.length})</h2>
          <button 
            onClick={genererQRCodesPDF} 
            className="bg-purple-600 text-white px-4 py-2 rounded font-bold hover:bg-purple-700 text-sm"
          >
            📋 QR Codes PDF ({filtrerArticles().length})
          </button>
        </div>

        {/* BARRE DE RECHERCHE INTELLIGENTE */}
        <div className="mb-4">
          <input 
            type="text" 
            placeholder="🔍 Rechercher article (code, description, fournisseur)..." 
            value={rechercheArticles}
            onChange={(e) => setRechercheArticles(e.target.value)}
            className="w-full border-2 border-purple-400 rounded-lg px-4 py-3 font-medium focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition"
          />
          {rechercheArticles && (
            <div className="text-sm text-purple-700 mt-2 font-medium flex items-center gap-2">
              🎯 {articlesFiltres.length} article(s) trouvé(s) sur {articles.length}
              {articlesFiltres.length === 0 && (
                <span className="text-red-600">• Aucun résultat</span>
              )}
            </div>
          )}
        </div>

        <div className="space-y-2">
          {articlesFiltres.length > 0 ? (
            articlesFiltres.map(a => (
              <div key={a.id} className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border-2 border-purple-200 hover:shadow-md transition">
                {/* EN-TÊTE ARTICLE AVEC FLÈCHE */}
                <div 
                  className="flex justify-between items-center p-3 cursor-pointer"
                  onClick={() => setArticleDeplie(articleDeplie === a.id ? null : a.id)}
                >
                  <div className="flex items-center gap-2 flex-1">
                    <span className="text-xl text-purple-600">
                      {articleDeplie === a.id ? '▼' : '▶'}
                    </span>
                    {a.photo && (
                      <img 
                        src={a.photo} 
                        alt={a.code}
                        onClick={(e) => {
                          e.stopPropagation();
                          setPhotoAgrandie(a.photo);
                        }}
                        className="w-12 h-12 object-cover rounded border-2 border-purple-400 cursor-pointer hover:scale-110 transition"
                      />
                    )}
                    <div className="flex-1">
                      <div className="font-bold text-purple-700">{a.code}</div>
                      <div className="text-sm text-gray-600">{a.description}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {a.fournisseur && <span>🏭 {a.fournisseur} • </span>}
                        <span>💰 {a.prixUnitaire}€ • </span>
                        <span>📊 Min: {a.stockMin} • </span>
                        <span className={getStockTotal(a) <= 2 ? 'text-red-600 font-bold' : 'text-green-600 font-bold'}>{getStockTotal(a)} pièces</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2 ml-2" onClick={(e) => e.stopPropagation()}>
                    <button 
                      onClick={() => ouvrirEditionArticle(a)}
                      className="bg-blue-600 text-white px-3 py-2 rounded font-bold text-sm hover:bg-blue-700 whitespace-nowrap"
                    >
                      ✏️ Éditer
                    </button>
                    <button 
                      onClick={() => supprimerArticle(a.id)}
                      className="bg-red-600 text-white px-3 py-2 rounded font-bold text-sm hover:bg-red-700 whitespace-nowrap"
                    >
                      🗑️ Supprimer
                    </button>
                    <button 
                      onClick={() => ouvrirHistorique(a)}
                      className="bg-green-600 text-white px-3 py-2 rounded font-bold text-sm hover:bg-green-700 whitespace-nowrap"
                    >
                      📊 Historique
                    </button>
                  </div>
                </div>

                {/* SECTION ACTIONS RAPIDES (SI DÉPLIÉ) */}
                {articleDeplie === a.id && (
                  <div className="px-3 pb-3 border-t border-purple-200 pt-3 bg-white bg-opacity-50">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm font-bold text-purple-700">⚡ Actions rapides Stock :</span>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      <button 
                        onClick={() => allerVersStock(a, 'entree')}
                        className="bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2 rounded-lg font-bold text-sm hover:from-green-600 hover:to-green-700 transition flex items-center gap-1"
                      >
                        📥 Entrée
                      </button>
                      <button 
                        onClick={() => allerVersStock(a, 'sortie')}
                        className="bg-gradient-to-r from-red-500 to-red-600 text-white px-4 py-2 rounded-lg font-bold text-sm hover:from-red-600 hover:to-red-700 transition flex items-center gap-1"
                      >
                        📤 Sortie
                      </button>
                      <button 
                        onClick={() => allerVersStock(a, 'transfert')}
                        className="bg-gradient-to-r from-amber-500 to-amber-600 text-white px-4 py-2 rounded-lg font-bold text-sm hover:from-amber-600 hover:to-amber-700 transition flex items-center gap-1"
                      >
                        🔄 Transfert
                      </button>
                      <button 
                        onClick={() => allerVersStock(a, 'affectation')}
                        className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-4 py-2 rounded-lg font-bold text-sm hover:from-purple-600 hover:to-purple-700 transition flex items-center gap-1"
                      >
                        📎 Affecter équipements
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))
          ) : rechercheArticles ? (
            <div className="text-center py-8 text-gray-500">
              <div className="text-4xl mb-2">🔍</div>
              <div className="font-bold">Aucun article trouvé</div>
              <div className="text-sm">Essayez avec un autre terme de recherche</div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <div className="text-4xl mb-2">📦</div>
              <div className="font-bold">Aucun article</div>
              <div className="text-sm">Créez votre premier article</div>
            </div>
          )}
        </div>
      </div>

      {/* MODAL HISTORIQUE */}
      {articleHistorique && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-2xl font-black text-purple-700">📊 HISTORIQUE DES MOUVEMENTS</h2>
                <p className="text-lg font-bold mt-1">{articleHistorique.code}</p>
                <p className="text-sm text-gray-600">{articleHistorique.description}</p>
                {articleHistorique.fournisseur && (
                  <p className="text-sm text-blue-600 font-medium mt-1">🏭 {articleHistorique.fournisseur}</p>
                )}
              </div>
              <button onClick={() => setArticleHistorique(null)} className="text-2xl hover:text-red-600">✕</button>
            </div>
            
            <div className="space-y-2">
              {mouvementsStock && mouvementsStock.filter(m => m.articleId === articleHistorique.id).length === 0 ? (
                <p className="text-gray-500 italic text-center py-8">Aucun mouvement enregistré</p>
              ) : (
                mouvementsStock && mouvementsStock.filter(m => m.articleId === articleHistorique.id).sort((a, b) => new Date(b.date) - new Date(a.date)).map(m => {
                  const isTransfert = m.type === 'transfert' || m.type === 'transfer';
                  let depotInfo = '';
                  
                  if (isTransfert && m.raison && m.raison.includes('→')) {
                    const [source, destination] = m.raison.split('→').map(d => d.trim());
                    depotInfo = `DE ${source} VERS ${destination}`;
                  } else if (m.type === 'entree') {
                    depotInfo = `DANS ${m.depot || 'dépôt inconnu'}`;
                  } else if (m.type === 'sortie') {
                    depotInfo = `DE ${m.depot || 'dépôt inconnu'}`;
                  }

                  return (
                    <div key={m.id} className={`p-3 rounded border-l-4 ${m.type === 'entree' ? 'bg-green-50 border-green-500' : m.type === 'sortie' ? 'bg-red-50 border-red-500' : 'bg-blue-50 border-blue-500'}`}>
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-bold text-lg">
                              {m.type === 'entree' ? '📥 Entrée' : m.type === 'sortie' ? '📤 Sortie' : '🔄 Transfert'}
                            </p>
                            <span className="text-xs bg-gray-200 px-2 py-1 rounded">{m.date}</span>
                          </div>
                          
                          <p className="text-sm font-bold text-blue-700 mb-1">
                            {depotInfo}
                          </p>
                          
                          {(!isTransfert || !m.raison || !m.raison.includes('→')) && m.raison && (
                            <p className="text-xs text-gray-600 italic">
                              📝 {m.raison}
                            </p>
                          )}
                          
                          {m.coutTotal && (
                            <p className="text-xs text-green-700 font-bold mt-1">
                              💰 {m.coutTotal.toFixed(2)}€ total
                              {m.quantite && ` (${(m.coutTotal / m.quantite).toFixed(2)}€/unité)`}
                            </p>
                          )}
                        </div>
                        
                        <div className="text-right">
                          <p className="font-black text-2xl">
                            {isTransfert ? '→' : m.type === 'entree' ? '+' : '-'} {m.quantite}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="mt-6 flex justify-end">
              <button onClick={() => setArticleHistorique(null)} className="bg-gray-600 text-white px-6 py-3 rounded-lg font-black hover:bg-gray-700">Fermer</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL AGRANDISSEMENT PHOTO */}
      {photoAgrandie && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50" onClick={() => setPhotoAgrandie(null)}>
          <div className="relative max-w-4xl max-h-screen p-4">
            <button
              onClick={() => setPhotoAgrandie(null)}
              className="absolute top-6 right-6 bg-red-600 text-white px-4 py-2 rounded-full font-bold text-xl hover:bg-red-700 z-10"
            >
              ✕
            </button>
            <img 
              src={photoAgrandie} 
              alt="Photo agrandie"
              className="max-w-full max-h-screen object-contain rounded-lg"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default Articles;