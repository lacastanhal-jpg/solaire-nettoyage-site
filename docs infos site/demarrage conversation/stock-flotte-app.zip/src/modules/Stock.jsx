// Module STOCK - Solaire Nettoyage V3.1
// AMÉLIORATIONS : Recherche intelligente + descriptions complètes dans les selects
// Gestion des entrées/sorties/transferts avec scanner QR
import React, { useEffect } from 'react';

const Stock = ({
  articles,
  setArticles,
  equipements,
  depots,
  mouvementsStock,
  setMouvementsStock,
  afficherScannerQR,
  setAfficherScannerQR,
  scanResultat,
  setScanResultat,
  actionScan,
  setActionScan,
  formScanEntree,
  setFormScanEntree,
  formScanSortie,
  setFormScanSortie,
  formScanTransfert,
  setFormScanTransfert,
  nouvelleEntreeStock,
  setNouvelleEntreeStock,
  nouveauMouvementSortie,
  setNouveauMouvementSortie,
  nouveauTransfert,
  setNouveauTransfert,
  getStockTotal,
  updateArticles,
  updateMouvements,
  videoRef,
  canvasRef,
  scanningRef,
  jsQRRef,
  videoStream,
  setVideoStream,
  articlePreselectionne,
  setArticlePreselectionne
}) => {

  // NOUVEAUX ÉTATS - RECHERCHE INTELLIGENTE
  const [rechercheEntree, setRechercheEntree] = React.useState('');
  const [rechercheSortie, setRechercheSortie] = React.useState('');
  const [rechercheTransfert, setRechercheTransfert] = React.useState('');
  const [articleEnEvidence, setArticleEnEvidence] = React.useState(null);
  const [rechercheAffectation, setRechercheAffectation] = React.useState('');

  // EFFET - PRÉ-REMPLIR FORMULAIRE SI ARTICLE PRÉ-SÉLECTIONNÉ
  React.useEffect(() => {
    if (articlePreselectionne && articlePreselectionne.article) {
      const { article, action } = articlePreselectionne;
      
      if (action === 'entree') {
        setNouvelleEntreeStock(prev => ({ ...prev, articleId: article.id }));
      } else if (action === 'sortie') {
        setNouveauMouvementSortie(prev => ({ ...prev, articleId: article.id }));
      } else if (action === 'transfert') {
        setNouveauTransfert(prev => ({ ...prev, articleId: article.id }));
      } else if (action === 'affectation') {
        // Mettre en évidence et scroller
        setArticleEnEvidence(article.id);
        setTimeout(() => {
          const element = document.getElementById(`affectation-article-${article.id}`);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 300);
        setTimeout(() => setArticleEnEvidence(null), 3000);
      }
      
      // Réinitialiser après utilisation
      setArticlePreselectionne(null);
    }
  }, [articlePreselectionne]);


  // NOUVELLE FONCTION - FILTRAGE INTELLIGENT MULTI-MOTS
  const filtrerArticles = (recherche) => {
    if (!recherche.trim()) return articles;
    
    // Découper la recherche en mots (séparés par espaces)
    const mots = recherche.toLowerCase().trim().split(/\s+/);
    
    return articles.filter(a => {
      // Créer une chaîne avec tout le contenu de l'article
      const contenu = [
        a.code,
        a.description,
        a.fournisseur || ''
      ].join(' ').toLowerCase();
      
      // Vérifier que TOUS les mots sont présents
      return mots.every(mot => contenu.includes(mot));
    });
  };

  // FONCTION TRAITER SCAN QR
  const traiterScanQR = (code) => {
    const article = articles.find(a => a.code === code);
    if (article) {
      setScanResultat({ success: true, article, code });
      setActionScan(null);
    } else {
      setScanResultat({ success: false, code });
      setActionScan(null);
    }
  };

  // SCANNER QR EFFECT
  useEffect(() => {
    if (!afficherScannerQR || !videoRef.current || !canvasRef.current || scanResultat) return;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    let lastDetectedCode = null;
    let lastDetectedTime = 0;
    
    const tick = () => {
      try {
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
          const videoWidth = video.videoWidth;
          const videoHeight = video.videoHeight;
          if (videoWidth > 0 && videoHeight > 0) {
            canvas.width = videoWidth;
            canvas.height = videoHeight;
            ctx.drawImage(video, 0, 0, videoWidth, videoHeight);
            const imageData = ctx.getImageData(0, 0, videoWidth, videoHeight);
            const jsQR = jsQRRef.current || window.jsQR;
            if (jsQR && typeof jsQR === 'function') {
              const code = jsQR(imageData.data, videoWidth, videoHeight);
              if (code && code.data) {
                const now = Date.now();
                if (code.data !== lastDetectedCode || now - lastDetectedTime > 5000) {
                  lastDetectedCode = code.data;
                  lastDetectedTime = now;
                  traiterScanQR(code.data);
                }
              }
            }
          }
        }
      } catch (err) {
        console.error('Erreur scan:', err);
      }
      scanningRef.current = requestAnimationFrame(tick);
    };
    
    scanningRef.current = requestAnimationFrame(tick);
    return () => {
      if (scanningRef.current) cancelAnimationFrame(scanningRef.current);
    };
  }, [afficherScannerQR, scanResultat, videoRef, canvasRef, scanningRef, jsQRRef]);

  // FONCTIONS SCANNER
  const toggleScannerQR = async () => {
    if (afficherScannerQR) {
      if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
        setVideoStream(null);
      }
      setAfficherScannerQR(false);
    } else {
      setAfficherScannerQR(true);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setVideoStream(stream);
      } catch (err) {
        alert('Caméra non disponible');
        setAfficherScannerQR(false);
      }
    }
  };

  // FONCTIONS SCAN - ENTRÉE/SORTIE/TRANSFERT
  const enregistrerEntreeStockScan = () => {
    if (!formScanEntree.quantite || !formScanEntree.prixUnitaire) { 
      alert('Quantité et prix requis'); 
      return; 
    }
    const quantite = parseInt(formScanEntree.quantite);
    const coutTotal = parseFloat(formScanEntree.prixUnitaire) * quantite;
    
    updateArticles(articles.map(a => a.id === scanResultat.article.id ? { 
      ...a, 
      stockParDepot: { 
        ...a.stockParDepot, 
        [formScanEntree.depot]: (a.stockParDepot[formScanEntree.depot] || 0) + quantite 
      } 
    } : a));
    
    updateMouvements([...mouvementsStock, { 
      id: mouvementsStock.length + 1, 
      articleId: scanResultat.article.id, 
      type: 'entree', 
      quantite, 
      date: formScanEntree.date, 
      raison: formScanEntree.raison, 
      coutTotal, 
      depot: formScanEntree.depot 
    }]);
    
    alert(`✅ +${quantite} ${scanResultat.article.code}`);
    setScanResultat(null);
    setFormScanEntree({ quantite: '', prixUnitaire: '', raison: '', depot: 'Atelier', date: new Date().toISOString().split('T')[0] });
  };

  const enregistrerSortieStockScan = () => {
    if (!formScanSortie.quantite) { 
      alert('Quantité requise'); 
      return; 
    }
    const quantite = parseInt(formScanSortie.quantite);
    const stockDisponible = scanResultat.article.stockParDepot[formScanSortie.depot] || 0;
    
    if (quantite > stockDisponible) { 
      alert(`❌ Stock insuffisant ! Disponible: ${stockDisponible}`); 
      return; 
    }
    
    updateArticles(articles.map(a => a.id === scanResultat.article.id ? { 
      ...a, 
      stockParDepot: { 
        ...a.stockParDepot, 
        [formScanSortie.depot]: stockDisponible - quantite 
      } 
    } : a));
    
    updateMouvements([...mouvementsStock, { 
      id: mouvementsStock.length + 1, 
      articleId: scanResultat.article.id, 
      type: 'sortie', 
      quantite, 
      date: formScanSortie.date, 
      raison: formScanSortie.raison, 
      coutTotal: 0, 
      depot: formScanSortie.depot 
    }]);
    
    alert(`✅ -${quantite} ${scanResultat.article.code}`);
    setScanResultat(null);
    setFormScanSortie({ quantite: '', raison: '', depot: 'Atelier', date: new Date().toISOString().split('T')[0] });
  };

  const enregistrerTransfertStockScan = () => {
    if (!formScanTransfert.quantite) { 
      alert('Quantité requise'); 
      return; 
    }
    if (formScanTransfert.depotSource === formScanTransfert.depotDestination) { 
      alert('❌ Les dépôts doivent être différents'); 
      return; 
    }
    
    const quantite = parseInt(formScanTransfert.quantite);
    const stockSource = scanResultat.article.stockParDepot[formScanTransfert.depotSource] || 0;
    
    if (quantite > stockSource) { 
      alert(`❌ Stock source insuffisant ! Disponible: ${stockSource}`); 
      return; 
    }
    
    updateArticles(articles.map(a => a.id === scanResultat.article.id ? { 
      ...a, 
      stockParDepot: { 
        ...a.stockParDepot, 
        [formScanTransfert.depotSource]: stockSource - quantite,
        [formScanTransfert.depotDestination]: (a.stockParDepot[formScanTransfert.depotDestination] || 0) + quantite
      } 
    } : a));
    
    updateMouvements([...mouvementsStock, { 
      id: mouvementsStock.length + 1, 
      articleId: scanResultat.article.id, 
      type: 'transfert', 
      quantite, 
      date: new Date().toISOString().split('T')[0], 
      raison: `${formScanTransfert.depotSource} → ${formScanTransfert.depotDestination}`, 
      coutTotal: 0, 
      depot: formScanTransfert.depotSource 
    }]);
    
    alert(`✅ ${quantite} ${scanResultat.article.code} transféré`);
    setScanResultat(null);
    setFormScanTransfert({ depotSource: 'Atelier', depotDestination: 'Porteur 26 T', quantite: '' });
  };

  // FONCTIONS MANUELLES - ENTRÉE/SORTIE/TRANSFERT
  const enregistrerEntreeStock = () => {
    if (!nouvelleEntreeStock.articleId || !nouvelleEntreeStock.quantite || !nouvelleEntreeStock.prixUnitaire) { 
      alert('Article, quantité et prix requis'); 
      return; 
    }
    const quantite = parseInt(nouvelleEntreeStock.quantite);
    const coutTotal = parseFloat(nouvelleEntreeStock.prixUnitaire) * quantite;
    const articleId = parseInt(nouvelleEntreeStock.articleId);
    const depot = nouvelleEntreeStock.depot || 'Atelier';
    
    updateArticles(articles.map(a => a.id === articleId ? { 
      ...a, 
      stockParDepot: { 
        ...a.stockParDepot, 
        [depot]: (a.stockParDepot[depot] || 0) + quantite 
      } 
    } : a));
    
    updateMouvements([...mouvementsStock, { 
      id: mouvementsStock.length + 1, 
      articleId, 
      type: 'entree', 
      quantite, 
      date: nouvelleEntreeStock.date || new Date().toISOString().split('T')[0], 
      raison: nouvelleEntreeStock.raison, 
      coutTotal, 
      depot 
    }]);
    
    const art = articles.find(a => a.id === articleId);
    alert(`✅ +${quantite} ${art?.code} ajouté au stock ${depot}`);
    setNouvelleEntreeStock({ articleId: '', quantite: '', prixUnitaire: '', raison: '', date: new Date().toISOString().split('T')[0], depot: 'Atelier' });
  };

  const enregistrerSortieStock = () => {
    if (!nouveauMouvementSortie.articleId || !nouveauMouvementSortie.quantite) { 
      alert('Article et quantité requis'); 
      return; 
    }
    const quantite = parseInt(nouveauMouvementSortie.quantite);
    const articleId = parseInt(nouveauMouvementSortie.articleId);
    const depot = nouveauMouvementSortie.depot || 'Atelier';
    const article = articles.find(a => a.id === articleId);
    const stockDisponible = article?.stockParDepot[depot] || 0;
    
    if (quantite > stockDisponible) { 
      alert(`❌ Stock insuffisant dans ${depot} ! Disponible: ${stockDisponible}`); 
      return; 
    }
    
    updateArticles(articles.map(a => a.id === articleId ? { 
      ...a, 
      stockParDepot: { 
        ...a.stockParDepot, 
        [depot]: stockDisponible - quantite 
      } 
    } : a));
    
    updateMouvements([...mouvementsStock, { 
      id: mouvementsStock.length + 1, 
      articleId, 
      type: 'sortie', 
      quantite, 
      date: nouveauMouvementSortie.date, 
      raison: nouveauMouvementSortie.raison, 
      coutTotal: 0, 
      depot 
    }]);
    
    alert(`✅ -${quantite} ${article?.code} retiré du stock ${depot}`);
    setNouveauMouvementSortie({ articleId: '', quantite: '', raison: '', date: new Date().toISOString().split('T')[0], depot: 'Atelier' });
  };

  const enregistrerTransfertStock = () => {
    if (!nouveauTransfert.articleId || !nouveauTransfert.quantite) { 
      alert('Article et quantité requis'); 
      return; 
    }
    if (nouveauTransfert.depotSource === nouveauTransfert.depotDestination) { 
      alert('❌ Les dépôts doivent être différents'); 
      return; 
    }
    
    const quantite = parseInt(nouveauTransfert.quantite);
    const articleId = parseInt(nouveauTransfert.articleId);
    const article = articles.find(a => a.id === articleId);
    const stockSource = article?.stockParDepot[nouveauTransfert.depotSource] || 0;
    
    if (quantite > stockSource) { 
      alert(`❌ Stock source insuffisant dans ${nouveauTransfert.depotSource} ! Disponible: ${stockSource}`); 
      return; 
    }
    
    updateArticles(articles.map(a => a.id === articleId ? { 
      ...a, 
      stockParDepot: { 
        ...a.stockParDepot, 
        [nouveauTransfert.depotSource]: stockSource - quantite,
        [nouveauTransfert.depotDestination]: (a.stockParDepot[nouveauTransfert.depotDestination] || 0) + quantite
      } 
    } : a));
    
    updateMouvements([...mouvementsStock, { 
      id: mouvementsStock.length + 1, 
      articleId, 
      type: 'transfert', 
      quantite, 
      date: new Date().toISOString().split('T')[0], 
      raison: `${nouveauTransfert.depotSource} → ${nouveauTransfert.depotDestination} ${nouveauTransfert.raison ? '- ' + nouveauTransfert.raison : ''}`, 
      coutTotal: 0, 
      depot: nouveauTransfert.depotSource 
    }]);
    
    alert(`✅ ${quantite} ${article?.code} transféré de ${nouveauTransfert.depotSource} vers ${nouveauTransfert.depotDestination}`);
    setNouveauTransfert({ articleId: '', depotSource: 'Atelier', depotDestination: 'Porteur 26 T', quantite: '', raison: '' });
  };

  // FONCTION AFFECTATION ARTICLE À ÉQUIPEMENT
  const affecterArticleEquipement = (articleId, equipementId) => {
    updateArticles(articles.map(a => {
      if (a.id === articleId) {
        const isAffecte = a.equipementsAffectes.includes(equipementId);
        return { 
          ...a, 
          equipementsAffectes: isAffecte 
            ? a.equipementsAffectes.filter(id => id !== equipementId) 
            : [...a.equipementsAffectes, equipementId] 
        };
      }
      return a;
    }));
  };

  return (
    <div className="space-y-4">
      {/* SCANNER QR */}
      <div className="bg-blue-50 border-2 border-blue-400 p-4 rounded">
        <button onClick={toggleScannerQR} className="w-full bg-blue-600 text-white px-4 py-3 rounded-lg font-bold text-lg flex items-center justify-center gap-2">
          {afficherScannerQR ? '✕ Fermer le scanner' : '📷 Scanner un article'}
        </button>
        
        {afficherScannerQR && (
          <div className="mt-4">
            {!scanResultat && (
              <>
                <video ref={videoRef} autoPlay playsInline muted className="w-full max-w-md mx-auto rounded border-4 border-blue-600" />
                <canvas ref={canvasRef} className="hidden" />
                <p className="text-center mt-2 text-blue-700 font-medium">📸 Positionnez le QR code devant la caméra</p>
                
                {/* CHOIX ACTION */}
                {!actionScan && (
                  <div className="grid grid-cols-3 gap-2 mt-4">
                    <button onClick={() => setActionScan('entree')} className="bg-green-600 text-white px-4 py-3 rounded font-bold">📥 Entrée</button>
                    <button onClick={() => setActionScan('sortie')} className="bg-red-600 text-white px-4 py-3 rounded font-bold">📤 Sortie</button>
                    <button onClick={() => setActionScan('transfert')} className="bg-amber-600 text-white px-4 py-3 rounded font-bold">🔄 Transfert</button>
                  </div>
                )}
              </>
            )}
            
            {scanResultat && (
              <div className="mt-4 p-4 bg-white rounded border-2 border-gray-300">
                {scanResultat.success ? (
                  <>
                    <div className="bg-green-100 p-3 rounded mb-3 border-2 border-green-500">
                      <h4 className="font-bold text-green-800 text-lg">✅ Article détecté</h4>
                      <p className="font-bold text-xl mt-1">{scanResultat.article.code} - {scanResultat.article.description}</p>
                      <p className="text-sm text-gray-600 mt-1">Fournisseur: {scanResultat.article.fournisseur}</p>
                      <div className="mt-2 flex gap-2 flex-wrap">
                        {depots.map(d => (
                          <span key={d} className="bg-white px-2 py-1 rounded text-xs border">
                            {d}: <strong>{scanResultat.article.stockParDepot[d] || 0}</strong>
                          </span>
                        ))}
                      </div>
                    </div>

                    {actionScan === 'entree' ? (
                      <div className="bg-green-50 p-4 rounded-lg mb-4 border-2 border-green-300">
                        <h4 className="font-bold text-green-700 mb-3">📥 Entrée de Stock</h4>
                        <div className="space-y-2">
                          <input type="number" placeholder="Quantité *" value={formScanEntree.quantite} onChange={(e) => setFormScanEntree({...formScanEntree, quantite: e.target.value})} className="w-full border rounded px-2 py-1" />
                          <input type="number" step="0.01" placeholder="Prix unitaire *" value={formScanEntree.prixUnitaire} onChange={(e) => setFormScanEntree({...formScanEntree, prixUnitaire: e.target.value})} className="w-full border rounded px-2 py-1" />
                          <input placeholder="Raison" value={formScanEntree.raison} onChange={(e) => setFormScanEntree({...formScanEntree, raison: e.target.value})} className="w-full border rounded px-2 py-1" />
                          <select value={formScanEntree.depot} onChange={(e) => setFormScanEntree({...formScanEntree, depot: e.target.value})} className="w-full border rounded px-2 py-1">
                            {depots.map(d => <option key={d} value={d}>{d}</option>)}
                          </select>
                          <input type="date" value={formScanEntree.date} onChange={(e) => setFormScanEntree({...formScanEntree, date: e.target.value})} className="w-full border rounded px-2 py-1" />
                        </div>
                        <div className="flex gap-2 mt-3">
                          <button onClick={enregistrerEntreeStockScan} className="flex-1 bg-green-600 text-white px-3 py-2 rounded font-bold">✓ Valider</button>
                          <button onClick={() => setActionScan(null)} className="flex-1 bg-gray-400 text-white px-3 py-2 rounded font-bold">↩️ Retour</button>
                        </div>
                      </div>
                    ) : actionScan === 'sortie' ? (
                      <div className="bg-red-50 p-4 rounded-lg mb-4 border-2 border-red-300">
                        <h4 className="font-bold text-red-700 mb-3">📤 Sortie de Stock</h4>
                        <div className="space-y-2">
                          <input type="number" placeholder="Quantité *" value={formScanSortie.quantite} onChange={(e) => setFormScanSortie({...formScanSortie, quantite: e.target.value})} className="w-full border rounded px-2 py-1" />
                          <input placeholder="Raison" value={formScanSortie.raison} onChange={(e) => setFormScanSortie({...formScanSortie, raison: e.target.value})} className="w-full border rounded px-2 py-1" />
                          <select value={formScanSortie.depot} onChange={(e) => setFormScanSortie({...formScanSortie, depot: e.target.value})} className="w-full border rounded px-2 py-1">
                            {depots.map(d => <option key={d} value={d}>{d}</option>)}
                          </select>
                          <input type="date" value={formScanSortie.date} onChange={(e) => setFormScanSortie({...formScanSortie, date: e.target.value})} className="w-full border rounded px-2 py-1" />
                        </div>
                        <div className="flex gap-2 mt-3">
                          <button onClick={enregistrerSortieStockScan} className="flex-1 bg-red-600 text-white px-3 py-2 rounded font-bold">✓ Valider</button>
                          <button onClick={() => setActionScan(null)} className="flex-1 bg-gray-400 text-white px-3 py-2 rounded font-bold">↩️ Retour</button>
                        </div>
                      </div>
                    ) : actionScan === 'transfert' ? (
                      <div className="bg-amber-50 p-4 rounded-lg mb-4 border-2 border-amber-300">
                        <h4 className="font-bold text-amber-700 mb-3">🔄 Transfert</h4>
                        <div className="space-y-2">
                          <input type="number" placeholder="Quantité *" value={formScanTransfert.quantite} onChange={(e) => setFormScanTransfert({...formScanTransfert, quantite: e.target.value})} className="w-full border rounded px-2 py-1" />
                          <select value={formScanTransfert.depotSource} onChange={(e) => setFormScanTransfert({...formScanTransfert, depotSource: e.target.value})} className="w-full border rounded px-2 py-1">
                            {depots.map(d => <option key={d} value={d}>{d}</option>)}
                          </select>
                          <select value={formScanTransfert.depotDestination} onChange={(e) => setFormScanTransfert({...formScanTransfert, depotDestination: e.target.value})} className="w-full border rounded px-2 py-1">
                            {depots.map(d => <option key={d} value={d}>{d}</option>)}
                          </select>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <button onClick={enregistrerTransfertStockScan} className="flex-1 bg-amber-600 text-white px-3 py-2 rounded font-bold">✓ Valider</button>
                          <button onClick={() => setActionScan(null)} className="flex-1 bg-gray-400 text-white px-3 py-2 rounded font-bold">↩️ Retour</button>
                        </div>
                      </div>
                    ) : null}
                  </>
                ) : (
                  <div className="flex gap-2">
                    <button onClick={() => setScanResultat(null)} className="flex-1 bg-blue-600 text-white px-4 py-2 rounded font-bold">🔄 Rescanner</button>
                    <button onClick={() => {setAfficherScannerQR(false); setScanResultat(null);}} className="flex-1 bg-gray-400 text-white px-4 py-2 rounded font-bold">✕ Fermer</button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ENTRÉE AVEC RECHERCHE INTELLIGENTE */}
      <div className="bg-green-50 border-2 border-green-300 p-4 rounded">
        <h3 className="font-bold mb-3">📥 Entrée</h3>
        
        {/* BARRE DE RECHERCHE INTELLIGENTE */}
        <div className="mb-3">
          <input 
            type="text" 
            placeholder="🔍 Rechercher article (code, description, fournisseur)..." 
            value={rechercheEntree}
            onChange={(e) => setRechercheEntree(e.target.value)}
            className="w-full border-2 border-green-400 rounded px-3 py-2 font-medium focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          {rechercheEntree && (
            <div className="text-xs text-green-700 mt-1 font-medium">
              🎯 {filtrerArticles(rechercheEntree).length} article(s) trouvé(s)
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
          <select value={nouvelleEntreeStock.articleId} onChange={(e) => setNouvelleEntreeStock({...nouvelleEntreeStock, articleId: e.target.value})} className="border rounded px-2 py-1">
            <option value="">Sélectionner un article...</option>
            {filtrerArticles(rechercheEntree).map(a => (
              <option key={a.id} value={a.id}>{a.code} - {a.description}</option>
            ))}
          </select>
          <input type="number" placeholder="Qté" value={nouvelleEntreeStock.quantite} onChange={(e) => setNouvelleEntreeStock({...nouvelleEntreeStock, quantite: e.target.value})} className="border rounded px-2 py-1" />
          <input type="number" step="0.01" placeholder="Prix" value={nouvelleEntreeStock.prixUnitaire} onChange={(e) => setNouvelleEntreeStock({...nouvelleEntreeStock, prixUnitaire: e.target.value})} className="border rounded px-2 py-1" />
          <input placeholder="Raison" value={nouvelleEntreeStock.raison} onChange={(e) => setNouvelleEntreeStock({...nouvelleEntreeStock, raison: e.target.value})} className="border rounded px-2 py-1" />
          <button onClick={enregistrerEntreeStock} className="bg-green-600 text-white px-3 py-1 rounded font-bold">Entrer</button>
        </div>
      </div>

      {/* SORTIE AVEC RECHERCHE INTELLIGENTE */}
      <div className="bg-red-50 border-2 border-red-300 p-4 rounded">
        <h3 className="font-bold mb-3">📤 Sortie</h3>
        
        {/* BARRE DE RECHERCHE INTELLIGENTE */}
        <div className="mb-3">
          <input 
            type="text" 
            placeholder="🔍 Rechercher article (code, description, fournisseur)..." 
            value={rechercheSortie}
            onChange={(e) => setRechercheSortie(e.target.value)}
            className="w-full border-2 border-red-400 rounded px-3 py-2 font-medium focus:outline-none focus:ring-2 focus:ring-red-500"
          />
          {rechercheSortie && (
            <div className="text-xs text-red-700 mt-1 font-medium">
              🎯 {filtrerArticles(rechercheSortie).length} article(s) trouvé(s)
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
          <select value={nouveauMouvementSortie.articleId} onChange={(e) => setNouveauMouvementSortie({...nouveauMouvementSortie, articleId: e.target.value})} className="border rounded px-2 py-1">
            <option value="">Sélectionner un article...</option>
            {filtrerArticles(rechercheSortie).map(a => (
              <option key={a.id} value={a.id}>{a.code} - {a.description}</option>
            ))}
          </select>
          <input type="number" placeholder="Qté" value={nouveauMouvementSortie.quantite} onChange={(e) => setNouveauMouvementSortie({...nouveauMouvementSortie, quantite: e.target.value})} className="border rounded px-2 py-1" />
          <input placeholder="Raison" value={nouveauMouvementSortie.raison} onChange={(e) => setNouveauMouvementSortie({...nouveauMouvementSortie, raison: e.target.value})} className="border rounded px-2 py-1" />
          <input type="date" value={nouveauMouvementSortie.date} onChange={(e) => setNouveauMouvementSortie({...nouveauMouvementSortie, date: e.target.value})} className="border rounded px-2 py-1" />
          <button onClick={enregistrerSortieStock} className="bg-red-600 text-white px-3 py-1 rounded font-bold">Sortir</button>
        </div>
      </div>

      {/* TRANSFERT AVEC RECHERCHE INTELLIGENTE */}
      <div className="bg-amber-50 border-2 border-amber-400 p-4 rounded">
        <h3 className="font-bold mb-3">🔄 Transfert</h3>
        
        {/* BARRE DE RECHERCHE INTELLIGENTE */}
        <div className="mb-3">
          <input 
            type="text" 
            placeholder="🔍 Rechercher article (code, description, fournisseur)..." 
            value={rechercheTransfert}
            onChange={(e) => setRechercheTransfert(e.target.value)}
            className="w-full border-2 border-amber-400 rounded px-3 py-2 font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
          {rechercheTransfert && (
            <div className="text-xs text-amber-700 mt-1 font-medium">
              🎯 {filtrerArticles(rechercheTransfert).length} article(s) trouvé(s)
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-6 gap-2">
          <select value={nouveauTransfert.articleId} onChange={(e) => setNouveauTransfert({...nouveauTransfert, articleId: e.target.value})} className="border rounded px-2 py-1">
            <option value="">Sélectionner un article...</option>
            {filtrerArticles(rechercheTransfert).map(a => (
              <option key={a.id} value={a.id}>{a.code} - {a.description}</option>
            ))}
          </select>
          <select value={nouveauTransfert.depotSource} onChange={(e) => setNouveauTransfert({...nouveauTransfert, depotSource: e.target.value})} className="border rounded px-2 py-1">
            {depots.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          <select value={nouveauTransfert.depotDestination} onChange={(e) => setNouveauTransfert({...nouveauTransfert, depotDestination: e.target.value})} className="border rounded px-2 py-1">
            {depots.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          <input type="number" placeholder="Qté" value={nouveauTransfert.quantite} onChange={(e) => setNouveauTransfert({...nouveauTransfert, quantite: e.target.value})} className="border rounded px-2 py-1" />
          <input placeholder="Note" value={nouveauTransfert.raison} onChange={(e) => setNouveauTransfert({...nouveauTransfert, raison: e.target.value})} className="border rounded px-2 py-1" />
          <button onClick={enregistrerTransfertStock} className="bg-amber-600 text-white px-3 py-1 rounded font-bold">Transférer</button>
        </div>
      </div>

      {/* AFFECTATION ARTICLES AUX ÉQUIPEMENTS */}
      <div className="bg-white p-4 rounded border">
        <h3 className="font-bold text-lg mb-3">🎯 Affecter articles aux équipements</h3>
        
        {/* BARRE DE RECHERCHE INTELLIGENTE */}
        <div className="mb-4">
          <input 
            type="text" 
            placeholder="🔍 Rechercher article à affecter (code, description, fournisseur)..." 
            value={rechercheAffectation}
            onChange={(e) => setRechercheAffectation(e.target.value)}
            className="w-full border-2 border-blue-400 rounded-lg px-4 py-3 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
          />
          {rechercheAffectation && (
            <div className="text-sm text-blue-700 mt-2 font-medium flex items-center gap-2">
              🎯 {filtrerArticles(rechercheAffectation).length} article(s) trouvé(s) sur {articles.length}
              {filtrerArticles(rechercheAffectation).length === 0 && (
                <span className="text-red-600">• Aucun résultat</span>
              )}
            </div>
          )}
        </div>

        <div className="space-y-2">
          {filtrerArticles(rechercheAffectation).length > 0 ? (
            filtrerArticles(rechercheAffectation).map(a => {
              const equipAffectes = equipements.filter(e => a.equipementsAffectes.includes(e.id));
              const isAffecte = a.equipementsAffectes.length > 0;
              return (
                <div 
                  key={a.id} 
                  id={`affectation-article-${a.id}`}
                  className={`flex justify-between items-center p-3 rounded border-2 transition-all duration-500 ${
                    articleEnEvidence === a.id 
                      ? 'bg-yellow-200 border-yellow-500 shadow-lg scale-105' 
                      : isAffecte ? 'bg-blue-100 border-blue-400' : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex-1">
                    <div className="font-semibold">{a.code} - {a.description}</div>
                    <div className="text-xs text-gray-600">
                      Stock total: {getStockTotal(a)} × {isAffecte ? `✓ Affecté à : ${equipAffectes.map(e => e.immat).join(', ')}` : 'Non affecté'}
                    </div>
                  </div>
                  <div className="flex gap-1 ml-2 flex-wrap">
                    {equipements.map(e => (
                      <button 
                        key={e.id} 
                        onClick={() => affecterArticleEquipement(a.id, e.id)} 
                        className={`px-3 py-1 rounded text-xs font-bold whitespace-nowrap transition ${
                          a.equipementsAffectes.includes(e.id) 
                            ? 'bg-blue-600 text-white shadow-md' 
                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        }`}
                      >
                        {e.immat}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })
          ) : rechercheAffectation ? (
            <div className="text-center py-8 text-gray-500">
              <div className="text-4xl mb-2">🔍</div>
              <div className="font-bold">Aucun article trouvé</div>
              <div className="text-sm">Essayez avec un autre terme de recherche</div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <div className="text-4xl mb-2">📦</div>
              <div className="font-bold">Aucun article</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Stock;