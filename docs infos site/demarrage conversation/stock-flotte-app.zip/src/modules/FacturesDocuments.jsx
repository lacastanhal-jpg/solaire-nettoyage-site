// Module FACTURES & DOCUMENTS - Solaire Nettoyage V3.6
// Gestion complète des factures multi-lignes et documents (carte grise, VGP, assurance, CT)
import React, { useState } from 'react';

const FacturesDocuments = ({
  factures,
  setFactures,
  equipements,
  updateFactures
}) => {

  // ÉTATS LOCAUX
  const [rechercheFacture, setRechercheFacture] = useState('');
  const [afficherModalFacture, setAfficherModalFacture] = useState(false);
  const [factureEnCours, setFactureEnCours] = useState(null);
  const [modeEdition, setModeEdition] = useState(false);
  const [scanFacture, setScanFacture] = useState(null);
  const [afficherScanModal, setAfficherScanModal] = useState(null);
  const [typeAffichage, setTypeAffichage] = useState('factures'); // 'factures' ou 'documents'

  // ÉTATS - TYPES PERSONNALISÉS FRAIS
  const [typesFraisPersonnalises, setTypesFraisPersonnalises] = useState(() => {
    const saved = localStorage.getItem('typesFraisPersonnalises');
    return saved ? JSON.parse(saved) : [];
  });
  const [nouveauTypeFraisEnCours, setNouveauTypeFraisEnCours] = useState(false);
  const [nouveauTypeFraisTexte, setNouveauTypeFraisTexte] = useState('');

  // TYPES DE FRAIS (pour factures)
  const typesFraisParDefaut = [
    '🔧 Garage',
    '⛽ Carburant', 
    '🛣️ Péage',
    '🛡️ Assurance',
    '🔩 Pièces détachées',
    '🧽 Nettoyage',
    '📋 Contrôle technique',
    '📄 Autre'
  ];
  const typesFrais = [...typesFraisParDefaut, ...typesFraisPersonnalises];

  // ÉTATS - TYPES PERSONNALISÉS DOCUMENTS
  const [typesDocumentsPersonnalises, setTypesDocumentsPersonnalises] = useState(() => {
    const saved = localStorage.getItem('typesDocumentsPersonnalises');
    return saved ? JSON.parse(saved) : [];
  });
  const [nouveauTypeDocumentEnCours, setNouveauTypeDocumentEnCours] = useState(false);
  const [nouveauTypeDocumentTexte, setNouveauTypeDocumentTexte] = useState('');

  // TYPES DE DOCUMENTS
  const typesDocumentsParDefaut = [
    '🚗 Carte Grise',
    '✅ VGP',
    '🛡️ Assurance',
    '🔧 Contrôle Technique',
    '📄 Autre'
  ];
  const typesDocuments = [...typesDocumentsParDefaut, ...typesDocumentsPersonnalises];

  // FONCTION - AJOUTER UN TYPE DE FRAIS PERSONNALISÉ
  const ajouterTypeFraisPersonnalise = () => {
    if (!nouveauTypeFraisTexte.trim()) {
      alert('⚠️ Veuillez saisir un type de frais');
      return;
    }
    
    const typeNormalise = nouveauTypeFraisTexte.trim();
    
    if (typesFrais.includes(typeNormalise)) {
      alert('⚠️ Ce type de frais existe déjà');
      return;
    }
    
    const nouveauxTypes = [...typesFraisPersonnalises, typeNormalise];
    setTypesFraisPersonnalises(nouveauxTypes);
    localStorage.setItem('typesFraisPersonnalises', JSON.stringify(nouveauxTypes));
    
    setFactureEnCours({...factureEnCours, typeFrais: typeNormalise});
    setNouveauTypeFraisEnCours(false);
    setNouveauTypeFraisTexte('');
    
    alert('✅ Type de frais ajouté !');
  };

  // FONCTION - AJOUTER UN TYPE DE DOCUMENT PERSONNALISÉ
  const ajouterTypeDocumentPersonnalise = () => {
    if (!nouveauTypeDocumentTexte.trim()) {
      alert('⚠️ Veuillez saisir un type de document');
      return;
    }
    
    const typeNormalise = nouveauTypeDocumentTexte.trim();
    
    if (typesDocuments.includes(typeNormalise)) {
      alert('⚠️ Ce type de document existe déjà');
      return;
    }
    
    const nouveauxTypes = [...typesDocumentsPersonnalises, typeNormalise];
    setTypesDocumentsPersonnalises(nouveauxTypes);
    localStorage.setItem('typesDocumentsPersonnalises', JSON.stringify(nouveauxTypes));
    
    setFactureEnCours({...factureEnCours, typeDocument: typeNormalise});
    setNouveauTypeDocumentEnCours(false);
    setNouveauTypeDocumentTexte('');
    
    alert('✅ Type de document ajouté !');
  };

  // INITIALISER NOUVELLE FACTURE
  const initialiserNouvelleFacture = () => {
    const facturesUniquement = factures.filter(f => !f.type || f.type === 'facture');
    const dernierNumero = facturesUniquement.length > 0 
      ? Math.max(...facturesUniquement.map(f => parseInt(f.numero?.split('-')[2]) || 0))
      : 0;
    const nouveauNumero = `FAC-${new Date().getFullYear()}-${String(dernierNumero + 1).padStart(3, '0')}`;
    
    return {
      id: Date.now(),
      type: 'facture',
      numero: nouveauNumero,
      fournisseur: '',
      typeFrais: '🔧 Garage',
      date: new Date().toISOString().split('T')[0],
      lignes: [
        {
          id: 1,
          equipementId: '',
          description: '',
          quantite: 1,
          prixUnitaire: 0,
          total: 0
        }
      ],
      totalHT: 0,
      scanUrl: null,
      scanNom: null,
      operateur: 'Jerome',
      notes: ''
    };
  };

  // INITIALISER NOUVEAU DOCUMENT
  const initialiserNouveauDocument = () => {
    return {
      id: Date.now(),
      type: 'document',
      typeDocument: '🚗 Carte Grise',
      equipementId: '',
      titre: '',
      dateEmission: new Date().toISOString().split('T')[0],
      dateExpiration: null,
      organisme: '',
      pdfUrl: null,
      pdfNom: null,
      operateur: 'Jerome',
      notes: ''
    };
  };

  // OUVRIR MODAL NOUVELLE FACTURE/DOCUMENT
  const ouvrirModalNouvelleFacture = () => {
    if (typeAffichage === 'factures') {
      setFactureEnCours(initialiserNouvelleFacture());
    } else {
      setFactureEnCours(initialiserNouveauDocument());
    }
    setModeEdition(false);
    setScanFacture(null);
    setAfficherModalFacture(true);
  };

  // OUVRIR MODAL ÉDITION
  const ouvrirModalEdition = (item) => {
    setFactureEnCours({...item});
    setModeEdition(true);
    setScanFacture(null);
    setAfficherModalFacture(true);
  };

  // FERMER MODAL
  const fermerModal = () => {
    setAfficherModalFacture(false);
    setFactureEnCours(null);
    setModeEdition(false);
    setScanFacture(null);
  };

  // AJOUTER/MODIFIER LIGNE FACTURE
  const ajouterLigne = () => {
    const nouvelleLigne = {
      id: Date.now(),
      equipementId: '',
      description: '',
      quantite: 1,
      prixUnitaire: 0,
      total: 0
    };
    setFactureEnCours({
      ...factureEnCours,
      lignes: [...factureEnCours.lignes, nouvelleLigne]
    });
  };

  const supprimerLigne = (ligneId) => {
    if (factureEnCours.lignes.length === 1) return;
    setFactureEnCours({
      ...factureEnCours,
      lignes: factureEnCours.lignes.filter(l => l.id !== ligneId)
    });
  };

  const modifierLigne = (ligneId, champ, valeur) => {
    const nouvellesLignes = factureEnCours.lignes.map(ligne => {
      if (ligne.id === ligneId) {
        const ligneModifiee = { ...ligne, [champ]: valeur };
        // Recalculer le total de la ligne
        if (champ === 'quantite' || champ === 'prixUnitaire') {
          ligneModifiee.total = (ligneModifiee.quantite || 0) * (ligneModifiee.prixUnitaire || 0);
        }
        return ligneModifiee;
      }
      return ligne;
    });

    // Recalculer le total HT
    const totalHT = nouvellesLignes.reduce((sum, ligne) => sum + (ligne.total || 0), 0);

    setFactureEnCours({
      ...factureEnCours,
      lignes: nouvellesLignes,
      totalHT
    });
  };

  // UPLOAD SCAN
  const handleScanUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Vérifier la taille (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('⚠️ Le fichier est trop volumineux (max 5MB)');
      return;
    }

    // Vérifier le type
    const typesAcceptes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!typesAcceptes.includes(file.type)) {
      alert('⚠️ Format non accepté. Utilisez PDF, JPG ou PNG.');
      return;
    }

    // Lire le fichier
    const reader = new FileReader();
    reader.onload = (event) => {
      setScanFacture(file);
      
      // Pour les documents, utiliser pdfUrl/pdfNom
      // Pour les factures, utiliser scanUrl/scanNom
      if (factureEnCours.type === 'document') {
        setFactureEnCours({
          ...factureEnCours,
          pdfUrl: event.target.result,
          pdfNom: file.name
        });
      } else {
        setFactureEnCours({
          ...factureEnCours,
          scanUrl: event.target.result,
          scanNom: file.name
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // ENREGISTRER FACTURE/DOCUMENT
  const enregistrerFacture = () => {
    // Validation
    if (factureEnCours.type === 'document') {
      if (!factureEnCours.equipementId || !factureEnCours.titre) {
        alert('⚠️ Veuillez remplir tous les champs obligatoires');
        return;
      }
    } else {
      if (!factureEnCours.fournisseur) {
        alert('⚠️ Le fournisseur est obligatoire');
        return;
      }
      const lignesCompletes = factureEnCours.lignes.filter(l => 
        l.equipementId && l.description && l.quantite > 0 && l.prixUnitaire > 0
      );
      if (lignesCompletes.length === 0) {
        alert('⚠️ Ajoutez au moins une ligne complète');
        return;
      }
    }

    let nouvellesFactures;
    if (modeEdition) {
      nouvellesFactures = factures.map(f => f.id === factureEnCours.id ? factureEnCours : f);
    } else {
      nouvellesFactures = [...factures, factureEnCours];
    }

    updateFactures(nouvellesFactures);
    fermerModal();
  };

  // SUPPRIMER FACTURE/DOCUMENT
  const supprimerFacture = (id) => {
    const item = factures.find(f => f.id === id);
    const type = item.type === 'document' ? 'document' : 'facture';
    if (window.confirm(`Supprimer ${type === 'document' ? 'ce document' : 'cette facture'} définitivement ?`)) {
      const nouvellesFactures = factures.filter(f => f.id !== id);
      updateFactures(nouvellesFactures);
    }
  };

  // FILTRER FACTURES/DOCUMENTS
  const filtrerFactures = () => {
    // Filtrer par type (facture ou document)
    let items = factures.filter(f => {
      if (typeAffichage === 'factures') {
        return !f.type || f.type === 'facture';
      } else {
        return f.type === 'document';
      }
    });
    
    // Si pas de recherche, retourner tous les items du type sélectionné
    if (!rechercheFacture.trim()) return items;
    
    const mots = rechercheFacture.toLowerCase().trim().split(/\s+/);
    
    return items.filter(f => {
      if (f.type === 'document') {
        // Pour les documents
        const eq = equipements.find(e => e.id === parseInt(f.equipementId));
        const contenu = [
          f.titre || '',
          f.typeDocument || '',
          eq?.immat || '',
          f.organisme || ''
        ].join(' ').toLowerCase();
        return mots.every(mot => contenu.includes(mot));
      } else {
        // Pour les factures
        const contenu = [
          f.numero,
          f.fournisseur,
          f.typeFrais,
          ...(f.lignes || []).map(l => {
            const eq = equipements.find(e => e.id === parseInt(l.equipementId));
            return `${eq?.immat || ''} ${l.description}`;
          })
        ].join(' ').toLowerCase();
        return mots.every(mot => contenu.includes(mot));
      }
    });
  };

  // GET NOM ÉQUIPEMENT
  const getNomEquipement = (equipementId) => {
    const eq = equipements.find(e => e.id === parseInt(equipementId));
    return eq ? `${eq.immat} - ${eq.marque} ${eq.modele}` : 'Inconnu';
  };

  const facturesFiltrees = filtrerFactures();

  return (
    <div className="space-y-4">
      {/* EN-TÊTE */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6 rounded-xl shadow-lg">
        <h2 className="text-3xl font-black mb-2">💰 FACTURES & DOCUMENTS</h2>
        <p className="text-purple-100">Gestion des factures et documents (carte grise, VGP, assurance, CT)</p>
      </div>

      {/* TOGGLE FACTURES / DOCUMENTS */}
      <div className="flex gap-3">
        <button 
          onClick={() => setTypeAffichage('factures')}
          className={`flex-1 px-6 py-4 rounded-lg font-black text-lg transition shadow-md ${
            typeAffichage === 'factures' 
              ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white' 
              : 'bg-white text-gray-700 border-2 border-gray-300 hover:border-purple-400'
          }`}
        >
          💰 Factures ({factures.filter(f => !f.type || f.type === 'facture').length})
        </button>
        <button 
          onClick={() => setTypeAffichage('documents')}
          className={`flex-1 px-6 py-4 rounded-lg font-black text-lg transition shadow-md ${
            typeAffichage === 'documents' 
              ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white' 
              : 'bg-white text-gray-700 border-2 border-gray-300 hover:border-green-400'
          }`}
        >
          📄 Documents ({factures.filter(f => f.type === 'document').length})
        </button>
      </div>

      {/* BARRE RECHERCHE + BOUTON */}
      <div className="flex gap-4">
        <input 
          type="text" 
          placeholder={typeAffichage === 'factures' ? "🔍 Rechercher facture (n°, fournisseur, équipement)..." : "🔍 Rechercher document (titre, type, équipement)..."}
          value={rechercheFacture}
          onChange={(e) => setRechercheFacture(e.target.value)}
          className="flex-1 border-2 border-purple-400 rounded-lg px-4 py-3 font-medium focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition"
        />
        <button 
          onClick={ouvrirModalNouvelleFacture}
          className="bg-green-600 text-white px-6 py-3 rounded-lg font-black hover:bg-green-700 shadow-lg whitespace-nowrap"
        >
          {typeAffichage === 'factures' ? '+ Nouvelle Facture' : '+ Nouveau Document'}
        </button>
      </div>

      {/* COMPTEUR */}
      {rechercheFacture && (
        <div className="text-sm text-purple-700 font-medium flex items-center gap-2">
          🎯 {facturesFiltrees.length} {typeAffichage === 'factures' ? 'facture(s)' : 'document(s)'} trouvé(s) sur {factures.filter(f => typeAffichage === 'factures' ? (!f.type || f.type === 'facture') : f.type === 'document').length}
        </div>
      )}

      {/* LISTE FACTURES OU DOCUMENTS */}
      <div className="bg-white p-4 rounded border">
        {facturesFiltrees.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <div className="text-5xl mb-3">{typeAffichage === 'factures' ? '💰' : '📄'}</div>
            <div className="font-bold text-lg">
              {rechercheFacture ? `Aucun${typeAffichage === 'factures' ? 'e facture' : ' document'} trouvé${typeAffichage === 'factures' ? 'e' : ''}` : `Aucun${typeAffichage === 'factures' ? 'e facture' : ' document'}`}
            </div>
            {!rechercheFacture && (
              <div className="text-sm mt-1">Cliquez sur "{typeAffichage === 'factures' ? '+ Nouvelle Facture' : '+ Nouveau Document'}" pour commencer</div>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {facturesFiltrees.map(item => (
              item.type === 'document' ? (
                /* AFFICHAGE DOCUMENT */
                <div key={item.id} className="border-2 border-green-200 bg-green-50 p-4 rounded-lg">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xl">{item.typeDocument}</span>
                        <span className="font-black text-lg text-green-700">{item.titre}</span>
                      </div>
                      <div className="text-sm text-gray-700 mt-1">
                        🚛 {getNomEquipement(item.equipementId)}
                      </div>
                      {item.dateExpiration && (
                        <div className="text-sm text-gray-600 mt-1">
                          📅 Expire le {new Date(item.dateExpiration).toLocaleDateString('fr-FR')}
                        </div>
                      )}
                      {item.organisme && (
                        <div className="text-sm text-gray-600 mt-1">
                          🏢 {item.organisme}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      {item.pdfUrl && (
                        <button
                          onClick={() => setAfficherScanModal(item)}
                          className="bg-blue-600 text-white px-3 py-1 rounded text-sm font-bold hover:bg-blue-700"
                        >
                          📎 PDF
                        </button>
                      )}
                      <button
                        onClick={() => ouvrirModalEdition(item)}
                        className="bg-orange-600 text-white px-3 py-1 rounded text-sm font-bold hover:bg-orange-700"
                      >
                        ✏️
                      </button>
                      <button
                        onClick={() => supprimerFacture(item.id)}
                        className="bg-red-600 text-white px-3 py-1 rounded text-sm font-bold hover:bg-red-700"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                  {item.notes && (
                    <div className="mt-2 pt-2 border-t border-green-300 text-sm text-gray-600 italic">
                      📝 {item.notes}
                    </div>
                  )}
                </div>
              ) : (
                /* AFFICHAGE FACTURE */
                <div key={item.id} className="border-2 border-purple-200 bg-purple-50 p-4 rounded-lg">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="font-black text-xl text-purple-700">{item.numero}</span>
                        <span className="text-sm bg-purple-200 px-2 py-1 rounded">{item.typeFrais}</span>
                        <span className="text-sm text-gray-600">{new Date(item.date).toLocaleDateString('fr-FR')}</span>
                      </div>
                      <div className="font-bold text-gray-800">{item.fournisseur}</div>
                    </div>
                    <div className="text-right flex flex-col gap-2">
                      <div className="text-2xl font-black text-green-600">{item.totalHT?.toFixed(2)}€</div>
                      <div className="flex gap-2">
                        {item.scanUrl && (
                          <button
                            onClick={() => setAfficherScanModal(item)}
                            className="bg-blue-600 text-white px-3 py-1 rounded text-sm font-bold hover:bg-blue-700"
                          >
                            📎 Scan
                          </button>
                        )}
                        <button
                          onClick={() => ouvrirModalEdition(item)}
                          className="bg-orange-600 text-white px-3 py-1 rounded text-sm font-bold hover:bg-orange-700"
                        >
                          ✏️
                        </button>
                        <button
                          onClick={() => supprimerFacture(item.id)}
                          className="bg-red-600 text-white px-3 py-1 rounded text-sm font-bold hover:bg-red-700"
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 mt-3">
                    {(item.lignes || []).map(ligne => (
                      <div key={ligne.id} className="bg-white p-2 rounded border flex justify-between items-center">
                        <div className="flex-1">
                          <div className="font-medium text-gray-700">{getNomEquipement(ligne.equipementId)}</div>
                          <div className="text-sm text-gray-600">{ligne.description}</div>
                        </div>
                        <div className="text-right">
                          <span className="text-gray-600">{ligne.quantite} × {ligne.prixUnitaire.toFixed(2)}€</span>
                          <span className="text-gray-600 mx-2">=</span>
                          <span className="font-bold text-green-600">{ligne.total.toFixed(2)}€</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {item.notes && (
                    <div className="mt-3 pt-3 border-t text-sm text-gray-600 italic">
                      📝 {item.notes}
                    </div>
                  )}
                </div>
              )
            ))}
          </div>
        )}
      </div>

      {/* MODAL CRÉATION/ÉDITION */}
      {afficherModalFacture && factureEnCours && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-6">
              <h2 className="text-2xl font-black text-purple-700">
                {factureEnCours.type === 'document' 
                  ? (modeEdition ? '✏️ MODIFIER DOCUMENT' : '📄 NOUVEAU DOCUMENT')
                  : (modeEdition ? '✏️ MODIFIER FACTURE' : '💰 NOUVELLE FACTURE')
                }
              </h2>
              <button onClick={fermerModal} className="text-2xl hover:text-red-600">✕</button>
            </div>

            {/* FORMULAIRE DOCUMENT */}
            {factureEnCours.type === 'document' ? (
              <>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Type de document *</label>
                    <select
                      value={nouveauTypeDocumentEnCours ? '➕_NOUVEAU' : factureEnCours.typeDocument}
                      onChange={(e) => {
                        if (e.target.value === '➕_NOUVEAU') {
                          setNouveauTypeDocumentEnCours(true);
                          setFactureEnCours({...factureEnCours, typeDocument: ''});
                        } else {
                          setNouveauTypeDocumentEnCours(false);
                          setFactureEnCours({...factureEnCours, typeDocument: e.target.value});
                        }
                      }}
                      className="w-full border-2 border-green-300 rounded px-3 py-2"
                    >
                      {typesDocuments.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                      <option value="➕_NOUVEAU">➕ Nouveau type...</option>
                    </select>
                    
                    {/* CHAMP POUR NOUVEAU TYPE DOCUMENT */}
                    {nouveauTypeDocumentEnCours && (
                      <div className="mt-2 p-2 bg-blue-50 border-2 border-blue-400 rounded">
                        <label className="block text-xs font-bold text-blue-700 mb-1">Nouveau type :</label>
                        <input
                          type="text"
                          value={nouveauTypeDocumentTexte}
                          onChange={(e) => setNouveauTypeDocumentTexte(e.target.value)}
                          placeholder="Ex: Contrat, Devis..."
                          className="w-full border-2 border-blue-300 rounded px-2 py-1 text-sm mb-1"
                          autoFocus
                        />
                        <div className="flex gap-1">
                          <button
                            type="button"
                            onClick={ajouterTypeDocumentPersonnalise}
                            className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-bold hover:bg-blue-700"
                          >
                            ✓ Ajouter
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setNouveauTypeDocumentEnCours(false);
                              setNouveauTypeDocumentTexte('');
                              setFactureEnCours({...factureEnCours, typeDocument: '🚗 Carte Grise'});
                            }}
                            className="bg-gray-400 text-white px-2 py-1 rounded text-xs font-bold hover:bg-gray-500"
                          >
                            ✗ Annuler
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Équipement *</label>
                    <select
                      value={factureEnCours.equipementId}
                      onChange={(e) => setFactureEnCours({...factureEnCours, equipementId: e.target.value})}
                      className="w-full border-2 border-green-300 rounded px-3 py-2"
                    >
                      <option value="">-- Sélectionner --</option>
                      {equipements.map(eq => (
                        <option key={eq.id} value={eq.id}>
                          {eq.immat} - {eq.marque} {eq.modele}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-bold text-gray-700 mb-1">Titre *</label>
                  <input
                    type="text"
                    placeholder="Ex: Carte Grise GT-316-FG"
                    value={factureEnCours.titre}
                    onChange={(e) => setFactureEnCours({...factureEnCours, titre: e.target.value})}
                    className="w-full border-2 border-green-300 rounded px-3 py-2"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Date d'émission *</label>
                    <input
                      type="date"
                      value={factureEnCours.dateEmission}
                      onChange={(e) => setFactureEnCours({...factureEnCours, dateEmission: e.target.value})}
                      className="w-full border-2 border-green-300 rounded px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Date d'expiration</label>
                    <input
                      type="date"
                      value={factureEnCours.dateExpiration || ''}
                      onChange={(e) => setFactureEnCours({...factureEnCours, dateExpiration: e.target.value || null})}
                      className="w-full border-2 border-green-300 rounded px-3 py-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">Laisser vide si pas d'expiration</p>
                  </div>
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-bold text-gray-700 mb-1">Organisme</label>
                  <input
                    type="text"
                    placeholder="Ex: APAVE, Prefecture..."
                    value={factureEnCours.organisme}
                    onChange={(e) => setFactureEnCours({...factureEnCours, organisme: e.target.value})}
                    className="w-full border-2 border-green-300 rounded px-3 py-2"
                  />
                </div>

                {/* UPLOAD PDF */}
                <div className="mb-6">
                  <label className="block text-sm font-bold text-gray-700 mb-1">📎 Document PDF/Image</label>
                  <input
                    type="file"
                    accept="application/pdf,image/jpeg,image/png"
                    onChange={handleScanUpload}
                    className="w-full border-2 border-green-300 rounded px-3 py-2"
                  />
                  {(scanFacture || factureEnCours.pdfNom) && (
                    <div className="mt-2 text-sm text-green-600 font-medium">
                      ✅ {scanFacture?.name || factureEnCours.pdfNom}
                    </div>
                  )}
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-bold text-gray-700 mb-1">Notes</label>
                  <textarea
                    value={factureEnCours.notes}
                    onChange={(e) => setFactureEnCours({...factureEnCours, notes: e.target.value})}
                    className="w-full border-2 border-green-300 rounded px-3 py-2 h-20"
                    placeholder="Informations complémentaires..."
                  />
                </div>

                <button
                  onClick={enregistrerFacture}
                  className="w-full bg-green-600 text-white px-6 py-3 rounded-lg font-black hover:bg-green-700 text-lg"
                >
                  💾 {modeEdition ? 'Modifier le document' : 'Enregistrer le document'}
                </button>
              </>
            ) : (
              /* FORMULAIRE FACTURE (code existant) */
              <>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">N° Facture *</label>
                    <input 
                      type="text" 
                      value={factureEnCours.numero}
                      onChange={(e) => setFactureEnCours({...factureEnCours, numero: e.target.value})}
                      className="w-full border-2 border-purple-300 rounded px-3 py-2 font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Date *</label>
                    <input 
                      type="date" 
                      value={factureEnCours.date}
                      onChange={(e) => setFactureEnCours({...factureEnCours, date: e.target.value})}
                      className="w-full border-2 border-purple-300 rounded px-3 py-2"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Fournisseur *</label>
                    <input 
                      type="text" 
                      placeholder="Nom du fournisseur"
                      value={factureEnCours.fournisseur}
                      onChange={(e) => setFactureEnCours({...factureEnCours, fournisseur: e.target.value})}
                      className="w-full border-2 border-purple-300 rounded px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Type de frais</label>
                    <select
                      value={nouveauTypeFraisEnCours ? '➕_NOUVEAU' : factureEnCours.typeFrais}
                      onChange={(e) => {
                        if (e.target.value === '➕_NOUVEAU') {
                          setNouveauTypeFraisEnCours(true);
                          setFactureEnCours({...factureEnCours, typeFrais: ''});
                        } else {
                          setNouveauTypeFraisEnCours(false);
                          setFactureEnCours({...factureEnCours, typeFrais: e.target.value});
                        }
                      }}
                      className="w-full border-2 border-purple-300 rounded px-3 py-2"
                    >
                      {typesFrais.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                      <option value="➕_NOUVEAU">➕ Nouveau type...</option>
                    </select>
                    
                    {/* CHAMP POUR NOUVEAU TYPE FRAIS */}
                    {nouveauTypeFraisEnCours && (
                      <div className="mt-2 p-2 bg-blue-50 border-2 border-blue-400 rounded">
                        <label className="block text-xs font-bold text-blue-700 mb-1">Nouveau type :</label>
                        <input
                          type="text"
                          value={nouveauTypeFraisTexte}
                          onChange={(e) => setNouveauTypeFraisTexte(e.target.value)}
                          placeholder="Ex: Parking, Péage..."
                          className="w-full border-2 border-blue-300 rounded px-2 py-1 text-sm mb-1"
                          autoFocus
                        />
                        <div className="flex gap-1">
                          <button
                            type="button"
                            onClick={ajouterTypeFraisPersonnalise}
                            className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-bold hover:bg-blue-700"
                          >
                            ✓ Ajouter
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setNouveauTypeFraisEnCours(false);
                              setNouveauTypeFraisTexte('');
                              setFactureEnCours({...factureEnCours, typeFrais: '🔧 Garage'});
                            }}
                            className="bg-gray-400 text-white px-2 py-1 rounded text-xs font-bold hover:bg-gray-500"
                          >
                            ✗ Annuler
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* LIGNES FACTURE */}
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-3">
                    <label className="text-sm font-bold text-gray-700">Lignes de facture *</label>
                    <button
                      onClick={ajouterLigne}
                      className="bg-blue-600 text-white px-4 py-1 rounded text-sm font-bold hover:bg-blue-700"
                    >
                      + Ajouter ligne
                    </button>
                  </div>

                  <div className="space-y-3">
                    {factureEnCours.lignes.map((ligne, index) => (
                      <div key={ligne.id} className="border-2 border-purple-200 p-3 rounded-lg bg-purple-50">
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-bold text-purple-700">Ligne {index + 1}</span>
                          {factureEnCours.lignes.length > 1 && (
                            <button
                              onClick={() => supprimerLigne(ligne.id)}
                              className="text-red-600 hover:text-red-800 font-bold"
                            >
                              ✕ Supprimer
                            </button>
                          )}
                        </div>

                        <div className="grid grid-cols-12 gap-2">
                          <div className="col-span-3">
                            <select
                              value={ligne.equipementId}
                              onChange={(e) => modifierLigne(ligne.id, 'equipementId', e.target.value)}
                              className="w-full border border-purple-300 rounded px-2 py-1 text-sm"
                            >
                              <option value="">Équipement *</option>
                              {equipements.map(eq => (
                                <option key={eq.id} value={eq.id}>{eq.immat}</option>
                              ))}
                            </select>
                          </div>
                          <div className="col-span-4">
                            <input
                              type="text"
                              placeholder="Description *"
                              value={ligne.description}
                              onChange={(e) => modifierLigne(ligne.id, 'description', e.target.value)}
                              className="w-full border border-purple-300 rounded px-2 py-1 text-sm"
                            />
                          </div>
                          <div className="col-span-2">
                            <input
                              type="number"
                              step="1"
                              min="0"
                              placeholder="Qté *"
                              value={ligne.quantite}
                              onChange={(e) => modifierLigne(ligne.id, 'quantite', parseFloat(e.target.value) || 0)}
                              className="w-full border border-purple-300 rounded px-2 py-1 text-sm"
                            />
                          </div>
                          <div className="col-span-2">
                            <input
                              type="number"
                              step="0.01"
                              min="0"
                              placeholder="Prix €"
                              value={ligne.prixUnitaire}
                              onChange={(e) => modifierLigne(ligne.id, 'prixUnitaire', parseFloat(e.target.value) || 0)}
                              className="w-full border border-purple-300 rounded px-2 py-1 text-sm"
                            />
                          </div>
                          <div className="col-span-1 flex items-center justify-end">
                            <span className="font-bold text-green-600">{ligne.total.toFixed(2)}€</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 flex justify-end">
                    <div className="bg-green-100 border-2 border-green-500 px-4 py-2 rounded-lg">
                      <span className="font-bold text-gray-700">TOTAL HT: </span>
                      <span className="text-2xl font-black text-green-600">{factureEnCours.totalHT.toFixed(2)}€</span>
                    </div>
                  </div>
                </div>

                {/* UPLOAD SCAN */}
                <div className="mb-6">
                  <label className="block text-sm font-bold text-gray-700 mb-1">📎 Scan de la facture (optionnel)</label>
                  <input
                    type="file"
                    accept="application/pdf,image/jpeg,image/png"
                    onChange={handleScanUpload}
                    className="w-full border-2 border-purple-300 rounded px-3 py-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">PDF, JPG ou PNG - Max 5MB</p>
                  {(scanFacture || factureEnCours.scanNom) && (
                    <div className="mt-2 text-sm text-green-600 font-medium">
                      ✅ {scanFacture?.name || factureEnCours.scanNom}
                    </div>
                  )}
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-bold text-gray-700 mb-1">Notes</label>
                  <textarea
                    value={factureEnCours.notes}
                    onChange={(e) => setFactureEnCours({...factureEnCours, notes: e.target.value})}
                    className="w-full border-2 border-purple-300 rounded px-3 py-2 h-20"
                    placeholder="Informations complémentaires..."
                  />
                </div>

                <button
                  onClick={enregistrerFacture}
                  className="w-full bg-purple-600 text-white px-6 py-3 rounded-lg font-black hover:bg-purple-700 text-lg"
                >
                  💾 {modeEdition ? 'Modifier la facture' : 'Enregistrer la facture'}
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* MODAL VISUALISATION PDF */}
      {afficherScanModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 max-w-4xl w-full max-h-[90vh] overflow-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-black">
                {afficherScanModal.type === 'document' ? afficherScanModal.titre : `Scan ${afficherScanModal.numero}`}
              </h3>
              <button onClick={() => setAfficherScanModal(null)} className="text-2xl hover:text-red-600">✕</button>
            </div>

            {afficherScanModal.pdfUrl || afficherScanModal.scanUrl ? (
              <>
                {(afficherScanModal.pdfNom || afficherScanModal.scanNom)?.endsWith('.pdf') ? (
                  /* AFFICHAGE PDF avec iframe - meilleur support mobile */
                  <iframe 
                    src={afficherScanModal.pdfUrl || afficherScanModal.scanUrl} 
                    width="100%" 
                    height="600px" 
                    className="rounded-lg shadow-lg border-2 border-gray-300"
                    title="Visualisation PDF"
                  />
                ) : (
                  /* IMAGE - Affichage normal */
                  <img 
                    src={afficherScanModal.pdfUrl || afficherScanModal.scanUrl} 
                    alt="Document" 
                    className="w-full rounded-lg shadow-lg" 
                  />
                )}

                <div className="mt-6 flex justify-center gap-3">
                  <a
                    href={afficherScanModal.pdfUrl || afficherScanModal.scanUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-green-600 text-white px-6 py-3 rounded-lg font-black hover:bg-green-700 shadow-lg"
                  >
                    🔗 Ouvrir
                  </a>
                  <a
                    href={afficherScanModal.pdfUrl || afficherScanModal.scanUrl}
                    download={afficherScanModal.pdfNom || afficherScanModal.scanNom || `document_${afficherScanModal.id}.pdf`}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg font-black hover:bg-blue-700 shadow-lg"
                  >
                    📥 Télécharger
                  </a>
                  <button
                    onClick={() => setAfficherScanModal(null)}
                    className="bg-gray-600 text-white px-6 py-3 rounded-lg font-black hover:bg-gray-700 shadow-lg"
                  >
                    Fermer
                  </button>
                </div>
              </>
            ) : (
              <p className="text-gray-500 text-center py-8">Aucun document disponible</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default FacturesDocuments;