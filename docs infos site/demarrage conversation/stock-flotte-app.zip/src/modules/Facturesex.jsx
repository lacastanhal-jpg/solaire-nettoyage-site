// Module FACTURES - Solaire Nettoyage V3.4
// Gestion complète des factures multi-lignes avec scan
import React, { useState } from 'react';

const Factures = ({
  factures,
  setFactures,
  equipements,
  updateFactures
}) => {

  // ÉTATS LOCAUX
  const [rechercheFacture, setRechercheFacture] = useState('');
  const [afficherModalFacture, setAfficherModalFacture] = useState(false);
  const [factureEnCours, setFactureEnCours] = useState(null);
  const [modeEdition, setModeEdition] = useState(false);
  const [scanFacture, setScanFacture] = useState(null);
  const [afficherScanModal, setAfficherScanModal] = useState(null);

  // TYPES DE FRAIS
  const typesFrais = [
    '🔧 Garage',
    '⛽ Carburant', 
    '🛣️ Péage',
    '🛡️ Assurance',
    '🔩 Pièces détachées',
    '🧽 Nettoyage',
    '📋 Contrôle technique',
    '📄 Autre'
  ];

  // INITIALISER NOUVELLE FACTURE
  const initialiserNouvelleFacture = () => {
    const dernierNumero = factures.length > 0 
      ? Math.max(...factures.map(f => parseInt(f.numero.split('-')[2]) || 0))
      : 0;
    const nouveauNumero = `FAC-${new Date().getFullYear()}-${String(dernierNumero + 1).padStart(3, '0')}`;
    
    return {
      id: Date.now(),
      numero: nouveauNumero,
      fournisseur: '',
      typeFrais: '🔧 Garage',
      date: new Date().toISOString().split('T')[0],
      lignes: [
        {
          id: 1,
          equipementId: '',
          description: '',
          quantite: 1,
          prixUnitaire: 0,
          total: 0
        }
      ],
      totalHT: 0,
      scanUrl: null,
      scanNom: null,
      operateur: 'Jerome',
      notes: ''
    };
  };

  // OUVRIR MODAL NOUVELLE FACTURE
  const ouvrirNouvelleFacture = () => {
    setFactureEnCours(initialiserNouvelleFacture());
    setModeEdition(false);
    setScanFacture(null);
    setAfficherModalFacture(true);
  };

  // OUVRIR MODAL ÉDITION
  const ouvrirEditionFacture = (facture) => {
    setFactureEnCours({ ...facture });
    setModeEdition(true);
    setScanFacture(null);
    setAfficherModalFacture(true);
  };

  // AJOUTER LIGNE
  const ajouterLigne = () => {
    const nouvelleLigne = {
      id: Date.now(),
      equipementId: '',
      description: '',
      quantite: 1,
      prixUnitaire: 0,
      total: 0
    };
    setFactureEnCours({
      ...factureEnCours,
      lignes: [...factureEnCours.lignes, nouvelleLigne]
    });
  };

  // SUPPRIMER LIGNE
  const supprimerLigne = (ligneId) => {
    if (factureEnCours.lignes.length === 1) {
      alert('⚠️ Impossible de supprimer la dernière ligne !');
      return;
    }
    const nouvellesLignes = factureEnCours.lignes.filter(l => l.id !== ligneId);
    recalculerTotal({ ...factureEnCours, lignes: nouvellesLignes });
  };

  // MODIFIER LIGNE
  const modifierLigne = (ligneId, champ, valeur) => {
    const nouvellesLignes = factureEnCours.lignes.map(ligne => {
      if (ligne.id === ligneId) {
        const ligneModifiee = { ...ligne, [champ]: valeur };
        // Recalculer le total de la ligne
        if (champ === 'quantite' || champ === 'prixUnitaire') {
          ligneModifiee.total = (ligneModifiee.quantite || 0) * (ligneModifiee.prixUnitaire || 0);
        }
        return ligneModifiee;
      }
      return ligne;
    });
    recalculerTotal({ ...factureEnCours, lignes: nouvellesLignes });
  };

  // RECALCULER TOTAL
  const recalculerTotal = (facture) => {
    const totalHT = facture.lignes.reduce((sum, ligne) => sum + (ligne.total || 0), 0);
    setFactureEnCours({ ...facture, totalHT });
  };

  // GÉRER UPLOAD SCAN
  const gererUploadScan = (e) => {
    const fichier = e.target.files[0];
    if (!fichier) return;

    // Vérifier type de fichier
    const typesAcceptes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
    if (!typesAcceptes.includes(fichier.type)) {
      alert('⚠️ Format non accepté ! Utilisez PDF, JPG ou PNG.');
      return;
    }

    // Vérifier taille (max 5 MB)
    if (fichier.size > 5 * 1024 * 1024) {
      alert('⚠️ Fichier trop volumineux ! Maximum 5 MB.');
      return;
    }

    // Convertir en base64 pour stockage Firebase
    const lecteur = new FileReader();
    lecteur.onload = (event) => {
      setScanFacture({
        nom: fichier.name,
        data: event.target.result,
        type: fichier.type
      });
    };
    lecteur.readAsDataURL(fichier);
  };

  // ENREGISTRER FACTURE
  const enregistrerFacture = () => {
    // Validation
    if (!factureEnCours.fournisseur.trim()) {
      alert('⚠️ Le fournisseur est obligatoire !');
      return;
    }

    // Vérifier qu'au moins une ligne est complète
    const lignesValides = factureEnCours.lignes.filter(l => 
      l.equipementId && l.description.trim() && l.quantite > 0 && l.prixUnitaire > 0
    );

    if (lignesValides.length === 0) {
      alert('⚠️ Au moins une ligne complète est nécessaire !');
      return;
    }

    // Préparer la facture finale
    const factureFinale = {
      ...factureEnCours,
      lignes: lignesValides,
      scanUrl: scanFacture ? scanFacture.data : factureEnCours.scanUrl,
      scanNom: scanFacture ? scanFacture.nom : factureEnCours.scanNom
    };

    if (modeEdition) {
      // Mise à jour
      updateFactures(factures.map(f => f.id === factureFinale.id ? factureFinale : f));
    } else {
      // Création
      updateFactures([...factures, factureFinale]);
    }

    fermerModal();
  };

  // SUPPRIMER FACTURE
  const supprimerFacture = (factureId) => {
    if (window.confirm('⚠️ Supprimer cette facture définitivement ?')) {
      updateFactures(factures.filter(f => f.id !== factureId));
    }
  };

  // FERMER MODAL
  const fermerModal = () => {
    setAfficherModalFacture(false);
    setFactureEnCours(null);
    setScanFacture(null);
    setModeEdition(false);
  };

  // FILTRER FACTURES
  const filtrerFactures = () => {
    if (!rechercheFacture.trim()) return factures;
    
    const mots = rechercheFacture.toLowerCase().trim().split(/\s+/);
    
    return factures.filter(f => {
      const contenu = [
        f.numero,
        f.fournisseur,
        f.typeFrais,
        ...f.lignes.map(l => {
          const eq = equipements.find(e => e.id === parseInt(l.equipementId));
          return `${eq?.immat || ''} ${l.description}`;
        })
      ].join(' ').toLowerCase();
      
      return mots.every(mot => contenu.includes(mot));
    });
  };

  // GET NOM ÉQUIPEMENT
  const getNomEquipement = (equipementId) => {
    const eq = equipements.find(e => e.id === parseInt(equipementId));
    return eq ? `${eq.immat} - ${eq.marque} ${eq.modele}` : 'Inconnu';
  };

  // CALCULER TOTAL PAR ÉQUIPEMENT
  const calculerTotalEquipement = (equipementId) => {
    return factures.reduce((total, facture) => {
      const lignesEquipement = facture.lignes.filter(l => 
        parseInt(l.equipementId) === parseInt(equipementId)
      );
      return total + lignesEquipement.reduce((sum, l) => sum + (l.total || 0), 0);
    }, 0);
  };

  const facturesFiltrees = filtrerFactures();

  return (
    <div className="space-y-4">
      {/* EN-TÊTE */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6 rounded-xl shadow-lg">
        <h2 className="text-3xl font-black mb-2">💰 FACTURES</h2>
        <p className="text-purple-100">Gestion des factures multi-lignes avec archivage</p>
      </div>

      {/* BARRE RECHERCHE + BOUTON */}
      <div className="flex gap-4">
        <input 
          type="text" 
          placeholder="🔍 Rechercher facture (n°, fournisseur, équipement)..." 
          value={rechercheFacture}
          onChange={(e) => setRechercheFacture(e.target.value)}
          className="flex-1 border-2 border-purple-400 rounded-lg px-4 py-3 font-medium focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition"
        />
        <button 
          onClick={ouvrirNouvelleFacture}
          className="bg-green-600 text-white px-6 py-3 rounded-lg font-black hover:bg-green-700 shadow-lg whitespace-nowrap"
        >
          + Nouvelle Facture
        </button>
      </div>

      {/* COMPTEUR */}
      {rechercheFacture && (
        <div className="text-sm text-purple-700 font-medium flex items-center gap-2">
          🎯 {facturesFiltrees.length} facture(s) trouvée(s) sur {factures.length}
        </div>
      )}

      {/* LISTE FACTURES */}
      <div className="bg-white p-4 rounded border">
        {facturesFiltrees.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <div className="text-5xl mb-3">💰</div>
            <div className="font-bold text-lg">
              {rechercheFacture ? 'Aucune facture trouvée' : 'Aucune facture'}
            </div>
            {!rechercheFacture && (
              <div className="text-sm mt-1">Cliquez sur "+ Nouvelle Facture" pour commencer</div>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {facturesFiltrees.map(facture => (
              <div key={facture.id} className="border-2 border-purple-200 rounded-lg p-4 hover:bg-purple-50 transition">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xl font-black text-purple-700">{facture.numero}</span>
                      <span className="bg-purple-100 px-3 py-1 rounded text-sm font-bold text-purple-700">
                        {facture.typeFrais}
                      </span>
                      <span className="text-gray-500 text-sm">{facture.date}</span>
                    </div>
                    <div className="text-lg font-bold text-gray-800 mb-1">{facture.fournisseur}</div>
                    <div className="text-sm text-gray-600">
                      {facture.lignes.length} ligne{facture.lignes.length > 1 ? 's' : ''} • 
                      {facture.lignes.map(l => l.equipementId).filter((v, i, a) => a.indexOf(v) === i).length} équipement{facture.lignes.map(l => l.equipementId).filter((v, i, a) => a.indexOf(v) === i).length > 1 ? 's' : ''}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-black text-green-600 mb-2">
                      {facture.totalHT.toFixed(2)}€
                    </div>
                    <div className="flex gap-2">
                      {facture.scanUrl && (
                        <button 
                          onClick={() => setAfficherScanModal(facture)}
                          className="bg-blue-600 text-white px-3 py-1 rounded text-sm font-bold hover:bg-blue-700"
                          title="Voir le scan"
                        >
                          📎 Scan
                        </button>
                      )}
                      <button 
                        onClick={() => ouvrirEditionFacture(facture)}
                        className="bg-orange-600 text-white px-3 py-1 rounded text-sm font-bold hover:bg-orange-700"
                      >
                        ✏️ Modifier
                      </button>
                      <button 
                        onClick={() => supprimerFacture(facture.id)}
                        className="bg-red-600 text-white px-3 py-1 rounded text-sm font-bold hover:bg-red-700"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                </div>

                {/* LIGNES DÉTAIL */}
                <div className="border-t pt-3 space-y-2">
                  {facture.lignes.map((ligne, idx) => (
                    <div key={ligne.id} className="flex justify-between items-center bg-gray-50 p-2 rounded text-sm">
                      <div className="flex-1">
                        <span className="font-bold text-purple-600">{getNomEquipement(ligne.equipementId)}</span>
                        <span className="text-gray-600 mx-2">•</span>
                        <span>{ligne.description}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-gray-600">{ligne.quantite} × {ligne.prixUnitaire.toFixed(2)}€</span>
                        <span className="text-gray-600 mx-2">=</span>
                        <span className="font-bold text-green-600">{ligne.total.toFixed(2)}€</span>
                      </div>
                    </div>
                  ))}
                </div>

                {facture.notes && (
                  <div className="mt-3 pt-3 border-t text-sm text-gray-600 italic">
                    📝 {facture.notes}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* MODAL CRÉATION/ÉDITION FACTURE */}
      {afficherModalFacture && factureEnCours && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-6">
              <h2 className="text-2xl font-black text-purple-700">
                {modeEdition ? '✏️ MODIFIER FACTURE' : '💰 NOUVELLE FACTURE'}
              </h2>
              <button onClick={fermerModal} className="text-2xl hover:text-red-600">✕</button>
            </div>

            {/* EN-TÊTE FACTURE */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">N° Facture *</label>
                <input 
                  type="text" 
                  value={factureEnCours.numero}
                  onChange={(e) => setFactureEnCours({...factureEnCours, numero: e.target.value})}
                  className="w-full border-2 border-purple-300 rounded px-3 py-2 font-bold"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Date *</label>
                <input 
                  type="date" 
                  value={factureEnCours.date}
                  onChange={(e) => setFactureEnCours({...factureEnCours, date: e.target.value})}
                  className="w-full border-2 border-purple-300 rounded px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Fournisseur *</label>
                <input 
                  type="text" 
                  value={factureEnCours.fournisseur}
                  onChange={(e) => setFactureEnCours({...factureEnCours, fournisseur: e.target.value})}
                  placeholder="Nom du fournisseur"
                  className="w-full border-2 border-purple-300 rounded px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Type de frais *</label>
                <select 
                  value={factureEnCours.typeFrais}
                  onChange={(e) => setFactureEnCours({...factureEnCours, typeFrais: e.target.value})}
                  className="w-full border-2 border-purple-300 rounded px-3 py-2"
                >
                  {typesFrais.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* LIGNES DE DÉTAIL */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-lg font-black text-gray-800">📋 LIGNES DE DÉTAIL</h3>
                <button 
                  onClick={ajouterLigne}
                  className="bg-blue-600 text-white px-4 py-2 rounded font-bold hover:bg-blue-700"
                >
                  + Ajouter ligne
                </button>
              </div>

              <div className="space-y-3">
                {factureEnCours.lignes.map((ligne, index) => (
                  <div key={ligne.id} className="border-2 border-gray-200 rounded-lg p-3 bg-gray-50">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-bold text-gray-700">Ligne {index + 1}</span>
                      {factureEnCours.lignes.length > 1 && (
                        <button 
                          onClick={() => supprimerLigne(ligne.id)}
                          className="text-red-600 hover:text-red-800 font-bold"
                        >
                          ✕ Supprimer
                        </button>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-12 gap-2">
                      <div className="col-span-4">
                        <label className="block text-xs font-bold text-gray-600 mb-1">Équipement *</label>
                        <select 
                          value={ligne.equipementId}
                          onChange={(e) => modifierLigne(ligne.id, 'equipementId', e.target.value)}
                          className="w-full border border-gray-300 rounded px-2 py-2 text-sm"
                        >
                          <option value="">Sélectionner...</option>
                          {equipements.map(eq => (
                            <option key={eq.id} value={eq.id}>
                              {eq.immat} - {eq.marque} {eq.modele}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="col-span-4">
                        <label className="block text-xs font-bold text-gray-600 mb-1">Description *</label>
                        <input 
                          type="text" 
                          value={ligne.description}
                          onChange={(e) => modifierLigne(ligne.id, 'description', e.target.value)}
                          placeholder="Ex: Vidange + filtre"
                          className="w-full border border-gray-300 rounded px-2 py-2 text-sm"
                        />
                      </div>
                      <div className="col-span-1">
                        <label className="block text-xs font-bold text-gray-600 mb-1">Qté *</label>
                        <input 
                          type="number" 
                          min="1"
                          value={ligne.quantite}
                          onChange={(e) => modifierLigne(ligne.id, 'quantite', parseFloat(e.target.value) || 0)}
                          className="w-full border border-gray-300 rounded px-2 py-2 text-sm"
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="block text-xs font-bold text-gray-600 mb-1">Prix unit. *</label>
                        <input 
                          type="number" 
                          min="0"
                          step="0.01"
                          value={ligne.prixUnitaire}
                          onChange={(e) => modifierLigne(ligne.id, 'prixUnitaire', parseFloat(e.target.value) || 0)}
                          className="w-full border border-gray-300 rounded px-2 py-2 text-sm"
                        />
                      </div>
                      <div className="col-span-1">
                        <label className="block text-xs font-bold text-gray-600 mb-1">Total</label>
                        <div className="w-full border border-gray-300 rounded px-2 py-2 text-sm bg-green-50 font-bold text-green-700 text-right">
                          {ligne.total.toFixed(2)}€
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* TOTAL */}
            <div className="bg-green-50 border-2 border-green-500 rounded-lg p-4 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-xl font-black text-gray-800">TOTAL HT</span>
                <span className="text-3xl font-black text-green-700">{factureEnCours.totalHT.toFixed(2)}€</span>
              </div>
            </div>

            {/* SCAN FACTURE */}
            <div className="mb-6">
              <label className="block text-sm font-bold text-gray-700 mb-2">📎 Scan de la facture</label>
              <input 
                type="file" 
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={gererUploadScan}
                className="w-full border-2 border-dashed border-purple-300 rounded px-4 py-3 hover:border-purple-500 transition"
              />
              {(scanFacture || factureEnCours.scanUrl) && (
                <div className="mt-2 flex items-center gap-2 text-sm text-green-700 font-bold">
                  ✅ {scanFacture?.nom || factureEnCours.scanNom}
                </div>
              )}
              <div className="text-xs text-gray-500 mt-1">
                Formats acceptés : PDF, JPG, PNG (max 5 MB)
              </div>
            </div>

            {/* NOTES */}
            <div className="mb-6">
              <label className="block text-sm font-bold text-gray-700 mb-2">📝 Notes (optionnel)</label>
              <textarea 
                value={factureEnCours.notes}
                onChange={(e) => setFactureEnCours({...factureEnCours, notes: e.target.value})}
                placeholder="Remarques, détails supplémentaires..."
                rows="3"
                className="w-full border-2 border-gray-300 rounded px-3 py-2"
              />
            </div>

            {/* BOUTONS */}
            <div className="flex gap-3">
              <button 
                onClick={enregistrerFacture}
                className="flex-1 bg-green-600 text-white px-6 py-3 rounded font-black hover:bg-green-700"
              >
                💾 {modeEdition ? 'Mettre à jour' : 'Enregistrer'}
              </button>
              <button 
                onClick={fermerModal}
                className="flex-1 bg-gray-400 text-white px-6 py-3 rounded font-black hover:bg-gray-500"
              >
                ✕ Annuler
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL VISUALISATION SCAN */}
      {afficherScanModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-black text-purple-700">📎 SCAN FACTURE</h2>
              <button 
                onClick={() => setAfficherScanModal(null)} 
                className="text-2xl hover:text-red-600"
              >
                ✕
              </button>
            </div>
            
            <div className="mb-4">
              <div className="text-sm text-gray-600 mb-2">
                <strong>Facture :</strong> {afficherScanModal.numero} - {afficherScanModal.fournisseur}
              </div>
              <div className="text-sm text-gray-600">
                <strong>Fichier :</strong> {afficherScanModal.scanNom}
              </div>
            </div>

            <div className="border-2 border-gray-300 rounded-lg overflow-hidden">
              {afficherScanModal.scanUrl?.startsWith('data:application/pdf') ? (
                <embed 
                  src={afficherScanModal.scanUrl} 
                  type="application/pdf" 
                  width="100%" 
                  height="600px"
                />
              ) : (
                <img 
                  src={afficherScanModal.scanUrl} 
                  alt="Scan facture" 
                  className="w-full h-auto"
                />
              )}
            </div>

            <div className="flex gap-3 mt-4">
              <a 
                href={afficherScanModal.scanUrl}
                download={afficherScanModal.scanNom}
                className="flex-1 bg-blue-600 text-white px-6 py-3 rounded font-black hover:bg-blue-700 text-center"
              >
                💾 Télécharger
              </a>
              <button 
                onClick={() => setAfficherScanModal(null)}
                className="flex-1 bg-gray-400 text-white px-6 py-3 rounded font-black hover:bg-gray-500"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Factures;