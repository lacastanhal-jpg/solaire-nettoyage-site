// Module STOCK - Solaire Nettoyage V3.0
// Gestion des entrées/sorties/transferts avec scanner QR
import React, { useEffect } from 'react';

const Stock = ({
  articles,
  setArticles,
  equipements,
  depots,
  mouvementsStock,
  setMouvementsStock,
  afficherScannerQR,
  setAfficherScannerQR,
  scanResultat,
  setScanResultat,
  actionScan,
  setActionScan,
  formScanEntree,
  setFormScanEntree,
  formScanSortie,
  setFormScanSortie,
  formScanTransfert,
  setFormScanTransfert,
  nouvelleEntreeStock,
  setNouvelleEntreeStock,
  nouveauMouvementSortie,
  setNouveauMouvementSortie,
  nouveauTransfert,
  setNouveauTransfert,
  getStockTotal,
  updateArticles,
  updateMouvements,
  videoRef,
  canvasRef,
  scanningRef,
  jsQRRef,
  videoStream,
  setVideoStream
}) => {

  // FONCTION TRAITER SCAN QR
  const traiterScanQR = (code) => {
    const article = articles.find(a => a.code === code);
    if (article) {
      setScanResultat({ success: true, article, code });
      setActionScan(null);
    } else {
      setScanResultat({ success: false, code });
      setActionScan(null);
    }
  };

  // SCANNER QR EFFECT
  useEffect(() => {
    if (!afficherScannerQR || !videoRef.current || !canvasRef.current || scanResultat) return;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    let lastDetectedCode = null;
    let lastDetectedTime = 0;
    
    const tick = () => {
      try {
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
          const videoWidth = video.videoWidth;
          const videoHeight = video.videoHeight;
          if (videoWidth > 0 && videoHeight > 0) {
            canvas.width = videoWidth;
            canvas.height = videoHeight;
            ctx.drawImage(video, 0, 0, videoWidth, videoHeight);
            const imageData = ctx.getImageData(0, 0, videoWidth, videoHeight);
            const jsQR = jsQRRef.current || window.jsQR;
            if (jsQR && typeof jsQR === 'function') {
              const code = jsQR(imageData.data, videoWidth, videoHeight);
              if (code && code.data) {
                const now = Date.now();
                if (code.data !== lastDetectedCode || now - lastDetectedTime > 5000) {
                  lastDetectedCode = code.data;
                  lastDetectedTime = now;
                  traiterScanQR(code.data);
                }
              }
            }
          }
        }
      } catch (err) {
        console.error('Erreur scan:', err);
      }
      scanningRef.current = requestAnimationFrame(tick);
    };
    
    scanningRef.current = requestAnimationFrame(tick);
    return () => {
      if (scanningRef.current) cancelAnimationFrame(scanningRef.current);
    };
  }, [afficherScannerQR, scanResultat, videoRef, canvasRef, scanningRef, jsQRRef]);

  // FONCTIONS SCANNER
  const toggleScannerQR = async () => {
    if (afficherScannerQR) {
      if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
        setVideoStream(null);
      }
      setAfficherScannerQR(false);
    } else {
      setAfficherScannerQR(true);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setVideoStream(stream);
      } catch (err) {
        alert('Caméra non disponible');
        setAfficherScannerQR(false);
      }
    }
  };

  // FONCTIONS SCAN - ENTRÉE/SORTIE/TRANSFERT
  const enregistrerEntreeStockScan = () => {
    if (!formScanEntree.quantite || !formScanEntree.prixUnitaire) { 
      alert('Quantité et prix requis'); 
      return; 
    }
    const quantite = parseInt(formScanEntree.quantite);
    const coutTotal = parseFloat(formScanEntree.prixUnitaire) * quantite;
    
    updateArticles(articles.map(a => a.id === scanResultat.article.id ? { 
      ...a, 
      stockParDepot: { 
        ...a.stockParDepot, 
        [formScanEntree.depot]: (a.stockParDepot[formScanEntree.depot] || 0) + quantite 
      } 
    } : a));
    
    updateMouvements([...mouvementsStock, { 
      id: mouvementsStock.length + 1, 
      articleId: scanResultat.article.id, 
      type: 'entree', 
      quantite, 
      date: formScanEntree.date, 
      raison: formScanEntree.raison, 
      coutTotal, 
      depot: formScanEntree.depot 
    }]);
    
    alert(`✅ +${quantite} ${scanResultat.article.code}`);
    setScanResultat(null);
    setActionScan(null);
    setFormScanEntree({ quantite: '', prixUnitaire: '', raison: '', date: new Date().toISOString().split('T')[0], depot: 'Atelier' });
  };

  const enregistrerSortieStockScan = () => {
    if (!formScanSortie.quantite) { 
      alert('Quantité requise'); 
      return; 
    }
    const quantite = parseInt(formScanSortie.quantite);
    if ((scanResultat.article.stockParDepot[formScanSortie.depot] || 0) < quantite) { 
      alert('Stock insuffisant!'); 
      return; 
    }
    
    updateArticles(articles.map(a => a.id === scanResultat.article.id ? { 
      ...a, 
      stockParDepot: { 
        ...a.stockParDepot, 
        [formScanSortie.depot]: (a.stockParDepot[formScanSortie.depot] || 0) - quantite 
      } 
    } : a));
    
    updateMouvements([...mouvementsStock, { 
      id: mouvementsStock.length + 1, 
      articleId: scanResultat.article.id, 
      type: 'sortie', 
      quantite, 
      date: formScanSortie.date, 
      raison: formScanSortie.raison, 
      coutTotal: 0, 
      depot: formScanSortie.depot 
    }]);
    
    alert(`✅ -${quantite} ${scanResultat.article.code}`);
    setScanResultat(null);
    setActionScan(null);
    setFormScanSortie({ quantite: '', raison: '', date: new Date().toISOString().split('T')[0], depot: 'Atelier' });
  };

  const enregistrerTransfertStockScan = () => {
    if (!formScanTransfert.quantite || formScanTransfert.depotSource === formScanTransfert.depotDestination) { 
      alert('Quantité et dépôts différents requis'); 
      return; 
    }
    const quantite = parseInt(formScanTransfert.quantite);
    if ((scanResultat.article.stockParDepot[formScanTransfert.depotSource] || 0) < quantite) { 
      alert('Stock insuffisant!'); 
      return; 
    }
    
    updateArticles(articles.map(a => a.id === scanResultat.article.id ? { 
      ...a, 
      stockParDepot: { 
        ...a.stockParDepot, 
        [formScanTransfert.depotSource]: (a.stockParDepot[formScanTransfert.depotSource] || 0) - quantite, 
        [formScanTransfert.depotDestination]: (a.stockParDepot[formScanTransfert.depotDestination] || 0) + quantite 
      } 
    } : a));
    
    updateMouvements([...mouvementsStock, { 
      id: mouvementsStock.length + 1, 
      articleId: scanResultat.article.id, 
      type: 'transfer', 
      quantite, 
      date: new Date().toISOString().split('T')[0], 
      raison: `Transfert`, 
      coutTotal: 0, 
      depotSource: formScanTransfert.depotSource, 
      depotDestination: formScanTransfert.depotDestination 
    }]);
    
    alert(`✅ ${quantite} ${scanResultat.article.code}`);
    setScanResultat(null);
    setActionScan(null);
    setFormScanTransfert({ quantite: '', depotSource: 'Atelier', depotDestination: 'Porteur 26 T' });
  };

  // FONCTIONS FORMULAIRES MANUELS
  const enregistrerEntreeStock = () => {
    if (nouvelleEntreeStock.articleId && nouvelleEntreeStock.quantite && nouvelleEntreeStock.prixUnitaire) {
      const quantite = parseInt(nouvelleEntreeStock.quantite);
      const coutTotal = parseFloat(nouvelleEntreeStock.prixUnitaire) * quantite;
      
      updateArticles(articles.map(a => a.id === parseInt(nouvelleEntreeStock.articleId) ? { 
        ...a, 
        stockParDepot: { 
          ...a.stockParDepot, 
          [nouvelleEntreeStock.depot]: (a.stockParDepot[nouvelleEntreeStock.depot] || 0) + quantite 
        } 
      } : a));
      
      updateMouvements([...mouvementsStock, { 
        id: mouvementsStock.length + 1, 
        articleId: parseInt(nouvelleEntreeStock.articleId), 
        type: 'entree', 
        quantite, 
        date: nouvelleEntreeStock.date, 
        raison: nouvelleEntreeStock.raison, 
        coutTotal, 
        depot: nouvelleEntreeStock.depot 
      }]);
      
      setNouvelleEntreeStock({ articleId: '', quantite: '', prixUnitaire: '', raison: '', date: new Date().toISOString().split('T')[0], depot: 'Atelier' });
    }
  };

  const enregistrerSortieStock = () => {
    if (nouveauMouvementSortie.articleId && nouveauMouvementSortie.quantite) {
      const article = articles.find(a => a.id === parseInt(nouveauMouvementSortie.articleId));
      const quantite = parseInt(nouveauMouvementSortie.quantite);
      if ((article.stockParDepot[nouveauMouvementSortie.depot] || 0) < quantite) { 
        alert('Stock insuffisant!'); 
        return; 
      }
      
      updateArticles(articles.map(a => a.id === parseInt(nouveauMouvementSortie.articleId) ? { 
        ...a, 
        stockParDepot: { 
          ...a.stockParDepot, 
          [nouveauMouvementSortie.depot]: (a.stockParDepot[nouveauMouvementSortie.depot] || 0) - quantite 
        } 
      } : a));
      
      updateMouvements([...mouvementsStock, { 
        id: mouvementsStock.length + 1, 
        articleId: parseInt(nouveauMouvementSortie.articleId), 
        type: 'sortie', 
        quantite, 
        date: nouveauMouvementSortie.date, 
        raison: nouveauMouvementSortie.raison, 
        coutTotal: 0, 
        depot: nouveauMouvementSortie.depot 
      }]);
      
      setNouveauMouvementSortie({ articleId: '', quantite: '', raison: '', date: new Date().toISOString().split('T')[0], depot: 'Atelier' });
    }
  };

  const enregistrerTransfertStock = () => {
    if (nouveauTransfert.articleId && nouveauTransfert.quantite && nouveauTransfert.depotSource !== nouveauTransfert.depotDestination) {
      const article = articles.find(a => a.id === parseInt(nouveauTransfert.articleId));
      const quantite = parseInt(nouveauTransfert.quantite);
      if ((article.stockParDepot[nouveauTransfert.depotSource] || 0) < quantite) { 
        alert('Stock insuffisant!'); 
        return; 
      }
      
      updateArticles(articles.map(a => a.id === parseInt(nouveauTransfert.articleId) ? { 
        ...a, 
        stockParDepot: { 
          ...a.stockParDepot, 
          [nouveauTransfert.depotSource]: (a.stockParDepot[nouveauTransfert.depotSource] || 0) - quantite, 
          [nouveauTransfert.depotDestination]: (a.stockParDepot[nouveauTransfert.depotDestination] || 0) + quantite 
        } 
      } : a));
      
      updateMouvements([...mouvementsStock, { 
        id: mouvementsStock.length + 1, 
        articleId: parseInt(nouveauTransfert.articleId), 
        type: 'transfer', 
        quantite, 
        date: nouveauTransfert.date, 
        raison: `Transfert`, 
        coutTotal: 0, 
        depotSource: nouveauTransfert.depotSource, 
        depotDestination: nouveauTransfert.depotDestination 
      }]);
      
      setNouveauTransfert({ articleId: '', quantite: '', depotSource: 'Atelier', depotDestination: 'Porteur 26 T', raison: '', date: new Date().toISOString().split('T')[0] });
    }
  };

  // FONCTION AFFECTATION ÉQUIPEMENTS
  const affecterArticleEquipement = (articleId, equipementId) => {
    updateArticles(articles.map(a => {
      if (a.id === articleId) {
        const eqId = parseInt(equipementId);
        return a.equipementsAffectes.includes(eqId) 
          ? { ...a, equipementsAffectes: a.equipementsAffectes.filter(e => e !== eqId) }
          : { ...a, equipementsAffectes: [...a.equipementsAffectes, eqId] };
      }
      return a;
    }));
  };

  return (
    <div className="space-y-6">
      {/* SCANNER QR */}
      <div className="bg-indigo-100 border-2 border-indigo-400 p-4 rounded">
        <h3 className="font-bold mb-3">📱 Scanner QR Code</h3>
        <button 
          onClick={toggleScannerQR} 
          className={`px-4 py-2 rounded font-bold text-white ${afficherScannerQR ? 'bg-red-600 hover:bg-red-700' : 'bg-indigo-600 hover:bg-indigo-700'}`}
        >
          {afficherScannerQR ? '❌ Fermer Scanner' : '📷 Activer Scanner'}
        </button>
        
        {afficherScannerQR && !scanResultat && (
          <div className="mt-4">
            <div className="bg-gray-900 rounded overflow-hidden" style={{maxWidth: '400px'}}>
              <video ref={videoRef} autoPlay playsInline muted style={{width: '100%', display: 'block'}} />
              <canvas ref={canvasRef} style={{display: 'none'}} />
            </div>
            <div className="mt-3">
              <input 
                type="text" 
                placeholder="Entrer code article ou scanner QR" 
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && e.target.value) {
                    traiterScanQR(e.target.value); 
                    e.target.value = '';
                  }
                }} 
                className="w-full border-2 border-indigo-300 rounded px-3 py-2 font-bold" 
              />
            </div>
            <div className="mt-2 text-sm text-indigo-700 font-semibold">🎯 Scanner actif</div>
          </div>
        )}
        
        {scanResultat && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl shadow-2xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto">
              <div className="text-center mb-4">
                {scanResultat.success ? (
                  <>
                    <div className="text-4xl mb-2">✅</div>
                    <h3 className="text-xl font-black text-green-600">Article détecté !</h3>
                  </>
                ) : (
                  <>
                    <div className="text-4xl mb-2">❌</div>
                    <h3 className="text-xl font-black text-red-600">Article non trouvé</h3>
                  </>
                )}
              </div>
              
              {scanResultat.success && (
                <>
                  <div className="bg-green-50 p-4 rounded-lg mb-4 border-2 border-green-300">
                    <div className="font-bold text-lg text-green-700">{scanResultat.article.code}</div>
                    <div className="text-sm text-gray-700 mt-1">{scanResultat.article.description}</div>
                    <div className="text-xs text-gray-600 mt-2">Fournisseur: {scanResultat.article.fournisseur}</div>
                    <div className="text-sm font-bold text-green-600 mt-2">Stock: {getStockTotal(scanResultat.article)}</div>
                  </div>
                  
                  {!actionScan ? (
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <button onClick={() => setActionScan('entree')} className="bg-green-600 text-white px-3 py-3 rounded font-bold text-sm hover:bg-green-700">📥 Entrée</button>
                      <button onClick={() => setActionScan('sortie')} className="bg-red-600 text-white px-3 py-3 rounded font-bold text-sm hover:bg-red-700">📤 Sortie</button>
                      <button onClick={() => setActionScan('transfert')} className="bg-amber-600 text-white px-3 py-3 rounded font-bold text-sm hover:bg-amber-700">🔄 Transfer</button>
                    </div>
                  ) : actionScan === 'entree' ? (
                    <div className="bg-green-50 p-4 rounded-lg mb-4 border-2 border-green-300">
                      <h4 className="font-bold text-green-700 mb-3">📥 Entrée de Stock</h4>
                      <div className="space-y-2">
                        <input type="number" placeholder="Quantité *" value={formScanEntree.quantite} onChange={(e) => setFormScanEntree({...formScanEntree, quantite: e.target.value})} className="w-full border rounded px-2 py-1" />
                        <input type="number" step="0.01" placeholder="Prix unitaire *" value={formScanEntree.prixUnitaire} onChange={(e) => setFormScanEntree({...formScanEntree, prixUnitaire: e.target.value})} className="w-full border rounded px-2 py-1" />
                        <input placeholder="Raison" value={formScanEntree.raison} onChange={(e) => setFormScanEntree({...formScanEntree, raison: e.target.value})} className="w-full border rounded px-2 py-1" />
                        <select value={formScanEntree.depot} onChange={(e) => setFormScanEntree({...formScanEntree, depot: e.target.value})} className="w-full border rounded px-2 py-1">
                          {depots.map(d => <option key={d} value={d}>{d}</option>)}
                        </select>
                        <input type="date" value={formScanEntree.date} onChange={(e) => setFormScanEntree({...formScanEntree, date: e.target.value})} className="w-full border rounded px-2 py-1" />
                      </div>
                      <div className="flex gap-2 mt-3">
                        <button onClick={enregistrerEntreeStockScan} className="flex-1 bg-green-600 text-white px-3 py-2 rounded font-bold">✓ Valider</button>
                        <button onClick={() => setActionScan(null)} className="flex-1 bg-gray-400 text-white px-3 py-2 rounded font-bold">↩️ Retour</button>
                      </div>
                    </div>
                  ) : actionScan === 'sortie' ? (
                    <div className="bg-red-50 p-4 rounded-lg mb-4 border-2 border-red-300">
                      <h4 className="font-bold text-red-700 mb-3">📤 Sortie de Stock</h4>
                      <div className="space-y-2">
                        <input type="number" placeholder="Quantité *" value={formScanSortie.quantite} onChange={(e) => setFormScanSortie({...formScanSortie, quantite: e.target.value})} className="w-full border rounded px-2 py-1" />
                        <input placeholder="Raison" value={formScanSortie.raison} onChange={(e) => setFormScanSortie({...formScanSortie, raison: e.target.value})} className="w-full border rounded px-2 py-1" />
                        <select value={formScanSortie.depot} onChange={(e) => setFormScanSortie({...formScanSortie, depot: e.target.value})} className="w-full border rounded px-2 py-1">
                          {depots.map(d => <option key={d} value={d}>{d}</option>)}
                        </select>
                        <input type="date" value={formScanSortie.date} onChange={(e) => setFormScanSortie({...formScanSortie, date: e.target.value})} className="w-full border rounded px-2 py-1" />
                      </div>
                      <div className="flex gap-2 mt-3">
                        <button onClick={enregistrerSortieStockScan} className="flex-1 bg-red-600 text-white px-3 py-2 rounded font-bold">✓ Valider</button>
                        <button onClick={() => setActionScan(null)} className="flex-1 bg-gray-400 text-white px-3 py-2 rounded font-bold">↩️ Retour</button>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-amber-50 p-4 rounded-lg mb-4 border-2 border-amber-300">
                      <h4 className="font-bold text-amber-700 mb-3">🔄 Transfert</h4>
                      <div className="space-y-2">
                        <input type="number" placeholder="Quantité *" value={formScanTransfert.quantite} onChange={(e) => setFormScanTransfert({...formScanTransfert, quantite: e.target.value})} className="w-full border rounded px-2 py-1" />
                        <select value={formScanTransfert.depotSource} onChange={(e) => setFormScanTransfert({...formScanTransfert, depotSource: e.target.value})} className="w-full border rounded px-2 py-1">
                          {depots.map(d => <option key={d} value={d}>{d}</option>)}
                        </select>
                        <select value={formScanTransfert.depotDestination} onChange={(e) => setFormScanTransfert({...formScanTransfert, depotDestination: e.target.value})} className="w-full border rounded px-2 py-1">
                          {depots.map(d => <option key={d} value={d}>{d}</option>)}
                        </select>
                      </div>
                      <div className="flex gap-2 mt-3">
                        <button onClick={enregistrerTransfertStockScan} className="flex-1 bg-amber-600 text-white px-3 py-2 rounded font-bold">✓ Valider</button>
                        <button onClick={() => setActionScan(null)} className="flex-1 bg-gray-400 text-white px-3 py-2 rounded font-bold">↩️ Retour</button>
                      </div>
                    </div>
                  )}
                </>
              )}
              
              {!scanResultat.success && (
                <div className="flex gap-2">
                  <button onClick={() => setScanResultat(null)} className="flex-1 bg-blue-600 text-white px-4 py-2 rounded font-bold">🔄 Rescanner</button>
                  <button onClick={() => {setAfficherScannerQR(false); setScanResultat(null);}} className="flex-1 bg-gray-400 text-white px-4 py-2 rounded font-bold">✕ Fermer</button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ENTRÉE */}
      <div className="bg-green-50 border-2 border-green-300 p-4 rounded">
        <h3 className="font-bold mb-3">📥 Entrée</h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
          <select value={nouvelleEntreeStock.articleId} onChange={(e) => setNouvelleEntreeStock({...nouvelleEntreeStock, articleId: e.target.value})} className="border rounded px-2 py-1">
            <option value="">Article</option>
            {articles.map(a => <option key={a.id} value={a.id}>{a.code}</option>)}
          </select>
          <input type="number" placeholder="Qté" value={nouvelleEntreeStock.quantite} onChange={(e) => setNouvelleEntreeStock({...nouvelleEntreeStock, quantite: e.target.value})} className="border rounded px-2 py-1" />
          <input type="number" step="0.01" placeholder="Prix" value={nouvelleEntreeStock.prixUnitaire} onChange={(e) => setNouvelleEntreeStock({...nouvelleEntreeStock, prixUnitaire: e.target.value})} className="border rounded px-2 py-1" />
          <input placeholder="Raison" value={nouvelleEntreeStock.raison} onChange={(e) => setNouvelleEntreeStock({...nouvelleEntreeStock, raison: e.target.value})} className="border rounded px-2 py-1" />
          <button onClick={enregistrerEntreeStock} className="bg-green-600 text-white px-3 py-1 rounded font-bold">Entrer</button>
        </div>
      </div>

      {/* SORTIE */}
      <div className="bg-red-50 border-2 border-red-300 p-4 rounded">
        <h3 className="font-bold mb-3">📤 Sortie</h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
          <select value={nouveauMouvementSortie.articleId} onChange={(e) => setNouveauMouvementSortie({...nouveauMouvementSortie, articleId: e.target.value})} className="border rounded px-2 py-1">
            <option value="">Article</option>
            {articles.map(a => <option key={a.id} value={a.id}>{a.code}</option>)}
          </select>
          <input type="number" placeholder="Qté" value={nouveauMouvementSortie.quantite} onChange={(e) => setNouveauMouvementSortie({...nouveauMouvementSortie, quantite: e.target.value})} className="border rounded px-2 py-1" />
          <input placeholder="Raison" value={nouveauMouvementSortie.raison} onChange={(e) => setNouveauMouvementSortie({...nouveauMouvementSortie, raison: e.target.value})} className="border rounded px-2 py-1" />
          <input type="date" value={nouveauMouvementSortie.date} onChange={(e) => setNouveauMouvementSortie({...nouveauMouvementSortie, date: e.target.value})} className="border rounded px-2 py-1" />
          <button onClick={enregistrerSortieStock} className="bg-red-600 text-white px-3 py-1 rounded font-bold">Sortir</button>
        </div>
      </div>

      {/* TRANSFERT */}
      <div className="bg-amber-50 border-2 border-amber-400 p-4 rounded">
        <h3 className="font-bold mb-3">🔄 Transfert</h3>
        <div className="grid grid-cols-1 md:grid-cols-6 gap-2">
          <select value={nouveauTransfert.articleId} onChange={(e) => setNouveauTransfert({...nouveauTransfert, articleId: e.target.value})} className="border rounded px-2 py-1">
            <option value="">Article</option>
            {articles.map(a => <option key={a.id} value={a.id}>{a.code}</option>)}
          </select>
          <select value={nouveauTransfert.depotSource} onChange={(e) => setNouveauTransfert({...nouveauTransfert, depotSource: e.target.value})} className="border rounded px-2 py-1">
            {depots.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          <select value={nouveauTransfert.depotDestination} onChange={(e) => setNouveauTransfert({...nouveauTransfert, depotDestination: e.target.value})} className="border rounded px-2 py-1">
            {depots.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          <input type="number" placeholder="Qté" value={nouveauTransfert.quantite} onChange={(e) => setNouveauTransfert({...nouveauTransfert, quantite: e.target.value})} className="border rounded px-2 py-1" />
          <input placeholder="Note" value={nouveauTransfert.raison} onChange={(e) => setNouveauTransfert({...nouveauTransfert, raison: e.target.value})} className="border rounded px-2 py-1" />
          <button onClick={enregistrerTransfertStock} className="bg-amber-600 text-white px-3 py-1 rounded font-bold">Transférer</button>
        </div>
      </div>

      {/* AFFECTATION ARTICLES AUX ÉQUIPEMENTS */}
      <div className="bg-white p-4 rounded border">
        <h3 className="font-bold text-lg mb-3">🎯 Affecter articles aux équipements</h3>
        <div className="space-y-2">
          {articles.map(a => {
            const equipAffectes = equipements.filter(e => a.equipementsAffectes.includes(e.id));
            const isAffecte = a.equipementsAffectes.length > 0;
            return (
              <div key={a.id} className={`flex justify-between items-center p-3 rounded border-2 ${isAffecte ? 'bg-blue-100 border-blue-400' : 'bg-gray-50 border-gray-200'}`}>
                <div className="flex-1">
                  <div className="font-semibold">{a.code} - {a.description}</div>
                  <div className="text-xs text-gray-600">
                    Stock total: {getStockTotal(a)} × {isAffecte ? `✓ Affecté à: ${equipAffectes.map(e => e.immat).join(', ')}` : 'Non affecté'}
                  </div>
                </div>
                <div className="flex gap-1 ml-2 flex-wrap">
                  {equipements.map(e => (
                    <button 
                      key={e.id} 
                      onClick={() => affecterArticleEquipement(a.id, e.id)} 
                      className={`px-3 py-1 rounded text-xs font-bold whitespace-nowrap transition ${
                        a.equipementsAffectes.includes(e.id) 
                          ? 'bg-blue-600 text-white shadow-md' 
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      }`}
                    >
                      {e.immat}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Stock;
