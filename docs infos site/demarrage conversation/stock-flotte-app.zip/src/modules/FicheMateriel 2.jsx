import React, { useState } from 'react';

const FicheMateriel = ({ 
  equipements,
  articles,
  accessoiresEquipement,
  setAccessoiresEquipement,
  interventions,
  equipementSelectionne,  // AJOUT - État centralisé depuis App.jsx
  setEquipementSelectionne, // AJOUT - Setter centralisé depuis App.jsx
  factures
}) => {
  if (!factures) factures = [];

  // SUPPRIMÉ : const [equipementSelectionne, setEquipementSelectionne] = useState(1);
  // On utilise maintenant les props depuis App.jsx
  
  const [nouvelAccessoire, setNouvelAccessoire] = useState({ 
    nom: '', 
    valeur: '', 
    description: '', 
    dateAjout: new Date().toISOString().split('T')[0] 
  });
  
  const [afficherModalAjoutAccessoire, setAfficherModalAjoutAccessoire] = useState(false);
  const [pdfAffiche, setPdfAffiche] = useState(null);

  const getStockTotal = (article) => {
    const depots = ['Atelier', 'Porteur 26 T', 'Porteur 32 T', 'Semi Remorque'];
    return depots.reduce((sum, depot) => sum + (article.stockParDepot[depot] || 0), 0);
  };

  const ajouterAccessoire = (equipementId) => {
    if (nouvelAccessoire.nom && nouvelAccessoire.valeur) {
      const nouveauxAccessoires = [...(accessoiresEquipement[equipementId] || []), { 
        id: Date.now(), 
        ...nouvelAccessoire, 
        valeur: parseFloat(nouvelAccessoire.valeur) 
      }];
      setAccessoiresEquipement({ ...accessoiresEquipement, [equipementId]: nouveauxAccessoires });
      setNouvelAccessoire({ nom: '', valeur: '', description: '', dateAjout: new Date().toISOString().split('T')[0] });
    }
  };

  const supprimerAccessoire = (equipementId, accessoireId) => {
    setAccessoiresEquipement({ 
      ...accessoiresEquipement, 
      [equipementId]: (accessoiresEquipement[equipementId] || []).filter(a => a.id !== accessoireId) 
    });
  };

  const exporterPDF = () => {
    const equipSelectionne = equipements.find(e => e.immat === equipementSelectionne);
    const eqInterventions = interventions.filter(i => i.equipementId === equipSelectionne?.id);
    const eqAccessoires = accessoiresEquipement[equipementSelectionne] || [];
    const coutTotal = eqInterventions.filter(i => i.statut === 'effectue').reduce((sum, i) => sum + (i.coutTotal || 0), 0);

    let html = `
      <html>
        <head>
          <meta charset="UTF-8">
          <title>Fiche Matériel ${equipSelectionne?.immat}</title>
          <style>
            body { font-family: Arial; margin: 20px; color: #333; }
            h1 { color: #f97316; border-bottom: 3px solid #f97316; padding-bottom: 10px; }
            h2 { color: #ea580c; margin-top: 25px; border-left: 5px solid #ea580c; padding-left: 10px; }
            .header { background: linear-gradient(to right, #f97316, #fbbf24); color: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
            .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin: 20px 0; }
            .box { border: 2px solid #ddd; padding: 15px; border-radius: 8px; }
            .box-title { font-weight: bold; color: #ea580c; margin-bottom: 10px; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
            th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
            th { background-color: #f97316; color: white; }
            .total { font-size: 24px; font-weight: bold; color: #ea580c; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>${equipSelectionne?.immat}</h1>
            <p>${equipSelectionne?.marque} ${equipSelectionne?.modele} - ${equipSelectionne?.annee}</p>
          </div>

          <div class="grid">
            <div class="box">
              <div class="box-title">INFORMATIONS GÉNÉRALES</div>
              <p><strong>VIN:</strong> ${equipSelectionne?.vin}</p>
              <p><strong>Type:</strong> ${equipSelectionne?.type}</p>
              <p><strong>Carburant:</strong> ${equipSelectionne?.carburant}</p>
              <p><strong>PTAC:</strong> ${equipSelectionne?.ptac} kg</p>
            </div>
            <div class="box">
              <div class="box-title">VALEURS</div>
              <p><strong>Valeur d'achat:</strong> ${equipSelectionne?.valeurAchat}€</p>
              <p><strong>Valeur actuelle:</strong> ${equipSelectionne?.valeurActuelle}€</p>
              <p><strong>Accessoires:</strong> ${eqAccessoires.reduce((s, a) => s + a.valeur, 0).toFixed(2)}€</p>
              <p class="total">TOTAL: ${(equipSelectionne?.valeurActuelle + eqAccessoires.reduce((s, a) => s + a.valeur, 0)).toFixed(2)}€</p>
            </div>
          </div>

          ${eqAccessoires.length > 0 ? `
            <h2>ACCESSOIRES</h2>
            <table>
              <tr>
                <th>Nom</th>
                <th>Description</th>
                <th>Valeur</th>
                <th>Date ajout</th>
                <th>Statut</th>
              </tr>
              ${eqAccessoires.map(a => `
                <tr>
                  <td>${a.nom}</td>
                  <td>${a.description}</td>
                  <td>${a.valeur.toFixed(2)}€</td>
                  <td>${a.dateAjout}</td>
                  <td>${a.actif ? 'Actif' : 'Inactif'}</td>
                </tr>
              `).join('')}
            </table>
          ` : ''}

          <p style="margin-top: 30px; text-align: center; color: #999; font-size: 12px;">
            Document généré le ${new Date().toLocaleDateString('fr-FR')} - Solaire Nettoyage
          </p>
        </body>
      </html>
    `;

    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write(html);
    printWindow.document.close();
    setTimeout(() => printWindow.print(), 250);
  };

  const equipSelectionne = equipements.find(e => e.immat === equipementSelectionne);
  const accessoiresTotal = (accessoiresEquipement[equipementSelectionne] || []).reduce((sum, a) => sum + a.valeur, 0);
  const valeurEquipementTotal = (equipSelectionne?.valeurActuelle || 0) + accessoiresTotal;
  const articlesAffectesEquipement = articles.filter(a => (a.equipementsAffectes || []).includes(equipSelectionne?.id));

  // Factures
  const facturesEquipement = equipSelectionne && factures && Array.isArray(factures) ? factures.flatMap(facture => {
    if (!facture || !facture.lignes || !Array.isArray(facture.lignes)) return [];
    return facture.lignes
      .filter(ligne => {
        const eqId = String(ligne.equipementId);
        const selId = String(equipSelectionne.id);
        return eqId === selId;
      })
      .map(ligne => ({
        ...facture,
        ligneConcernee: ligne
      }));
  }) : [];
  const totalFraisEquipement = facturesEquipement.reduce((sum, f) => sum + (f.ligneConcernee?.total || 0), 0);
  
  // Documents de cet équipement
  const documentsEquipement = equipSelectionne && factures ? factures.filter(f => 
    f.type === 'document' && String(f.equipementId) === String(equipSelectionne.id)
  ) : [];


  return (
    <div className="space-y-6">
      <div className="sticky top-20 z-20">
        <div className="flex gap-3 overflow-x-auto pb-2 snap-x snap-mandatory" style={{scrollBehavior: 'smooth'}}>
          {equipements.map(eq => (
            <button 
              key={eq.id} 
              onClick={() => setEquipementSelectionne(eq.immat)} 
              className={`px-4 py-4 rounded-lg font-semibold transition whitespace-nowrap snap-center flex-shrink-0 ${
                equipementSelectionne === eq.immat 
                  ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-lg' 
                  : 'bg-white text-gray-800 border-2 border-gray-200'
              }`}
            >
              <div className="text-lg">{eq.immat}</div>
              <div className="text-sm mt-1">{eq.marque} {eq.modele}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-orange-500 to-yellow-400 text-white p-8 rounded-xl shadow-lg">
        <h2 className="text-5xl font-black mb-2">{equipSelectionne?.immat}</h2>
        <p className="text-xl">{equipSelectionne?.marque} {equipSelectionne?.modele}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-blue-500">
          <div className="text-blue-600 font-bold text-sm">VALEUR D'ACHAT</div>
          <div className="text-3xl font-black text-blue-600 mt-2">{equipSelectionne?.valeurAchat}€</div>
        </div>
        <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-green-500">
          <div className="text-green-600 font-bold text-sm">VALEUR ACTUELLE</div>
          <div className="text-3xl font-black text-green-700 mt-2">{equipSelectionne?.valeurActuelle}€</div>
        </div>
        <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-indigo-500">
          <div className="text-indigo-600 font-bold text-sm">ACCESSOIRES</div>
          <div className="text-3xl font-black text-indigo-700 mt-2">{Math.round(accessoiresTotal)}€</div>
        </div>
        <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-orange-500">
          <div className="text-orange-600 font-bold text-sm">VALEUR TOTALE</div>
          <div className="text-3xl font-black text-orange-700 mt-2">{Math.round(valeurEquipementTotal)}€</div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-lg font-black text-gray-800 mb-4 pb-3 border-b-3 border-purple-500">📦 ARTICLES AFFECTÉS</h3>
        {articlesAffectesEquipement.length === 0 ? (
          <p className="text-gray-500 italic">Aucun article affecté</p>
        ) : (
          <div className="space-y-2">
            {articlesAffectesEquipement.map(a => (
              <div key={a.id} className="flex justify-between p-3 bg-purple-50 rounded-lg border">
                <div>
                  <div className="font-bold text-purple-700">{a.code}</div>
                  <div className="text-sm text-gray-600">{a.description}</div>
                </div>
                <div className="text-right">
                  <div className="text-purple-600 font-bold">Total: {getStockTotal(a)}</div>
                  <div className="text-sm">{a.prixUnitaire}€ u.</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex justify-between items-center mb-4 pb-3 border-b-3 border-green-500">
          <h3 className="text-lg font-black text-gray-800">💰 FACTURES & FRAIS</h3>
          <div className="text-2xl font-black text-green-700">{totalFraisEquipement.toFixed(2)}€</div>
        </div>
        
        {facturesEquipement.length === 0 ? (
          <p className="text-gray-500 italic">Aucune facture enregistrée</p>
        ) : (
          <div className="space-y-3">
            {facturesEquipement.map((f, idx) => (
              <div 
                key={`${f.id}-${idx}`} 
                onClick={() => f.scanUrl && setPdfAffiche(f)}
                className={`p-3 bg-green-50 rounded-lg border-2 border-green-200 transition ${f.scanUrl ? 'cursor-pointer hover:bg-green-100 hover:border-green-400 hover:shadow-lg' : ''}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-green-700">{f.numero}</span>
                      <span className="text-xs bg-green-200 px-2 py-1 rounded">{f.typeFrais}</span>
                      <span className="text-xs text-gray-500">{f.date}</span>
                      {f.scanUrl && <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded font-bold">📎 PDF</span>}
                    </div>
                    <div className="text-sm text-gray-700 font-medium">{f.fournisseur}</div>
                    <div className="text-sm text-gray-600 mt-1">{f.ligneConcernee.description}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-black text-green-600">
                      {f.ligneConcernee.total.toFixed(2)}€
                    </div>
                    <div className="text-xs text-gray-500">
                      {f.ligneConcernee.quantite} × {f.ligneConcernee.prixUnitaire.toFixed(2)}€
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex justify-between items-center mb-4 pb-3 border-b-3 border-blue-500">
          <h3 className="text-lg font-black text-gray-800">📄 DOCUMENTS & CONFORMITÉ</h3>
        </div>
        {documentsEquipement.length === 0 ? (
          <p className="text-gray-500 italic">Aucun document enregistré</p>
        ) : (
          <div className="space-y-3">
            {documentsEquipement.map((doc, idx) => {
              const estExpire = doc.dateExpiration && new Date(doc.dateExpiration) < new Date();
              const expireBientot = doc.dateExpiration && new Date(doc.dateExpiration) < new Date(Date.now() + 30*24*60*60*1000);
              
              return (
                <div 
                  key={`${doc.id}-${idx}`} 
                  onClick={() => doc.pdfUrl && setPdfAffiche(doc)}
                  className={`p-3 rounded-lg border-2 transition ${
                    estExpire 
                      ? 'bg-red-50 border-red-300' + (doc.pdfUrl ? ' cursor-pointer hover:bg-red-100 hover:border-red-400 hover:shadow-lg' : '')
                      : expireBientot 
                      ? 'bg-orange-50 border-orange-300' + (doc.pdfUrl ? ' cursor-pointer hover:bg-orange-100 hover:border-orange-400 hover:shadow-lg' : '')
                      : 'bg-blue-50 border-blue-200' + (doc.pdfUrl ? ' cursor-pointer hover:bg-blue-100 hover:border-blue-400 hover:shadow-lg' : '')
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xl">{doc.typeDocument}</span>
                        <span className="font-bold text-blue-700">{doc.titre}</span>
                        {doc.pdfUrl && <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded font-bold">📎 PDF</span>}
                        {estExpire && <span className="text-xs bg-red-500 text-white px-2 py-1 rounded font-bold">EXPIRÉ</span>}
                        {!estExpire && expireBientot && <span className="text-xs bg-orange-500 text-white px-2 py-1 rounded font-bold">EXPIRE BIENTÔT</span>}
                        {!estExpire && !expireBientot && doc.dateExpiration && <span className="text-xs bg-green-500 text-white px-2 py-1 rounded font-bold">✅ CONFORME</span>}
                      </div>
                      <div className="text-sm text-gray-600 mt-1">
                        📅 Émis le {new Date(doc.dateEmission).toLocaleDateString('fr-FR')}
                      </div>
                      {doc.dateExpiration && (
                        <div className={`text-sm font-medium mt-1 ${estExpire ? 'text-red-600' : expireBientot ? 'text-orange-600' : 'text-gray-600'}`}>
                          ⏰ Expire le {new Date(doc.dateExpiration).toLocaleDateString('fr-FR')}
                        </div>
                      )}
                      {doc.organisme && (
                        <div className="text-sm text-gray-600 mt-1">
                          🏢 {doc.organisme}
                        </div>
                      )}
                    </div>
                  </div>
                  {doc.notes && (
                    <div className="mt-2 pt-2 border-t text-sm text-gray-600 italic">
                      📝 {doc.notes}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex justify-between items-center mb-4 pb-3 border-b-3 border-pink-500">
          <h3 className="text-lg font-black text-gray-800">🎨 ACCESSOIRES</h3>
          <button 
            onClick={exporterPDF} 
            className="bg-orange-600 text-white px-4 py-2 rounded font-bold hover:bg-orange-700"
          >
            📄 Export PDF
          </button>
        </div>
        
        <div className="bg-pink-50 border-2 border-pink-300 p-4 rounded-lg mb-4">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
            <input 
              type="text" 
              placeholder="Nom" 
              value={nouvelAccessoire.nom} 
              onChange={(e) => setNouvelAccessoire({...nouvelAccessoire, nom: e.target.value})} 
              className="border-2 border-pink-300 rounded px-3 py-2" 
            />
            <input 
              type="number" 
              step="0.01" 
              placeholder="Valeur €" 
              value={nouvelAccessoire.valeur} 
              onChange={(e) => setNouvelAccessoire({...nouvelAccessoire, valeur: e.target.value})} 
              className="border-2 border-pink-300 rounded px-3 py-2" 
            />
            <input 
              type="text" 
              placeholder="Description" 
              value={nouvelAccessoire.description} 
              onChange={(e) => setNouvelAccessoire({...nouvelAccessoire, description: e.target.value})} 
              className="border-2 border-pink-300 rounded px-3 py-2 col-span-2" 
            />
            <button 
              onClick={() => ajouterAccessoire(equipementSelectionne)} 
              className="bg-pink-500 text-white px-4 py-2 rounded font-bold"
            >
              Ajouter
            </button>
          </div>
        </div>

        {(accessoiresEquipement[equipementSelectionne] || []).length === 0 ? (
          <p className="text-gray-500">Aucun accessoire</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {(accessoiresEquipement[equipementSelectionne] || []).map(acc => (
              <div key={acc.id} className="bg-pink-50 p-4 rounded-lg border-2 border-pink-200">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2 flex-1">
                    <input 
                      type="checkbox" 
                      checked={acc.actif} 
                      onChange={() => setAccessoiresEquipement({
                        ...accessoiresEquipement, 
                        [equipementSelectionne]: (accessoiresEquipement[equipementSelectionne] || []).map(a => 
                          a.id === acc.id ? {...a, actif: !a.actif} : a
                        )
                      })} 
                      className="w-4 h-4" 
                    />
                    <div className="font-bold text-pink-700">{acc.nom}</div>
                  </div>
                  <div className="text-xl font-black text-green-600">{acc.valeur.toFixed(2)}€</div>
                </div>
                <p className="text-sm text-gray-700 mb-2">{acc.description}</p>
                <button 
                  onClick={() => supprimerAccessoire(equipementSelectionne, acc.id)} 
                  className="text-red-600 font-bold text-sm"
                >
                  Supprimer
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* MODAL VISUALISATION PDF */}
      {pdfAffiche && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 max-w-4xl w-full max-h-[90vh] overflow-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-black">
                {pdfAffiche.type === 'document' ? pdfAffiche.titre : `${pdfAffiche.numero} - ${pdfAffiche.fournisseur}`}
              </h3>
              <button onClick={() => setPdfAffiche(null)} className="text-2xl hover:text-red-600 font-bold">✕</button>
            </div>

            {(pdfAffiche.pdfUrl || pdfAffiche.scanUrl) ? (
              <>
                {((pdfAffiche.pdfNom || pdfAffiche.scanNom)?.endsWith('.pdf')) ? (
                  /* AFFICHAGE PDF avec iframe - meilleur support mobile */
                  <iframe 
                    src={pdfAffiche.pdfUrl || pdfAffiche.scanUrl} 
                    width="100%" 
                    height="800px" 
                    className="rounded-lg shadow-lg border-2 border-gray-300"
                    title="Visualisation PDF"
                  />
                ) : (
                  /* IMAGE - Affichage normal */
                  <img 
                    src={pdfAffiche.pdfUrl || pdfAffiche.scanUrl} 
                    alt="Document" 
                    className="w-full rounded-lg shadow-lg"
                  />
                )}

                <div className="mt-6 flex justify-center gap-3">
                  <a
                    href={pdfAffiche.pdfUrl || pdfAffiche.scanUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-green-600 text-white px-6 py-3 rounded-lg font-black hover:bg-green-700 shadow-lg"
                  >
                    🔗 Ouvrir
                  </a>
                  <a
                    href={pdfAffiche.pdfUrl || pdfAffiche.scanUrl}
                    download={pdfAffiche.pdfNom || pdfAffiche.scanNom || `document_${pdfAffiche.id}.pdf`}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg font-black hover:bg-blue-700 shadow-lg"
                  >
                    📥 Télécharger
                  </a>
                  <button
                    onClick={() => setPdfAffiche(null)}
                    className="bg-gray-600 text-white px-6 py-3 rounded-lg font-black hover:bg-gray-700 shadow-lg"
                  >
                    Fermer
                  </button>
                </div>
              </>
            ) : (
              <p className="text-gray-500 text-center py-8">Aucun document disponible</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default FicheMateriel;