import React, { useState } from 'react';

const Alertes = ({ 
  articles,
  updateArticles,
  mouvementsStock,
  updateMouvements,
  depots,
  panierCommande,
  setPanierCommande
}) => {

  const [filtreAlerteSeverite, setFiltreAlerteSeverite] = useState('');
  const [filtreAlerteFournisseur, setFiltreAlerteFournisseur] = useState('');
  const [filtreAlerteDepot, setFiltreAlerteDepot] = useState('');
  const [triAlertes, setTriAlertes] = useState('severite');
  const [articleEnDetailsAlerte, setArticleEnDetailsAlerte] = useState(null);
  const [articleEnTransfertAlerte, setArticleEnTransfertAlerte] = useState(null);
  const [articleEnHistoriqueAlerte, setArticleEnHistoriqueAlerte] = useState(null);
  const [transfertRapideData, setTransfertRapideData] = useState({ depotSource: 'Atelier', depotDestination: 'Porteur 26 T', quantite: '' });

  const getStockTotal = (article) => {
    return depots.reduce((sum, depot) => sum + (article.stockParDepot[depot] || 0), 0);
  };

  const calculerAlertes = () => {
    const alertes = articles.map(article => {
      const total = getStockTotal(article);
      let severite = null;

      if (total === article.stockMin) {
        severite = 'critique';
      }
      else if (total < article.stockMin * 1.5) {
        severite = 'attention';
      }
      else if (depots.some(depot => article.stockParDepot[depot] === 0)) {
        severite = 'vigilance';
      }

      if (severite) {
        return {
          ...article,
          severite,
          depotsVides: depots.filter(d => article.stockParDepot[d] === 0),
          total
        };
      }
      return null;
    }).filter(a => a !== null);

    return alertes;
  };

  const appliquerFiltresAlertes = (alertes) => {
    let filtrées = alertes;

    if (filtreAlerteSeverite) {
      filtrées = filtrées.filter(a => a.severite === filtreAlerteSeverite);
    }
    if (filtreAlerteFournisseur) {
      filtrées = filtrées.filter(a => a.fournisseur === filtreAlerteFournisseur);
    }
    if (filtreAlerteDepot) {
      filtrées = filtrées.filter(a => a.depotsVides.includes(filtreAlerteDepot));
    }

    if (triAlertes === 'severite') {
      filtrées.sort((a, b) => {
        const ordre = { 'critique': 0, 'attention': 1, 'vigilance': 2 };
        return ordre[a.severite] - ordre[b.severite];
      });
    } else if (triAlertes === 'stock') {
      filtrées.sort((a, b) => a.total - b.total);
    } else if (triAlertes === 'nom') {
      filtrées.sort((a, b) => a.code.localeCompare(b.code));
    }

    return filtrées;
  };

  const genererTexteCommande = (article) => {
    const qteACommander = Math.max(0, article.stockMin - getStockTotal(article));
    const existant = panierCommande.find(item => item.articleId === article.id);
    if (existant) { alert('Article déjà dans le panier !'); return; }
    setPanierCommande([...panierCommande, { articleId: article.id, qteEditable: qteACommander, article }]);
  };

  const effectuerTransfertRapide = () => {
    if (!transfertRapideData.quantite || transfertRapideData.depotSource === transfertRapideData.depotDestination) {
      alert('Quantité et dépôts différents requis');
      return;
    }
    const quantite = parseInt(transfertRapideData.quantite);
    if ((articleEnTransfertAlerte.stockParDepot[transfertRapideData.depotSource] || 0) < quantite) {
      alert('Stock insuffisant!');
      return;
    }
    updateArticles(articles.map(a => a.id === articleEnTransfertAlerte.id ? { ...a, stockParDepot: { ...a.stockParDepot, [transfertRapideData.depotSource]: (a.stockParDepot[transfertRapideData.depotSource] || 0) - quantite, [transfertRapideData.depotDestination]: (a.stockParDepot[transfertRapideData.depotDestination] || 0) + quantite } } : a));
    updateMouvements([...mouvementsStock, { id: mouvementsStock.length + 1, articleId: articleEnTransfertAlerte.id, type: 'transfer', quantite, date: new Date().toISOString().split('T')[0], raison: `Transfert rapide alerte`, coutTotal: 0, depotSource: transfertRapideData.depotSource, depotDestination: transfertRapideData.depotDestination }]);
    alert(`✅ ${quantite} ${articleEnTransfertAlerte.code} transférés!`);
    setArticleEnTransfertAlerte(null);
    setTransfertRapideData({ depotSource: 'Atelier', depotDestination: 'Porteur 26 T', quantite: '' });
  };

  const alertesTotales = calculerAlertes();
  const alertesCritiques = alertesTotales.filter(a => a.severite === 'critique');
  const alertesAttention = alertesTotales.filter(a => a.severite === 'attention');
  const alertesVigilance = alertesTotales.filter(a => a.severite === 'vigilance');
  const alertesFiltrees = appliquerFiltresAlertes(alertesTotales);

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-black text-red-700">🚨 ALERTES STOCKS INTELLIGENTES</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-red-50 border-4 border-red-600 p-6 rounded-xl cursor-pointer hover:shadow-lg transition" onClick={() => { setFiltreAlerteSeverite('critique'); setFiltreAlerteFournisseur(''); setFiltreAlerteDepot(''); }}>
          <p className="text-xs text-red-600 font-bold">🔴 CRITIQUES</p>
          <p className="text-5xl font-black text-red-600 mt-2">{alertesCritiques.length}</p>
          <p className="text-sm text-red-700 mt-2">⚡ Action immédiate!</p>
        </div>
        <div className="bg-orange-50 border-4 border-orange-500 p-6 rounded-xl cursor-pointer hover:shadow-lg transition" onClick={() => { setFiltreAlerteSeverite('attention'); setFiltreAlerteFournisseur(''); setFiltreAlerteDepot(''); }}>
          <p className="text-xs text-orange-600 font-bold">🟠 ATTENTION</p>
          <p className="text-5xl font-black text-orange-600 mt-2">{alertesAttention.length}</p>
          <p className="text-sm text-orange-700 mt-2">⏳ À court terme</p>
        </div>
        <div className="bg-yellow-50 border-4 border-yellow-500 p-6 rounded-xl cursor-pointer hover:shadow-lg transition" onClick={() => { setFiltreAlerteSeverite('vigilance'); setFiltreAlerteFournisseur(''); setFiltreAlerteDepot(''); }}>
          <p className="text-xs text-yellow-600 font-bold">🟡 VIGILANCE</p>
          <p className="text-5xl font-black text-yellow-600 mt-2">{alertesVigilance.length}</p>
          <p className="text-sm text-yellow-700 mt-2">👁️ À surveiller</p>
        </div>
      </div>

      <div className="bg-blue-50 border-2 border-blue-300 p-4 rounded-lg">
        <h3 className="font-bold mb-3">🔍 FILTRES & TRI</h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <div>
            <label className="text-xs font-bold text-gray-700">Sévérité</label>
            <select value={filtreAlerteSeverite} onChange={(e) => setFiltreAlerteSeverite(e.target.value)} className="w-full border-2 rounded px-2 py-1 text-sm">
              <option value="">Tous</option>
              <option value="critique">🔴 Critique</option>
              <option value="attention">🟠 Attention</option>
              <option value="vigilance">🟡 Vigilance</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-gray-700">Fournisseur</label>
            <select value={filtreAlerteFournisseur} onChange={(e) => setFiltreAlerteFournisseur(e.target.value)} className="w-full border-2 rounded px-2 py-1 text-sm">
              <option value="">Tous</option>
              {[...new Set(articles.map(a => a.fournisseur))].map(f => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-gray-700">Dépôt vide</label>
            <select value={filtreAlerteDepot} onChange={(e) => setFiltreAlerteDepot(e.target.value)} className="w-full border-2 rounded px-2 py-1 text-sm">
              <option value="">Tous</option>
              {depots.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-gray-700">Tri</label>
            <select value={triAlertes} onChange={(e) => setTriAlertes(e.target.value)} className="w-full border-2 rounded px-2 py-1 text-sm">
              <option value="severite">Par sévérité</option>
              <option value="stock">Stock faible</option>
              <option value="nom">Alphabétique</option>
            </select>
          </div>
          <div>
            <button onClick={() => { setFiltreAlerteSeverite(''); setFiltreAlerteFournisseur(''); setFiltreAlerteDepot(''); }} className="w-full bg-blue-600 text-white px-3 py-1 rounded font-bold text-sm mt-5 hover:bg-blue-700">Réinitialiser</button>
          </div>
        </div>
      </div>

      {alertesFiltrees.length === 0 ? (
        <div className="bg-green-50 border-4 border-green-500 p-6 rounded-lg text-center">
          <p className="text-2xl font-black text-green-700">✅ AUCUNE ALERTE!</p>
          <p className="text-green-600 mt-2">Tous les stocks sont corrects 🎉</p>
        </div>
      ) : (
        <div className="space-y-3">
          {alertesFiltrees.map(article => {
            const barrePourcent = (article.total / article.stockMin) * 100;
            const couleurSeverite = article.severite === 'critique' ? 'border-red-500 bg-red-50' : article.severite === 'attention' ? 'border-orange-500 bg-orange-50' : 'border-yellow-500 bg-yellow-50';
            const icone = article.severite === 'critique' ? '🔴' : article.severite === 'attention' ? '🟠' : '🟡';

            return (
              <div key={article.id} className={`border-l-4 ${couleurSeverite} p-4 rounded-lg`}>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-3">
                  <div>
                    <p className="font-bold text-lg">{article.code}</p>
                    <p className="text-sm text-gray-600">{article.description}</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-gray-600 mb-1">STOCK GLOBAL</p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-300 rounded-full h-3 overflow-hidden">
                        <div 
                          style={{width: `${Math.min(barrePourcent, 100)}%`}} 
                          className={`h-full ${article.severite === 'critique' ? 'bg-red-600' : article.severite === 'attention' ? 'bg-orange-600' : 'bg-yellow-600'}`}
                        />
                      </div>
                      <p className="font-black text-sm">{article.total}/{article.stockMin}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-gray-600 mb-1">DÉPÔTS</p>
                    <div className="grid grid-cols-2 gap-1 text-xs">
                      {depots.map(d => (
                        <p key={d} className={`${article.stockParDepot[d] === 0 ? 'text-red-600 font-bold' : 'text-gray-700'}`}>
                          {d.substring(0, 3)}: {article.stockParDepot[d] || 0}
                        </p>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-gray-600 mb-1">INFOS</p>
                    <p className="text-sm"><strong>{article.fournisseur}</strong></p>
                    <p className="text-sm">{article.prixUnitaire}€ u.</p>
                    <p className="font-bold mt-1">{icone} {article.severite.toUpperCase()}</p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button onClick={() => genererTexteCommande(article)} className="bg-green-600 text-white px-3 py-2 rounded font-bold text-sm hover:bg-green-700">
                    🛒 Commander
                  </button>
                  <button onClick={() => setArticleEnTransfertAlerte(article)} className="bg-blue-600 text-white px-3 py-2 rounded font-bold text-sm hover:bg-blue-700">
                    🔄 Transférer
                  </button>
                  <button onClick={() => setArticleEnDetailsAlerte(article)} className="bg-gray-600 text-white px-3 py-2 rounded font-bold text-sm hover:bg-gray-700">
                    👁️ Détails
                  </button>
                  <button onClick={() => setArticleEnHistoriqueAlerte(article)} className="bg-purple-600 text-white px-3 py-2 rounded font-bold text-sm hover:bg-purple-700">
                    📊 Historique
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODALES */}
      {articleEnTransfertAlerte && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full">
            <h2 className="text-2xl font-black text-blue-700 mb-4">🔄 TRANSFERT RAPIDE</h2>
            <div className="space-y-4">
              <div className="bg-blue-50 p-3 rounded border-2 border-blue-300">
                <p className="font-bold text-blue-700">{articleEnTransfertAlerte.code}</p>
                <p className="text-sm text-gray-600">{articleEnTransfertAlerte.description}</p>
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700">Dépôt source *</label>
                <select value={transfertRapideData.depotSource} onChange={(e) => setTransfertRapideData({...transfertRapideData, depotSource: e.target.value})} className="w-full border-2 rounded px-3 py-2 mt-1">
                  {depots.map(d => <option key={d} value={d}>{d} (Stock: {articleEnTransfertAlerte.stockParDepot[d] || 0})</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700">Dépôt destination *</label>
                <select value={transfertRapideData.depotDestination} onChange={(e) => setTransfertRapideData({...transfertRapideData, depotDestination: e.target.value})} className="w-full border-2 rounded px-3 py-2 mt-1">
                  {depots.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700">Quantité *</label>
                <input type="number" min="1" value={transfertRapideData.quantite} onChange={(e) => setTransfertRapideData({...transfertRapideData, quantite: e.target.value})} className="w-full border-2 rounded px-3 py-2 mt-1" />
              </div>
              <div className="flex gap-2">
                <button onClick={effectuerTransfertRapide} className="flex-1 bg-blue-600 text-white px-4 py-2 rounded font-bold hover:bg-blue-700">✓ Transférer</button>
                <button onClick={() => setArticleEnTransfertAlerte(null)} className="flex-1 bg-gray-400 text-white px-4 py-2 rounded font-bold">Annuler</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {articleEnDetailsAlerte && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-2xl font-black">📋 DÉTAILS</h2>
              <button onClick={() => setArticleEnDetailsAlerte(null)} className="text-2xl">✕</button>
            </div>
            <div className="space-y-3">
              <div className="bg-gray-50 p-3 rounded border-2">
                <p className="text-xs text-gray-600 font-bold">CODE</p>
                <p className="font-bold text-lg">{articleEnDetailsAlerte.code}</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 font-bold">DESCRIPTION</p>
                <p className="font-semibold">{articleEnDetailsAlerte.description}</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 font-bold">FOURNISSEUR</p>
                <p className="font-semibold">{articleEnDetailsAlerte.fournisseur}</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 font-bold">PRIX UNITAIRE</p>
                <p className="font-bold text-green-600">{articleEnDetailsAlerte.prixUnitaire}€</p>
              </div>
              <div className="border-t pt-3">
                <p className="text-xs text-gray-600 font-bold mb-2">STOCK PAR DÉPÔT</p>
                <div className="space-y-1">
                  {depots.map(d => (
                    <div key={d} className="flex justify-between p-2 bg-gray-100 rounded">
                      <span className="font-semibold">{d}:</span>
                      <span className="font-bold">{articleEnDetailsAlerte.stockParDepot[d] || 0}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-blue-50 p-3 rounded border-2 border-blue-300">
                <p className="text-xs text-gray-600 font-bold">STOCK TOTAL</p>
                <p className="text-2xl font-black text-blue-600">{getStockTotal(articleEnDetailsAlerte)}</p>
                <p className="text-xs text-blue-700 mt-1">Minimum: {articleEnDetailsAlerte.stockMin}</p>
              </div>
              <button onClick={() => setArticleEnDetailsAlerte(null)} className="w-full bg-gray-600 text-white px-4 py-2 rounded font-bold">Fermer</button>
            </div>
          </div>
        </div>
      )}

      {articleEnHistoriqueAlerte && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-lg w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-2xl font-black">📊 HISTORIQUE</h2>
              <button onClick={() => setArticleEnHistoriqueAlerte(null)} className="text-2xl">✕</button>
            </div>
            <div className="bg-gray-50 p-3 rounded border-2 mb-4">
              <p className="font-bold">{articleEnHistoriqueAlerte.code}</p>
              <p className="text-sm text-gray-600">{articleEnHistoriqueAlerte.description}</p>
            </div>
            <div className="space-y-2">
              {mouvementsStock.filter(m => m.articleId === articleEnHistoriqueAlerte.id).length === 0 ? (
                <p className="text-gray-500 italic">Aucun mouvement</p>
              ) : (
                mouvementsStock.filter(m => m.articleId === articleEnHistoriqueAlerte.id).map(m => (
                  <div key={m.id} className={`p-3 rounded border-l-4 ${m.type === 'entree' ? 'bg-green-50 border-green-500' : m.type === 'sortie' ? 'bg-red-50 border-red-500' : 'bg-blue-50 border-blue-500'}`}>
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-bold">{m.type === 'entree' ? '📥 Entrée' : m.type === 'sortie' ? '📤 Sortie' : '🔄 Transfert'}</p>
                        <p className="text-xs text-gray-600">{m.date} • {m.raison}</p>
                      </div>
                      <p className="font-black text-lg">{m.type === 'transfer' ? '→' : m.type === 'entree' ? '+' : '-'} {m.quantite}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
            <button onClick={() => setArticleEnHistoriqueAlerte(null)} className="w-full bg-gray-600 text-white px-4 py-2 rounded font-bold mt-4">Fermer</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Alertes;