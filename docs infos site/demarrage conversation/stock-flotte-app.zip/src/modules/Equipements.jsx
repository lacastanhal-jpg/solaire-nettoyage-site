// Module ÉQUIPEMENTS - Solaire Nettoyage V3.1
// AMÉLIORATIONS : Recherche intelligente + toutes fonctionnalités préservées
// Gestion complète du parc d'équipements
import React from 'react';

const Equipements = ({
  equipements,
  setEquipements,
  nouvelEquipement,
  setNouvelEquipement,
  afficherFormulaireEquipement,
  setAfficherFormulaireEquipement,
  equipementEnEdition,
  setEquipementEnEdition,
  modeEdition,
  setModeEdition,
  setOngletActif,
  setEquipementSelectionne,
  database,
  ref,
  set
}) => {

  // NOUVEL ÉTAT - RECHERCHE INTELLIGENTE
  const [rechercheEquipements, setRechercheEquipements] = React.useState('');

  // NOUVELLE FONCTION - FILTRAGE INTELLIGENT MULTI-MOTS
  const filtrerEquipements = () => {
    if (!rechercheEquipements.trim()) return equipements;
    const mots = rechercheEquipements.toLowerCase().trim().split(/\s+/);
    return equipements.filter(e => {
      const contenu = [e.immat, e.type, e.marque || '', e.modele || '', e.proprietaire || ''].join(' ').toLowerCase();
      return mots.every(mot => contenu.includes(mot));
    });
  };

  // ✅ FONCTION CRÉER/MODIFIER ÉQUIPEMENT
  const creerOuModifierEquipement = async () => {
    if (!nouvelEquipement.immat || !nouvelEquipement.type) {
      alert('⚠️ Immatriculation et Type sont obligatoires!');
      return;
    }

    const immatExiste = equipements.some(e => 
      e.immat === nouvelEquipement.immat && 
      (!modeEdition || e.id !== equipementEnEdition.id)
    );
    
    if (immatExiste) {
      alert('⚠️ Cette immatriculation existe déjà !');
      return;
    }

    if (modeEdition) {
      // MODE ÉDITION
      const equipementsModifies = equipements.map(e => 
        e.id === equipementEnEdition.id ? {
          id: e.id,
          immat: nouvelEquipement.immat,
          type: nouvelEquipement.type,
          marque: nouvelEquipement.marque || '',
          modele: nouvelEquipement.modele || '',
          annee: parseInt(nouvelEquipement.annee) || 0,
          km: parseInt(nouvelEquipement.km) || 0,
          heures: parseInt(nouvelEquipement.heures) || 0,
          carburant: nouvelEquipement.carburant || '',
          vin: nouvelEquipement.vin || '',
          ptac: parseInt(nouvelEquipement.ptac) || 0,
          poids: parseInt(nouvelEquipement.poids) || 0,
          proprietaire: nouvelEquipement.proprietaire || 'SOLAIRE NETTOYAGE',
          valeurAchat: parseFloat(nouvelEquipement.valeurAchat) || 0,
          valeurActuelle: parseFloat(nouvelEquipement.valeurActuelle) || 0,
          typeFinancement: nouvelEquipement.typeFinancement || '',
          coutMensuel: parseFloat(nouvelEquipement.coutMensuel) || 0,
          dateDebut: nouvelEquipement.dateDebut || new Date().toISOString().split('T')[0],
          dateFin: nouvelEquipement.dateFin || '',
          assurance: parseFloat(nouvelEquipement.assurance) || 0,
          dateContracteTechnique: nouvelEquipement.dateContracteTechnique || '',
          notes: nouvelEquipement.notes || ''
        } : e
      );
      
      // Sauvegarder dans Firebase
      for (const equipement of equipementsModifies) {
        await set(ref(database, 'equipements/' + equipement.id), equipement);
      }
      alert('✅ Équipement modifié avec succès!');
      
    } else {
      // MODE CRÉATION - CORRECTION DU PROBLÈME NaN
      let nouvelId = 1;
      
      // Trouver le plus grand ID existant
      if (equipements && equipements.length > 0) {
        const maxId = Math.max(...equipements.map(e => {
          const id = parseInt(e.id);
          return isNaN(id) ? 0 : id;
        }));
        nouvelId = maxId + 1;
      }
      
      // S'assurer que l'ID est valide
      if (isNaN(nouvelId)) {
        nouvelId = Date.now(); // Utiliser timestamp comme fallback
      }
      
      const nouvelEquip = {
        id: nouvelId,
        immat: nouvelEquipement.immat,
        type: nouvelEquipement.type,
        marque: nouvelEquipement.marque || '',
        modele: nouvelEquipement.modele || '',
        annee: parseInt(nouvelEquipement.annee) || 0,
        km: parseInt(nouvelEquipement.km) || 0,
        heures: parseInt(nouvelEquipement.heures) || 0,
        carburant: nouvelEquipement.carburant || '',
        vin: nouvelEquipement.vin || '',
        ptac: parseInt(nouvelEquipement.ptac) || 0,
        poids: parseInt(nouvelEquipement.poids) || 0,
        proprietaire: nouvelEquipement.proprietaire || 'SOLAIRE NETTOYAGE',
        valeurAchat: parseFloat(nouvelEquipement.valeurAchat) || 0,
        valeurActuelle: parseFloat(nouvelEquipement.valeurActuelle) || 0,
        typeFinancement: nouvelEquipement.typeFinancement || '',
        coutMensuel: parseFloat(nouvelEquipement.coutMensuel) || 0,
        dateDebut: nouvelEquipement.dateDebut || new Date().toISOString().split('T')[0],
        dateFin: nouvelEquipement.dateFin || '',
        assurance: parseFloat(nouvelEquipement.assurance) || 0,
        dateContracteTechnique: nouvelEquipement.dateContracteTechnique || '',
        notes: nouvelEquipement.notes || ''
      };

      // Créer dans Firebase
      try {
        await set(ref(database, 'equipements/' + nouvelId), nouvelEquip);
        alert('✅ Équipement créé avec succès!');
      } catch (error) {
        console.error('Erreur création équipement:', error);
        alert('❌ Erreur lors de la création!');
      }
    }

    // Réinitialiser formulaire
    setNouvelEquipement({
      immat: '',
      type: '',
      marque: '',
      modele: '',
      annee: '',
      km: 0,
      heures: 0,
      carburant: '',
      vin: '',
      ptac: 0,
      poids: 0,
      proprietaire: 'SOLAIRE NETTOYAGE',
      valeurAchat: 0,
      valeurActuelle: 0,
      typeFinancement: '',
      coutMensuel: 0,
      dateDebut: new Date().toISOString().split('T')[0],
      dateFin: '',
      assurance: 0,
      dateContracteTechnique: '',
      notes: ''
    });

    setEquipementEnEdition(null);
    setModeEdition(false);
    setAfficherFormulaireEquipement(false);
  };

  // ✅ FONCTION OUVRIR ÉDITION
  const ouvrirEditionEquipement = (equipement) => {
    setEquipementEnEdition(equipement);
    setModeEdition(true);
    setNouvelEquipement({
      immat: equipement.immat,
      type: equipement.type,
      marque: equipement.marque,
      modele: equipement.modele,
      annee: equipement.annee,
      km: equipement.km,
      heures: equipement.heures,
      carburant: equipement.carburant,
      vin: equipement.vin,
      ptac: equipement.ptac,
      poids: equipement.poids,
      proprietaire: equipement.proprietaire,
      valeurAchat: equipement.valeurAchat,
      valeurActuelle: equipement.valeurActuelle,
      typeFinancement: equipement.typeFinancement,
      coutMensuel: equipement.coutMensuel,
      dateDebut: equipement.dateDebut,
      dateFin: equipement.dateFin,
      assurance: equipement.assurance,
      dateContracteTechnique: equipement.dateContracteTechnique,
      notes: equipement.notes
    });
    setAfficherFormulaireEquipement(true);
  };

  // ✅ FONCTION ANNULER ÉDITION
  const annulerEditionEquipement = () => {
    setEquipementEnEdition(null);
    setModeEdition(false);
    setNouvelEquipement({
      immat: '',
      type: '',
      marque: '',
      modele: '',
      annee: '',
      km: 0,
      heures: 0,
      carburant: '',
      vin: '',
      ptac: 0,
      poids: 0,
      proprietaire: 'SOLAIRE NETTOYAGE',
      valeurAchat: 0,
      valeurActuelle: 0,
      typeFinancement: '',
      coutMensuel: 0,
      dateDebut: new Date().toISOString().split('T')[0],
      dateFin: '',
      assurance: 0,
      dateContracteTechnique: '',
      notes: ''
    });
    setAfficherFormulaireEquipement(false);
  };

  const typesEquipement = [
    'Camion Porteur',
    'Camion semi',
    'Nacelle',
    'Groupe électrogène',
    'Osmoseur',
    'Robot nettoyage',
    'Accessoire',
    'Véhicule léger',
    'Remorque',
    'Outil électroportatif',
    'Système filtration',
    'Tracteur',
    'Micro Tracteur',
    'Autre'
  ];

  // Calculer les équipements filtrés
  const equipementsFiltres = filtrerEquipements();

  return (
    <div className="space-y-6">
      {/* FORMULAIRE CRÉATION/ÉDITION */}
      <div className="bg-white p-4 rounded border">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-black text-xl">
            {modeEdition ? '✏️ MODIFIER ÉQUIPEMENT' : '➕ CRÉER UN NOUVEL ÉQUIPEMENT'}
          </h2>
          <button 
            onClick={() => setAfficherFormulaireEquipement(!afficherFormulaireEquipement)}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-2 rounded font-bold hover:from-blue-700 hover:to-indigo-700 transition"
          >
            {afficherFormulaireEquipement ? '❌ Fermer' : '➕ Nouveau'}
          </button>
        </div>
        
        {afficherFormulaireEquipement && (
          <div className="space-y-4 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border-2 border-blue-300">
            {/* SECTION 1 - IDENTIFICATION */}
            <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-400">
              <h4 className="font-bold text-blue-700 mb-3">🚛 IDENTIFICATION</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-700">Immatriculation *</label>
                  <input 
                    type="text" 
                    placeholder="Ex: AB-123-CD" 
                    value={nouvelEquipement.immat}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, immat: e.target.value})}
                    className="w-full border-2 border-blue-400 rounded px-3 py-2 mt-1 font-bold text-lg"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Type *</label>
                  <select 
                    value={nouvelEquipement.type}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, type: e.target.value})}
                    className="w-full border-2 border-blue-400 rounded px-3 py-2 mt-1"
                  >
                    <option value="">Sélectionner un type</option>
                    {typesEquipement.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* SECTION 2 - DÉTAILS TECHNIQUES */}
            <div className="bg-green-50 p-4 rounded-lg border-2 border-green-400">
              <h4 className="font-bold text-green-700 mb-3">⚙️ DÉTAILS TECHNIQUES</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-700">Marque</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Renault" 
                    value={nouvelEquipement.marque}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, marque: e.target.value})}
                    className="w-full border-2 border-green-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Modèle</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Master" 
                    value={nouvelEquipement.modele}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, modele: e.target.value})}
                    className="w-full border-2 border-green-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Année</label>
                  <input 
                    type="number" 
                    placeholder="2024" 
                    value={nouvelEquipement.annee}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, annee: e.target.value})}
                    className="w-full border-2 border-green-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Kilométrage</label>
                  <input 
                    type="number" 
                    placeholder="0" 
                    value={nouvelEquipement.km}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, km: e.target.value})}
                    className="w-full border-2 border-green-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Heures</label>
                  <input 
                    type="number" 
                    placeholder="0" 
                    value={nouvelEquipement.heures}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, heures: e.target.value})}
                    className="w-full border-2 border-green-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Carburant</label>
                  <select 
                    value={nouvelEquipement.carburant}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, carburant: e.target.value})}
                    className="w-full border-2 border-green-400 rounded px-3 py-2 mt-1"
                  >
                    <option value="">Sélectionner</option>
                    <option value="Diesel">Diesel</option>
                    <option value="Essence">Essence</option>
                    <option value="Électrique">Électrique</option>
                    <option value="Hybride">Hybride</option>
                    <option value="GPL">GPL</option>
                    <option value="N/A">N/A</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">VIN</label>
                  <input 
                    type="text" 
                    placeholder="N° châssis" 
                    value={nouvelEquipement.vin}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, vin: e.target.value})}
                    className="w-full border-2 border-green-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">PTAC (kg)</label>
                  <input 
                    type="number" 
                    placeholder="0" 
                    value={nouvelEquipement.ptac}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, ptac: e.target.value})}
                    className="w-full border-2 border-green-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Poids (kg)</label>
                  <input 
                    type="number" 
                    placeholder="0" 
                    value={nouvelEquipement.poids}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, poids: e.target.value})}
                    className="w-full border-2 border-green-400 rounded px-3 py-2 mt-1"
                  />
                </div>
              </div>
            </div>

            {/* SECTION 3 - VALEURS */}
            <div className="bg-purple-50 p-4 rounded-lg border-2 border-purple-400">
              <h4 className="font-bold text-purple-700 mb-3">💰 VALEURS</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-700">Valeur d'achat (€)</label>
                  <input 
                    type="number" 
                    step="0.01"
                    placeholder="0" 
                    value={nouvelEquipement.valeurAchat}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, valeurAchat: e.target.value})}
                    className="w-full border-2 border-purple-300 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Valeur actuelle (€)</label>
                  <input 
                    type="number" 
                    step="0.01"
                    placeholder="0" 
                    value={nouvelEquipement.valeurActuelle}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, valeurActuelle: e.target.value})}
                    className="w-full border-2 border-purple-300 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Assurance (€/mois)</label>
                  <input 
                    type="number" 
                    step="0.01"
                    placeholder="0" 
                    value={nouvelEquipement.assurance}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, assurance: e.target.value})}
                    className="w-full border-2 border-purple-300 rounded px-3 py-2 mt-1"
                  />
                </div>
              </div>
            </div>

            {/* SECTION 4 - FINANCEMENT */}
            <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-400">
              <h4 className="font-bold text-yellow-700 mb-3">🏦 FINANCEMENT</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-700">Type financement</label>
                  <select 
                    value={nouvelEquipement.typeFinancement}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, typeFinancement: e.target.value})}
                    className="w-full border-2 border-yellow-400 rounded px-3 py-2 mt-1"
                  >
                    <option value="">Sélectionner</option>
                    <option value="Achat">Achat</option>
                    <option value="Location">Location</option>
                    <option value="Crédit">Crédit</option>
                    <option value="Autre">Autre</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Coût mensuel (€)</label>
                  <input 
                    type="number" 
                    step="0.01"
                    placeholder="0" 
                    value={nouvelEquipement.coutMensuel}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, coutMensuel: e.target.value})}
                    className="w-full border-2 border-yellow-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div></div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Date début</label>
                  <input 
                    type="date" 
                    value={nouvelEquipement.dateDebut}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, dateDebut: e.target.value})}
                    className="w-full border-2 border-yellow-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Date fin</label>
                  <input 
                    type="date" 
                    value={nouvelEquipement.dateFin}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, dateFin: e.target.value})}
                    className="w-full border-2 border-yellow-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Date contrôle technique</label>
                  <input 
                    type="date" 
                    value={nouvelEquipement.dateContracteTechnique}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, dateContracteTechnique: e.target.value})}
                    className="w-full border-2 border-yellow-400 rounded px-3 py-2 mt-1"
                  />
                </div>
              </div>
            </div>

            {/* SECTION 5 - INFOS OPÉRATIONNELLES */}
            <div className="bg-orange-50 p-4 rounded-lg border-2 border-orange-400">
              <h4 className="font-bold text-orange-700 mb-3">🏢 INFOS OPÉRATIONNELLES</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-700">Propriétaire</label>
                  <input 
                    type="text" 
                    placeholder="SOLAIRE NETTOYAGE" 
                    value={nouvelEquipement.proprietaire}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, proprietaire: e.target.value})}
                    className="w-full border-2 border-orange-400 rounded px-3 py-2 mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-700">Notes</label>
                  <input 
                    type="text" 
                    placeholder="Notes..." 
                    value={nouvelEquipement.notes}
                    onChange={(e) => setNouvelEquipement({...nouvelEquipement, notes: e.target.value})}
                    className="w-full border-2 border-orange-400 rounded px-3 py-2 mt-1"
                  />
                </div>
              </div>
            </div>

            {/* BOUTONS CRÉER/SAUVEGARDER */}
            <div className="flex gap-2">
              <button 
                onClick={creerOuModifierEquipement}
                className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-4 rounded-lg font-black text-lg hover:from-blue-700 hover:to-indigo-700 transition"
              >
                {modeEdition ? '💾 SAUVEGARDER MODIFICATIONS' : '✅ CRÉER ÉQUIPEMENT'}
              </button>
              {modeEdition && (
                <button 
                  onClick={annulerEditionEquipement}
                  className="flex-1 bg-gray-500 text-white px-6 py-4 rounded-lg font-black text-lg hover:bg-gray-600 transition"
                >
                  ❌ ANNULER
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* LISTE DES ÉQUIPEMENTS AVEC RECHERCHE */}
      <div className="bg-white p-4 rounded border">
        <h2 className="font-black text-xl mb-4">🚛 Équipements ({equipements.length})</h2>
        
        {/* BARRE DE RECHERCHE INTELLIGENTE */}
        <div className="mb-4">
          <input 
            type="text" 
            placeholder="🔍 Rechercher équipement (immatriculation, type, marque, modèle, propriétaire)..." 
            value={rechercheEquipements}
            onChange={(e) => setRechercheEquipements(e.target.value)}
            className="w-full border-2 border-blue-400 rounded-lg px-4 py-3 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
          />
          {rechercheEquipements && (
            <div className="text-sm text-blue-700 mt-2 font-medium flex items-center gap-2">
              🎯 {equipementsFiltres.length} équipement(s) trouvé(s) sur {equipements.length}
              {equipementsFiltres.length === 0 && (
                <span className="text-red-600">• Aucun résultat</span>
              )}
            </div>
          )}
        </div>

        {equipementsFiltres.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {equipementsFiltres.map(eq => (
              <div 
                key={eq.id} 
                className="p-4 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg border-2 border-gray-300 hover:shadow-lg transition cursor-pointer"
                onClick={() => {setOngletActif('fiche'); setEquipementSelectionne(eq.id);}}
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="text-xl font-black text-orange-600">{eq.immat}</div>
                    <div className="text-sm text-gray-700"><strong>{eq.type}</strong></div>
                  </div>
                  <div className="text-right text-sm">
                    <div className="text-gray-600">{eq.marque}</div>
                    <div className="text-gray-600">{eq.modele}</div>
                    <div className="text-gray-500">({eq.annee})</div>
                  </div>
                </div>
                <div className="border-t pt-2 mt-2 grid grid-cols-2 gap-2 text-xs">
                  <div className="text-gray-600">💰 <strong>{eq.valeurActuelle}€</strong></div>
                  <div className="text-gray-600">⛽ {eq.carburant || 'N/A'}</div>
                  <div className="text-gray-600">🏢 {eq.proprietaire}</div>
                  <div className="text-gray-600">📅 {eq.dateDebut}</div>
                </div>
                <div className="flex gap-2 mt-3">
                  <button 
                    onClick={(e) => {e.stopPropagation(); setOngletActif('fiche'); setEquipementSelectionne(eq.id);}}
                    className="flex-1 bg-orange-500 text-white px-3 py-2 rounded font-bold text-sm hover:bg-orange-600"
                  >
                    👁️ Voir fiche
                  </button>
                  <button 
                    onClick={(e) => {e.stopPropagation(); ouvrirEditionEquipement(eq);}}
                    className="flex-1 bg-blue-600 text-white px-3 py-2 rounded font-bold text-sm hover:bg-blue-700"
                  >
                    ✏️ Éditer
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : rechercheEquipements ? (
          <div className="text-center py-12 text-gray-500">
            <div className="text-5xl mb-3">🔍</div>
            <div className="font-bold text-lg">Aucun équipement trouvé</div>
            <div className="text-sm mt-1">Essayez avec un autre terme de recherche</div>
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            <div className="text-5xl mb-3">🚛</div>
            <div className="font-bold text-lg">Aucun équipement</div>
            <div className="text-sm mt-1">Créez votre premier équipement</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Equipements;