// Module STATISTIQUES COMPLÈTES - Solaire Nettoyage V3.12
// MEGA MODULE avec TIMELINE interactive + stats détaillées
import React from 'react';

const Statistiques = ({ 
  equipements,
  interventions,
  defauts,
  accessoiresEquipement,
  equipementSelectionne,
  setEquipementSelectionne,
  factures,
  articles,
  mouvementsStock
}) => {
  // SÉCURITÉ
  if (!factures) factures = [];
  if (!articles) articles = [];
  if (!mouvementsStock) mouvementsStock = [];
  if (!defauts) defauts = [];

  // ÉTATS TIMELINE
  const [filtreTypeEvenement, setFiltreTypeEvenement] = React.useState({ interventions: true, defauts: true, factures: true });
  const [dateSelectionnee, setDateSelectionnee] = React.useState(null);
  const [evenementEnModal, setEvenementEnModal] = React.useState(null);
  const [zoomTimeline, setZoomTimeline] = React.useState('mois'); // 'semaine', 'mois', 'annee'

  // CALCULS GLOBAUX FLOTTE
  const valeurAchatTotale = equipements.reduce((sum, eq) => sum + (eq.valeurAchat || 0), 0);
  const valeurActuelleTotale = equipements.reduce((sum, eq) => sum + (eq.valeurActuelle || 0), 0);
  const valeurAccessoiresTotale = Object.keys(accessoiresEquipement).reduce((sum, equipId) => {
    const accessoires = accessoiresEquipement[equipId] || [];
    return sum + accessoires.reduce((s, a) => s + (a.valeur || 0), 0);
  }, 0);
  const valeurTotaleFlotte = valeurActuelleTotale + valeurAccessoiresTotale;
  const depreciationTotale = valeurAchatTotale - valeurActuelleTotale;
  const tauxDepreciation = valeurAchatTotale > 0 ? ((depreciationTotale / valeurAchatTotale) * 100) : 0;

  // ÉTATS FILTRES
  const [filtreEquipement, setFiltreEquipement] = React.useState('');
  const [filtrePeriodeDebut, setFiltrePeriodeDebut] = React.useState('');
  const [filtrePeriodeFin, setFiltrePeriodeFin] = React.useState('');

  // FILTRAGE
  const interventionsFiltrees = interventions.filter(interv => {
    if (filtreEquipement && interv.equipementId !== parseInt(filtreEquipement)) return false;
    if (filtrePeriodeDebut && interv.date < filtrePeriodeDebut) return false;
    if (filtrePeriodeFin && interv.date > filtrePeriodeFin) return false;
    return true;
  });

  const defautsFiltres = defauts.filter(def => {
    if (filtreEquipement && def.equipementId !== parseInt(filtreEquipement)) return false;
    return true;
  });

  // STATS ÉQUIPEMENT
  const equipSelectionne = equipements.find(e => e.id === equipementSelectionne);
  const eqInterventions = interventions.filter(i => i.equipementId === equipSelectionne?.id);
  const eqDefauts = defauts.filter(d => d.equipementId === equipSelectionne?.id);
  const eqAccessoires = accessoiresEquipement[equipementSelectionne] || [];
  
  const eqFactures = equipSelectionne && factures ? factures.flatMap(facture => {
    if (!facture || !facture.lignes || !Array.isArray(facture.lignes)) return [];
    return facture.lignes
      .filter(ligne => String(ligne.equipementId) === String(equipSelectionne.id))
      .map(ligne => ({ ...facture, ligneConcernee: ligne }));
  }) : [];
  const eqTotalFactures = eqFactures.reduce((sum, f) => sum + (f.ligneConcernee?.total || 0), 0);

  // FONCTION - GÉNÉRER TIMELINE ÉVÉNEMENTS
  const genererEvenements = () => {
    if (!equipSelectionne) return [];
    const evenements = [];

    // INTERVENTIONS
    if (filtreTypeEvenement.interventions) {
      eqInterventions.forEach(interv => {
        evenements.push({
          type: 'intervention',
          date: interv.date,
          icone: '🔧',
          couleur: interv.statut === 'en_cours' ? 'yellow' : 'green',
          titre: interv.type,
          sousTitre: `${interv.km > 0 ? interv.km + ' km' : ''} ${interv.heures > 0 ? interv.heures + 'h' : ''}`.trim(),
          montant: interv.coutTotal,
          data: interv
        });
      });
    }

    // DÉFAUTS
    if (filtreTypeEvenement.defauts) {
      eqDefauts.forEach(def => {
        evenements.push({
          type: 'defaut',
          date: def.dateConstatation,
          icone: '⚠️',
          couleur: def.severite === 'critique' ? 'red' : def.severite === 'moyen' ? 'yellow' : 'green',
          titre: def.type,
          sousTitre: def.severite === 'critique' ? '🔴 CRITIQUE' : def.severite === 'moyen' ? '🟡 MOYEN' : '🟢 MINEUR',
          montant: null,
          data: def
        });
      });
    }

    // FACTURES
    if (filtreTypeEvenement.factures) {
      eqFactures.forEach(fact => {
        evenements.push({
          type: 'facture',
          date: fact.date,
          icone: '💰',
          couleur: 'blue',
          titre: fact.fournisseur || 'Facture',
          sousTitre: fact.numero || '',
          montant: fact.ligneConcernee?.total,
          data: fact
        });
      });
    }

    return evenements.sort((a, b) => new Date(b.date) - new Date(a.date));
  };

  const evenements = genererEvenements();

  // FONCTION - ÉVÉNEMENTS PAR DATE
  const evenementsParDate = {};
  evenements.forEach(ev => {
    if (!evenementsParDate[ev.date]) {
      evenementsParDate[ev.date] = [];
    }
    evenementsParDate[ev.date].push(ev);
  });

  // FONCTION - ARTICLES UTILISÉS
  const getArticlesUtilises = () => {
    if (!equipSelectionne) return [];
    const articlesUtilises = {};
    eqInterventions.forEach(interv => {
      if (interv.articles) {
        interv.articles.forEach(art => {
          if (!articlesUtilises[art.articleId]) {
            const article = articles.find(a => a.id === art.articleId);
            articlesUtilises[art.articleId] = {
              article: article,
              quantiteTotal: 0,
              coutTotal: 0
            };
          }
          articlesUtilises[art.articleId].quantiteTotal += art.quantite;
          articlesUtilises[art.articleId].coutTotal += (art.prixUnitaire * art.quantite);
        });
      }
    });
    return Object.values(articlesUtilises).sort((a, b) => b.coutTotal - a.coutTotal);
  };

  // EXPORTS
  const exporterPDF = () => {
    const coutTotal = eqInterventions.filter(i => i.statut === 'effectue').reduce((sum, i) => sum + (i.coutTotal || 0), 0);
    let html = `<html><head><meta charset="UTF-8"><title>Stats ${equipSelectionne?.immat}</title></head><body><h1>📊 STATISTIQUES ${equipSelectionne?.immat}</h1><p>Total: ${coutTotal.toFixed(2)}€</p></body></html>`;
    const newWindow = window.open('', '_blank');
    newWindow.document.write(html);
    newWindow.document.close();
    newWindow.print();
  };

  const exporterCSV = () => {
    let csv = `STATS ${equipSelectionne?.immat}\nDate,Type,Coût\n`;
    eqInterventions.forEach(i => csv += `${i.date},${i.type},${i.coutTotal}\n`);
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv));
    element.setAttribute('download', `Stats_${equipSelectionne?.immat}.csv`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    alert('✅ CSV téléchargé!');
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-black text-purple-700">📈 STATISTIQUES ÉQUIPEMENTS</h2>

      {/* STATS GLOBALES FLOTTE */}
      <div className="bg-gradient-to-r from-amber-100 via-orange-100 to-red-100 border-4 border-orange-500 p-6 rounded-xl shadow-xl">
        <h3 className="text-2xl font-black text-orange-700 mb-4">🚛 VALEUR TOTALE DE LA FLOTTE</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg border-2 border-blue-300 shadow-md">
            <p className="text-xs text-gray-600 font-bold">ÉQUIPEMENTS</p>
            <p className="text-4xl font-black text-blue-600">{equipements.length}</p>
          </div>
          <div className="bg-white p-4 rounded-lg border-2 border-purple-300 shadow-md">
            <p className="text-xs text-gray-600 font-bold">VALEUR D'ACHAT</p>
            <p className="text-3xl font-black text-purple-600">{valeurAchatTotale.toLocaleString('fr-FR')}€</p>
          </div>
          <div className="bg-white p-4 rounded-lg border-2 border-green-300 shadow-md">
            <p className="text-xs text-gray-600 font-bold">VALEUR ACTUELLE</p>
            <p className="text-3xl font-black text-green-600">{valeurActuelleTotale.toLocaleString('fr-FR')}€</p>
          </div>
          <div className="bg-white p-4 rounded-lg border-2 border-indigo-300 shadow-md">
            <p className="text-xs text-gray-600 font-bold">ACCESSOIRES</p>
            <p className="text-3xl font-black text-indigo-600">{valeurAccessoiresTotale.toLocaleString('fr-FR')}€</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gradient-to-br from-orange-500 to-red-600 p-6 rounded-lg shadow-lg">
            <p className="text-sm text-orange-100 font-bold mb-2">💰 VALEUR TOTALE FLOTTE</p>
            <p className="text-5xl font-black text-white mb-2">{valeurTotaleFlotte.toLocaleString('fr-FR')}€</p>
          </div>
          <div className="bg-gradient-to-br from-gray-600 to-gray-800 p-6 rounded-lg shadow-lg">
            <p className="text-sm text-gray-300 font-bold mb-2">📉 DÉPRÉCIATION TOTALE</p>
            <p className="text-4xl font-black text-white mb-2">-{depreciationTotale.toLocaleString('fr-FR')}€</p>
            <p className="text-gray-300 text-sm">{tauxDepreciation.toFixed(1)}%</p>
          </div>
        </div>
      </div>

      {/* FILTRES GLOBAUX */}
      <div className="bg-purple-50 border-2 border-purple-300 p-4 rounded-lg">
        <p className="font-bold text-purple-700 mb-3">🔍 FILTRES</p>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <select value={filtreEquipement} onChange={(e) => setFiltreEquipement(e.target.value)} className="border-2 border-purple-300 rounded px-3 py-2 text-sm font-medium">
            <option value="">Tous les équipements</option>
            {equipements.map(eq => <option key={eq.id} value={eq.id}>{eq.immat}</option>)}
          </select>
          <input type="date" value={filtrePeriodeDebut} onChange={(e) => setFiltrePeriodeDebut(e.target.value)} className="border-2 border-purple-300 rounded px-3 py-2 text-sm font-medium" />
          <input type="date" value={filtrePeriodeFin} onChange={(e) => setFiltrePeriodeFin(e.target.value)} className="border-2 border-purple-300 rounded px-3 py-2 text-sm font-medium" />
          <button onClick={() => { setFiltreEquipement(''); setFiltrePeriodeDebut(''); setFiltrePeriodeFin(''); }} className="bg-gray-500 text-white px-4 py-2 rounded font-bold text-sm hover:bg-gray-600">✕ Reset</button>
        </div>
        {(filtreEquipement || filtrePeriodeDebut || filtrePeriodeFin) && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
            <div className="bg-blue-100 p-4 rounded-lg border-2 border-blue-400">
              <p className="text-xs font-bold text-blue-700">INTERVENTIONS</p>
              <p className="text-3xl font-black text-blue-600">{interventionsFiltrees.length}</p>
            </div>
            <div className="bg-green-100 p-4 rounded-lg border-2 border-green-400">
              <p className="text-xs font-bold text-green-700">COÛT TOTAL</p>
              <p className="text-3xl font-black text-green-600">{interventionsFiltrees.filter(i => i.statut === 'effectue').reduce((sum, i) => sum + (i.coutTotal || 0), 0).toLocaleString('fr-FR')}€</p>
            </div>
            <div className="bg-red-100 p-4 rounded-lg border-2 border-red-400">
              <p className="text-xs font-bold text-red-700">DÉFAUTS</p>
              <p className="text-3xl font-black text-red-600">{defautsFiltres.length}</p>
            </div>
            <div className="bg-yellow-100 p-4 rounded-lg border-2 border-yellow-400">
              <p className="text-xs font-bold text-yellow-700">DÉFAUTS OUVERTS</p>
              <p className="text-3xl font-black text-yellow-600">{defautsFiltres.filter(d => !d.resolu).length}</p>
            </div>
          </div>
        )}
      </div>

      {/* SÉLECTION ÉQUIPEMENT */}
      <div className="bg-white p-4 rounded border-2 border-purple-300">
        <label className="block text-sm font-bold text-gray-700 mb-2">Sélectionner équipement pour détails</label>
        <select value={equipementSelectionne || ''} onChange={(e) => setEquipementSelectionne(parseInt(e.target.value))} className="w-full border-2 border-purple-400 rounded px-3 py-2 font-bold text-lg">
          <option value="">-- Choisir un équipement --</option>
          {equipements.map(eq => <option key={eq.id} value={eq.id}>{eq.immat} - {eq.marque} {eq.modele}</option>)}
        </select>
      </div>

      {/* SI ÉQUIPEMENT SÉLECTIONNÉ */}
      {equipSelectionne && (
        <div className="space-y-6">
          
          {/* ========== TIMELINE INTERACTIVE ========== */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-4 border-blue-500 p-6 rounded-xl shadow-xl">
            <h3 className="text-2xl font-black text-blue-700 mb-4">📅 CHRONOLOGIE - {equipSelectionne.immat}</h3>
            
            {/* FILTRES TIMELINE */}
            <div className="flex gap-4 mb-4">
              <button onClick={() => setFiltreTypeEvenement({...filtreTypeEvenement, interventions: !filtreTypeEvenement.interventions})} className={`px-4 py-2 rounded font-bold ${filtreTypeEvenement.interventions ? 'bg-green-600 text-white' : 'bg-gray-300'}`}>🔧 Interventions</button>
              <button onClick={() => setFiltreTypeEvenement({...filtreTypeEvenement, defauts: !filtreTypeEvenement.defauts})} className={`px-4 py-2 rounded font-bold ${filtreTypeEvenement.defauts ? 'bg-red-600 text-white' : 'bg-gray-300'}`}>⚠️ Défauts</button>
              <button onClick={() => setFiltreTypeEvenement({...filtreTypeEvenement, factures: !filtreTypeEvenement.factures})} className={`px-4 py-2 rounded font-bold ${filtreTypeEvenement.factures ? 'bg-blue-600 text-white' : 'bg-gray-300'}`}>💰 Factures</button>
            </div>

            {/* TIMELINE HORIZONTALE */}
            <div className="bg-white p-4 rounded-lg border-2 border-blue-300 mb-4 overflow-x-auto">
              <div className="min-w-max flex gap-8">
                {Object.keys(evenementsParDate).sort().reverse().slice(0, 12).map(date => {
                  const evs = evenementsParDate[date];
                  return (
                    <div key={date} className="text-center cursor-pointer hover:bg-blue-50 p-2 rounded" onClick={() => setDateSelectionnee(date)}>
                      <div className="text-xs font-bold text-gray-600">{new Date(date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</div>
                      <div className="flex gap-1 justify-center my-2">
                        {evs.slice(0, 3).map((ev, idx) => (
                          <span key={idx} className="text-2xl">{ev.icone}</span>
                        ))}
                        {evs.length > 3 && <span className="text-xs font-bold">+{evs.length - 3}</span>}
                      </div>
                      <div className={`h-1 rounded ${dateSelectionnee === date ? 'bg-blue-600' : 'bg-gray-300'}`}></div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ÉVÉNEMENTS DU JOUR SÉLECTIONNÉ */}
            {dateSelectionnee && evenementsParDate[dateSelectionnee] && (
              <div className="bg-white p-4 rounded-lg border-2 border-blue-300">
                <h4 className="font-bold text-lg mb-3">Événements du {new Date(dateSelectionnee).toLocaleDateString('fr-FR')}</h4>
                <div className="space-y-2">
                  {evenementsParDate[dateSelectionnee].map((ev, idx) => (
                    <div key={idx} onClick={() => setEvenementEnModal(ev)} className={`p-3 rounded border-2 cursor-pointer hover:shadow-lg ${ev.couleur === 'green' ? 'bg-green-50 border-green-400' : ev.couleur === 'yellow' ? 'bg-yellow-50 border-yellow-400' : ev.couleur === 'red' ? 'bg-red-50 border-red-400' : 'bg-blue-50 border-blue-400'}`}>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{ev.icone}</span>
                          <div>
                            <p className="font-bold">{ev.titre}</p>
                            <p className="text-xs text-gray-600">{ev.sousTitre}</p>
                          </div>
                        </div>
                        {ev.montant && <p className="font-bold text-green-600">{ev.montant.toFixed(2)}€</p>}
                        <button className="bg-blue-600 text-white px-3 py-1 rounded text-xs font-bold">📋 Détails</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* LISTE TOUS ÉVÉNEMENTS */}
            <div className="mt-4">
              <h4 className="font-bold mb-2">Tous les événements ({evenements.length})</h4>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {evenements.slice(0, 20).map((ev, idx) => (
                  <div key={idx} onClick={() => setEvenementEnModal(ev)} className="p-2 bg-white rounded border cursor-pointer hover:shadow flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <span>{ev.icone}</span>
                      <div>
                        <p className="font-semibold text-sm">{ev.titre}</p>
                        <p className="text-xs text-gray-600">{ev.date}</p>
                      </div>
                    </div>
                    {ev.montant && <p className="text-sm font-bold">{ev.montant.toFixed(2)}€</p>}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* MODAL DÉTAILS ÉVÉNEMENT */}
          {evenementEnModal && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4" onClick={() => setEvenementEnModal(null)}>
              <div className="bg-white rounded-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <span className="text-4xl">{evenementEnModal.icone}</span>
                    <div>
                      <h3 className="text-2xl font-black">{evenementEnModal.titre}</h3>
                      <p className="text-gray-600">{evenementEnModal.date}</p>
                    </div>
                  </div>
                  <button onClick={() => setEvenementEnModal(null)} className="text-2xl hover:text-red-600">✕</button>
                </div>

                {evenementEnModal.type === 'intervention' && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      {evenementEnModal.data.km > 0 && <div><p className="text-xs font-bold">KILOMÉTRAGE</p><p>{evenementEnModal.data.km} km</p></div>}
                      {evenementEnModal.data.heures > 0 && <div><p className="text-xs font-bold">HEURES</p><p>{evenementEnModal.data.heures}h</p></div>}
                    </div>
                    {evenementEnModal.data.description && <div className="bg-red-50 p-3 rounded border-l-4 border-red-500"><p className="text-sm"><strong>Problème:</strong> {evenementEnModal.data.description}</p></div>}
                    {evenementEnModal.data.travauxEffectues && <div className="bg-green-50 p-3 rounded border-l-4 border-green-500"><p className="text-sm"><strong>Travaux:</strong> {evenementEnModal.data.travauxEffectues}</p></div>}
                    {evenementEnModal.data.articles && evenementEnModal.data.articles.length > 0 && (
                      <div>
                        <p className="font-bold mb-2">Articles utilisés:</p>
                        {evenementEnModal.data.articles.map((art, i) => {
                          const article = articles.find(a => a.id === art.articleId);
                          return <div key={i} className="text-sm bg-gray-100 p-2 rounded mb-1"><strong>{article?.code}</strong> - {article?.description} <span className="text-blue-600 font-bold ml-2">{art.prixUnitaire?.toFixed(2)}€ × {art.quantite} = {(art.prixUnitaire * art.quantite).toFixed(2)}€</span></div>;
                        })}
                      </div>
                    )}
                    <div className="bg-blue-50 p-4 rounded"><p className="font-bold text-xl">TOTAL: {evenementEnModal.montant?.toFixed(2)}€</p></div>
                  </div>
                )}

                {evenementEnModal.type === 'defaut' && (
                  <div className="space-y-3">
                    <div className={`p-3 rounded ${evenementEnModal.couleur === 'red' ? 'bg-red-50' : evenementEnModal.couleur === 'yellow' ? 'bg-yellow-50' : 'bg-green-50'}`}><p className="font-bold">{evenementEnModal.sousTitre}</p></div>
                    <div><p className="text-sm font-bold">Description:</p><p>{evenementEnModal.data.description}</p></div>
                    {evenementEnModal.data.operateur && <div><p className="text-sm font-bold">Opérateur:</p><p>{evenementEnModal.data.operateur}</p></div>}
                    {evenementEnModal.data.localisation && <div><p className="text-sm font-bold">Localisation:</p><p>{evenementEnModal.data.localisation}</p></div>}
                  </div>
                )}

                {evenementEnModal.type === 'facture' && (
                  <div className="space-y-3">
                    <div><p className="text-sm font-bold">Fournisseur:</p><p>{evenementEnModal.data.fournisseur}</p></div>
                    <div><p className="text-sm font-bold">Numéro:</p><p>{evenementEnModal.data.numero}</p></div>
                    <div className="bg-blue-50 p-4 rounded"><p className="font-bold text-xl">MONTANT: {evenementEnModal.montant?.toFixed(2)}€</p></div>
                  </div>
                )}

                <button onClick={() => setEvenementEnModal(null)} className="w-full mt-4 bg-gray-600 text-white px-4 py-2 rounded font-bold hover:bg-gray-700">Fermer</button>
              </div>
            </div>
          )}

          {/* RESTE DU MODULE (Résumé, Export, Accessoires, etc.) - SUITE AU PROCHAIN MESSAGE */}
          {/* RÉSUMÉ ÉQUIPEMENT */}
          <div className="bg-gradient-to-r from-purple-100 to-indigo-100 border-4 border-purple-500 p-6 rounded-xl">
            <h3 className="text-2xl font-black text-purple-700 mb-4">📊 RÉSUMÉ - {equipSelectionne.immat}</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-white p-4 rounded-lg border-2 border-purple-300">
                <p className="text-xs text-gray-600 font-bold">INTERVENTIONS</p>
                <p className="text-3xl font-black text-purple-600">{eqInterventions.length}</p>
                <p className="text-sm text-gray-700">{eqInterventions.filter(i => i.statut === 'effectue').length} effectuées</p>
              </div>
              <div className="bg-white p-4 rounded-lg border-2 border-red-300">
                <p className="text-xs text-gray-600 font-bold">DÉFAUTS</p>
                <p className="text-3xl font-black text-red-600">{eqDefauts.length}</p>
                <p className="text-sm text-gray-700">{eqDefauts.filter(d => d.resolu).length} résolus</p>
              </div>
              <div className="bg-white p-4 rounded-lg border-2 border-green-300">
                <p className="text-xs text-gray-600 font-bold">ACCESSOIRES</p>
                <p className="text-3xl font-black text-green-600">{eqAccessoires.length}</p>
                <p className="text-sm text-gray-700">{eqAccessoires.reduce((sum, a) => sum + a.valeur, 0).toFixed(0)}€</p>
              </div>
              <div className="bg-white p-4 rounded-lg border-2 border-blue-300">
                <p className="text-xs text-gray-600 font-bold">COÛT INTERVENTIONS</p>
                <p className="text-3xl font-black text-blue-600">{eqInterventions.filter(i => i.statut === 'effectue').reduce((sum, i) => sum + (i.coutTotal || 0), 0).toFixed(0)}€</p>
              </div>
              <div className="bg-white p-4 rounded-lg border-2 border-orange-300">
                <p className="text-xs text-gray-600 font-bold">FACTURES & FRAIS</p>
                <p className="text-3xl font-black text-orange-600">{eqFactures.length}</p>
                <p className="text-sm text-gray-700">{eqTotalFactures.toFixed(2)}€</p>
              </div>
            </div>
          </div>

          {/* EXPORT */}
          <div className="flex gap-2">
            <button onClick={() => exporterPDF()} className="flex-1 bg-red-600 text-white px-4 py-3 rounded-lg font-black hover:bg-red-700">📄 Exporter PDF</button>
            <button onClick={() => exporterCSV()} className="flex-1 bg-green-600 text-white px-4 py-3 rounded-lg font-black hover:bg-green-700">📊 Exporter CSV</button>
          </div>

          {/* ACCESSOIRES */}
          {eqAccessoires.length > 0 && (
            <div className="bg-white p-4 rounded-lg shadow border-2 border-green-300">
              <h3 className="font-bold text-lg mb-3">🔧 ACCESSOIRES ({eqAccessoires.length})</h3>
              <div className="grid grid-cols-2 gap-3">
                {eqAccessoires.map((acc, idx) => (
                  <div key={idx} className={`p-3 rounded border-2 ${acc.actif ? 'bg-green-50 border-green-400' : 'bg-red-50 border-red-400'}`}>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">{acc.nom}</span>
                      <span className={`px-2 py-1 rounded text-xs font-bold ${acc.actif ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}>{acc.actif ? '✅ Actif' : '❌ Inactif'}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* INTERVENTIONS */}
          <div className="bg-white p-4 rounded-lg shadow border-2 border-blue-300">
            <h3 className="font-bold text-lg mb-3">🔧 INTERVENTIONS ({eqInterventions.length})</h3>
            {eqInterventions.length === 0 ? <p className="text-gray-500 italic">Aucune intervention</p> : (
              <div className="space-y-3">
                {eqInterventions.sort((a, b) => new Date(b.date) - new Date(a.date)).map(interv => (
                  <div key={interv.id} className={`p-4 rounded border-2 ${interv.statut === 'en_cours' ? 'bg-yellow-50 border-yellow-400' : 'bg-green-50 border-green-400'}`}>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-bold text-lg">{interv.type}</h4>
                          <span className={`px-2 py-1 rounded text-xs font-bold ${interv.statut === 'en_cours' ? 'bg-yellow-600 text-white' : 'bg-green-600 text-white'}`}>{interv.statut === 'en_cours' ? '⏳ En cours' : '✅ Effectuée'}</span>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">📅 {interv.date}{interv.km > 0 && ` • 🛣️ ${interv.km} km`}{interv.heures > 0 && ` • ⏱️ ${interv.heures}h`}</p>
                        {interv.description && <p className="text-sm bg-red-50 border-l-4 border-red-500 pl-2 py-1 mb-2">📋 <strong>Problème:</strong> {interv.description}</p>}
                        {interv.travauxEffectues && <p className="text-sm bg-green-50 border-l-4 border-green-500 pl-2 py-1 mb-2">✅ <strong>Travaux:</strong> {interv.travauxEffectues}</p>}
                        {interv.articles && interv.articles.length > 0 && (
                          <div className="mt-2">
                            <p className="text-xs font-bold text-gray-600 mb-1">Articles:</p>
                            <div className="space-y-1">
                              {interv.articles.map((art, idx) => {
                                const article = articles.find(a => a.id === art.articleId);
                                return <div key={idx} className="text-xs bg-gray-100 px-2 py-1 rounded"><strong>{article?.code || 'N/A'}</strong> - {article?.description || '?'} <span className="ml-2 text-blue-600 font-bold">{art.prixUnitaire?.toFixed(2)}€ × {art.quantite} = {(art.prixUnitaire * art.quantite).toFixed(2)}€</span></div>;
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="text-right ml-4">
                        <p className="text-2xl font-black text-green-600">{interv.coutTotal?.toFixed(2) || '0.00'}€</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* DÉFAUTS */}
          <div className="bg-white p-4 rounded-lg shadow border-2 border-red-300">
            <h3 className="font-bold text-lg mb-3">⚠️ DÉFAUTS ({eqDefauts.length})</h3>
            {eqDefauts.length === 0 ? <p className="text-gray-500 italic">Aucun défaut</p> : (
              <div className="space-y-3">
                {eqDefauts.filter(d => !d.resolu).length > 0 && (
                  <div>
                    <h4 className="font-bold mb-2">🔴 À TRAITER ({eqDefauts.filter(d => !d.resolu).length})</h4>
                    {eqDefauts.filter(d => !d.resolu).map(def => (
                      <div key={def.id} className={`p-3 rounded border-2 mb-2 ${def.severite === 'critique' ? 'bg-red-50 border-red-500' : def.severite === 'moyen' ? 'bg-yellow-50 border-yellow-500' : 'bg-green-50 border-green-500'}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold">{def.type}</span>
                          <span className={`px-2 py-1 rounded text-xs font-bold ${def.severite === 'critique' ? 'bg-red-600 text-white' : def.severite === 'moyen' ? 'bg-yellow-600 text-white' : 'bg-green-600 text-white'}`}>{def.severite === 'critique' ? '🔴 CRITIQUE' : def.severite === 'moyen' ? '🟡 MOYEN' : '🟢 MINEUR'}</span>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">📅 {def.dateConstatation} • 👤 {def.operateur}</p>
                        <p className="text-sm">{def.description}</p>
                        {def.localisation && <p className="text-xs text-gray-600 mt-1">📍 {def.localisation}</p>}
                      </div>
                    ))}
                  </div>
                )}
                {eqDefauts.filter(d => d.resolu).length > 0 && (
                  <div>
                    <h4 className="font-bold mb-2">✅ RÉSOLUS ({eqDefauts.filter(d => d.resolu).length})</h4>
                    {eqDefauts.filter(d => d.resolu).slice(0, 5).map(def => (
                      <div key={def.id} className="p-3 rounded border-2 bg-gray-50 border-gray-300 mb-2">
                        <div className="flex justify-between"><div><span className="font-bold">{def.type}</span><p className="text-sm text-gray-600">📅 {def.dateConstatation}</p></div><span className="bg-green-600 text-white px-2 py-1 rounded text-xs font-bold">✅ Résolu</span></div>
                      </div>
                    ))}
                    {eqDefauts.filter(d => d.resolu).length > 5 && <p className="text-sm text-gray-500 italic">... et {eqDefauts.filter(d => d.resolu).length - 5} autres</p>}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* TOP 10 ARTICLES */}
          {getArticlesUtilises().length > 0 && (
            <div className="bg-white p-4 rounded-lg shadow border-2 border-purple-300">
              <h3 className="font-bold text-lg mb-3">🔧 TOP 10 ARTICLES</h3>
              <div className="space-y-2">
                {getArticlesUtilises().slice(0, 10).map((art, idx) => (
                  <div key={idx} className="flex justify-between items-center p-3 bg-gray-50 rounded border">
                    <div className="flex-1">
                      <p className="font-bold">{art.article?.code || 'N/A'}</p>
                      <p className="text-sm text-gray-600">{art.article?.description || '?'}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg">×{art.quantiteTotal}</p>
                      <p className="text-sm text-green-600 font-semibold">{art.coutTotal.toFixed(2)}€</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Statistiques;