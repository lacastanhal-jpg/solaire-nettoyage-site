# 🚨 MÉMO DÉVELOPPEMENT SOLAIRE V3 - ERREURS À NE JAMAIS REFAIRE

**Date:** 5 décembre 2025  
**Projet:** Solaire Nettoyage - Gestion Flotte V3.5  
**Session:** Ajout Module Factures

---

## ❌ ERREURS GRAVES À NE JAMAIS REFAIRE

### 1. NE JAMAIS MODIFIER LES ICÔNES EXISTANTES

**ERREUR FAITE :** J'ai modifié/corrompu les icônes en copiant/modifiant les fichiers sans respecter l'encodage UTF-8 original.

**RÈGLE ABSOLUE :**
- ✅ **TOUJOURS partir du fichier ORIGINAL uploadé par Jerome**
- ✅ **UNIQUEMENT ajouter** ce qui est nécessaire
- ✅ **NE JAMAIS toucher** aux icônes existantes (📦, 🎨, 💰, 🔧, 📊, etc.)
- ✅ Utiliser Python avec `encoding='utf-8'` pour modifier les fichiers

**WORKFLOW CORRECT :**
```python
# Lire le fichier ORIGINAL uploadé
with open('/mnt/user-data/uploads/FichierOriginal.jsx', 'r', encoding='utf-8') as f:
    contenu = f.read()

# Ajouter UNIQUEMENT ce qui est nécessaire
contenu = contenu.replace('pattern_exact', 'pattern_exact + ajout')

# Sauvegarder
with open('/mnt/user-data/outputs/Fichier.jsx', 'w', encoding='utf-8') as f:
    f.write(contenu)
```

---

### 2. NE JAMAIS OUBLIER LES PROPS DANS App.jsx

**ERREUR FAITE :** J'ai créé le module Factures mais **oublié de passer `factures` en props** à FicheMateriel et Statistiques dans App.jsx.

**RÈGLE :**
Quand on ajoute un nouvel état dans App.jsx, **TOUJOURS vérifier** qu'il est passé en props aux composants qui en ont besoin.

**CHECKLIST OBLIGATOIRE :**
- [ ] État créé dans App.jsx ? → `const [factures, setFactures] = useState([])`
- [ ] Firebase listener ajouté ? → `onValue(facturesRef, ...)`
- [ ] Props passées à **FicheMateriel** ? → `factures={factures}`
- [ ] Props passées à **Statistiques** ? → `factures={factures}`
- [ ] Props déclarées dans les composants ? → `({ ..., factures })`

---

### 3. NE JAMAIS AJOUTER DE CONSOLE.LOG SANS DEMANDER

**ERREUR FAITE :** J'ai ajouté des `console.log()` partout pour débugger sans demander, ce qui a pollué le code.

**RÈGLE :**
- ❌ **PAS de console.log dans le code final**
- ✅ **SI DEBUG NÉCESSAIRE :** Créer une version temporaire avec un encadré visuel dans l'interface
- ✅ **TOUJOURS créer 2 versions :** une avec debug, une propre
- ✅ **DEMANDER avant** d'ajouter du debug

**EXEMPLE DEBUG PROPRE :**
```jsx
{/* DEBUG TEMPORAIRE - À ENLEVER */}
<div className="bg-yellow-100 border-2 border-yellow-500 p-3 rounded mb-3">
  <strong>DEBUG:</strong><br/>
  • Variable X: {variableX}<br/>
  • Variable Y: {variableY}
</div>
```

---

### 4. NE JAMAIS SUPPOSER - TOUJOURS VÉRIFIER

**ERREUR FAITE :** J'ai supposé qu'il y avait 6 équipements (au lieu de 25), que l'ID était 6 (au lieu de 18), etc.

**RÈGLE :**
- ❌ **JAMAIS supposer** le nombre d'éléments, les IDs, les structures
- ✅ **TOUJOURS regarder** dans les fichiers projet ou demander à Jerome
- ✅ **TOUJOURS vérifier** dans Firebase ce qui existe réellement
- ✅ **DEMANDER** plutôt que d'inventer

**EXEMPLES :**
- "Combien d'équipements as-tu ?" → Réponse : 25 (pas 6)
- "Quel est l'ID de ton MERLO ?" → Réponse : 18
- "Quelle est l'immatriculation ?" → Réponse : "multifarmer"

---

### 5. NE JAMAIS MODIFIER PLUSIEURS FICHIERS SANS PLAN

**ERREUR FAITE :** J'ai modifié App.jsx 3 fois, FicheMateriel.jsx 5 fois, en allant dans tous les sens.

**RÈGLE :**
1. ✅ **ANALYSER** ce qui est nécessaire
2. ✅ **LISTER** les fichiers à modifier
3. ✅ **MODIFIER** un par un, dans l'ordre logique
4. ✅ **TESTER** après chaque modification
5. ✅ **VALIDER** avec Jerome avant de continuer

**ORDRE LOGIQUE :**
```
1. App.jsx (état + Firebase + props)
2. Composant principal (ex: Factures.jsx)
3. Composants liés (FicheMateriel.jsx, Statistiques.jsx)
4. Test complet
```

---

## ✅ BONNES PRATIQUES À TOUJOURS SUIVRE

### 1. WORKFLOW CORRECT POUR AJOUTER UNE FONCTIONNALITÉ

```
ÉTAPE 1 : COMPRENDRE
├─ Demander à Jerome ce qu'il veut exactement
├─ Vérifier les fichiers existants
└─ Vérifier Firebase

ÉTAPE 2 : PLANIFIER
├─ Lister les fichiers à modifier
├─ Identifier ce qui existe déjà
└─ Définir ce qui doit être ajouté

ÉTAPE 3 : CODER
├─ Partir des fichiers ORIGINAUX uploadés
├─ Ajouter UNIQUEMENT ce qui est nécessaire
├─ NE PAS toucher ce qui marche
└─ Utiliser Python avec UTF-8

ÉTAPE 4 : TESTER
├─ Vérifier que ça compile
├─ Vérifier Firebase
├─ Vérifier l'affichage
└─ Demander validation à Jerome

ÉTAPE 5 : NETTOYER
├─ Enlever le debug temporaire
├─ Créer les fichiers finaux propres
└─ Documenter ce qui a été fait
```

---

### 2. CHECKLIST FIREBASE

Quand on ajoute une nouvelle collection Firebase :

- [ ] **État créé** dans App.jsx : `const [items, setItems] = useState([])`
- [ ] **Listener ajouté** : `onValue(ref(database, 'items'), ...)`
- [ ] **Conversion objet → array** si nécessaire : `Object.values(data)`
- [ ] **Initialisation** du nœud si vide : `if (!snapshot.exists()) { set(..., {}) }`
- [ ] **updateItems** nettoie les `undefined` : fonction `nettoyerObjet()`
- [ ] **Props passées** aux composants enfants
- [ ] **Test** : Créer 1 élément et vérifier qu'il apparaît

---

### 3. STRUCTURE FIREBASE POUR FACTURES

```javascript
factures: {
  "1733432123456": {
    id: 1733432123456,
    numero: "FAC-2025-001",
    fournisseur: "GARAGE DURAND",
    typeFrais: "🔧 Garage",
    date: "2025-12-05",
    lignes: [  // ARRAY (pas objet !)
      {
        id: 1,
        equipementId: "18",  // STRING ou NUMBER
        description: "Vidange",
        quantite: 1,
        prixUnitaire: 150.00,
        total: 150.00
      }
    ],
    totalHT: 150.00,
    scanUrl: "data:application/pdf...",  // Optionnel
    scanNom: "facture.pdf",              // Optionnel
    operateur: "Jerome",
    notes: ""
  }
}
```

**IMPORTANT :**
- `lignes` doit être un **ARRAY**, pas un objet
- `equipementId` peut être STRING ou NUMBER → **toujours comparer en STRING**
- `scanUrl` et `scanNom` sont **optionnels** → nettoyer les `undefined`

---

### 4. COMPARAISON equipementId

**PROBLÈME :** Firebase stocke parfois en STRING `"18"`, parfois en NUMBER `18`.

**SOLUTION :**
```javascript
// Toujours comparer en STRING
const eqId = String(ligne.equipementId);
const selId = String(equipSelectionne.id);
return eqId === selId;
```

---

### 5. FICHIERS DE RÉFÉRENCE

**TOUJOURS utiliser les fichiers ORIGINAUX uploadés par Jerome :**

| Fichier | Source originale |
|---------|------------------|
| FicheMateriel.jsx | `/mnt/user-data/uploads/FicheMateriel_2.jsx` |
| Statistiques.jsx | `/mnt/user-data/uploads/Statistiques_2.jsx` |
| App.jsx | Version la plus récente dans `/mnt/project/` |

**NE JAMAIS partir** d'une version modifiée par moi sans vérifier avec Jerome.

---

## 🎯 RÉSUMÉ DES RÈGLES D'OR

1. **PARTIR DES FICHIERS ORIGINAUX** uploadés par Jerome
2. **AJOUTER uniquement**, JAMAIS supprimer/modifier ce qui marche
3. **NE PAS toucher aux icônes** existantes
4. **TOUJOURS passer les props** dans App.jsx
5. **NE PAS supposer**, TOUJOURS vérifier ou demander
6. **PLAN CLAIR** avant de coder : quels fichiers, quoi ajouter
7. **TESTER** après chaque modification
8. **PAS de console.log** dans le code final
9. **COMPARER equipementId en STRING** toujours
10. **NETTOYER les undefined** avant Firebase

---

## 📝 CE QUI A MARCHÉ POUR MODULE FACTURES V3.5

### Fichiers modifiés (ordre correct)

1. **App.jsx** (3 modifications)
   - Ajout état `factures`
   - Ajout listener Firebase + initialisation
   - Ajout props `factures` à FicheMateriel et Statistiques
   - Fonction `nettoyerObjet()` dans `updateFactures`

2. **Factures.jsx** (nouveau module)
   - Création complète du module
   - CRUD complet
   - Multi-lignes dynamiques
   - Upload scan

3. **FicheMateriel.jsx** (ajout section factures)
   - Ajout props `factures` (ligne 11)
   - Ajout calculs (lignes 138-150)
   - Ajout section HTML (après ARTICLES, avant ACCESSOIRES)

4. **Statistiques.jsx** (ajout carte factures)
   - Ajout props `factures` (ligne 10)
   - Ajout calculs `eqFactures` et `eqTotalFactures`
   - Ajout carte "FACTURES & FRAIS" dans la grille

### Ce qui a causé les problèmes

- ❌ Modifier les icônes sans faire attention
- ❌ Oublier de passer `factures` en props
- ❌ Supposer le nombre d'équipements et les IDs
- ❌ Ajouter du debug sans demander
- ❌ Modifier plusieurs fois les mêmes fichiers

### Solution qui a marché

- ✅ Partir des fichiers ORIGINAUX uploadés
- ✅ Ajouter UNIQUEMENT ce qui est nécessaire
- ✅ Tester avec encadré DEBUG visible dans l'interface
- ✅ Enlever le debug après validation
- ✅ Vérifier CHAQUE modification avec Jerome

---

## 🚀 POUR LES PROCHAINS MODULES

**TOUJOURS suivre cette méthode :**

1. Jerome demande une fonctionnalité
2. Je demande les détails précis (pas de suppositions)
3. Je vérifie les fichiers existants
4. Je propose un PLAN clair : "Je vais modifier X, Y, Z pour ajouter A, B, C"
5. Jerome valide le plan
6. Je pars des fichiers ORIGINAUX
7. Je modifie fichier par fichier
8. Je teste après chaque modification
9. Je valide avec Jerome
10. Je nettoie et je documente

**SI JEROME S'ÉNERVE :**
- ✅ **ARRÊTER** immédiatement
- ✅ **DEMANDER** quel est le problème exact
- ✅ **REPARTIR** des fichiers ORIGINAUX uploadés
- ✅ **SIMPLIFIER** : une seule chose à la fois
- ❌ **NE PAS** continuer à modifier dans tous les sens

---

## 📁 FICHIERS FINAUX V3.5

**Module Factures opérationnel :**

- [App.jsx](computer:///mnt/user-data/outputs/App.jsx)
- [Factures.jsx](computer:///mnt/user-data/outputs/Factures.jsx)
- [FicheMateriel.jsx](computer:///mnt/user-data/outputs/FicheMateriel.jsx)
- [Statistiques.jsx](computer:///mnt/user-data/outputs/Statistiques.jsx)

**Tous les fichiers sont propres, testés, et opérationnels.** ✅

---

**FIN DU MÉMO**

*Ce document doit être relu AVANT chaque nouvelle session de développement.*
