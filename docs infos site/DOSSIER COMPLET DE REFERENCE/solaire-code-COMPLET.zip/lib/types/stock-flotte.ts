// Types pour le module Stock & Flotte

// ===================================
// ARTICLES STOCK
// ===================================

export interface ArticleStock {
  id: string
  code: string                    // BAC5X5, HIFSO 8055...
  description: string
  fournisseur: string             // LE BON ROULEMENT, RURAL MASTER...
  prixUnitaire: number
  stockParDepot: {
    'Atelier': number
    'Porteur 26 T': number
    'Porteur 32 T': number
    'Semi Remorque': number
  }
  stockTotal: number              // Calculé
  stockMin: number
  equipementsAffectes: string[]   // IDs équipements
  photoUrl?: string
  qrCode?: string
  actif: boolean
  createdAt: string
  updatedAt: string
}

export interface ArticleStockInput {
  code: string
  description: string
  fournisseur: string
  prixUnitaire: number
  stockParDepot?: {
    'Atelier'?: number
    'Porteur 26 T'?: number
    'Porteur 32 T'?: number
    'Semi Remorque'?: number
  }
  stockMin?: number
  equipementsAffectes?: string[]
  photoUrl?: string
  actif?: boolean
}

// ===================================
// MOUVEMENTS STOCK
// ===================================

export type TypeMouvement = 'entree' | 'sortie' | 'transfert' | 'ajustement'

export interface MouvementStock {
  id: string
  articleId: string
  articleCode: string
  articleDescription: string
  type: TypeMouvement
  quantite: number
  date: string
  raison: string
  coutUnitaire: number
  coutTotal: number
  depotSource?: string            // Pour sortie/transfert
  depotDestination?: string       // Pour entrée/transfert
  operateur: string
  equipementId?: string           // Si lié à équipement
  interventionId?: string         // Si lié à intervention
  factureId?: string              // Si lié à facture fournisseur
  notes?: string
  createdAt: string
}

export interface MouvementStockInput {
  articleId: string
  type: TypeMouvement
  quantite: number
  date: string
  raison: string
  coutUnitaire?: number
  depotSource?: string
  depotDestination?: string
  operateur: string
  equipementId?: string
  interventionId?: string
  factureId?: string
  notes?: string
}

// ===================================
// ÉQUIPEMENTS (Véhicules + Accessoires)
// ===================================

export type TypeEquipement = 'vehicule' | 'machine' | 'accessoire'
export type TypeFinancement = 'Achat' | 'Location' | 'Leasing'
export type StatutEquipement = 'actif' | 'maintenance' | 'hors_service'

export interface Equipement {
  id: string
  nom: string
  type: TypeEquipement
  
  // Si accessoire
  parentId?: string               // ID équipement parent
  parentNom?: string              // Nom équipement parent
  actifStructurel?: boolean       // false = carrosserie, true = brosse
  
  // Infos générales
  immatriculation?: string        // Pour véhicules
  marque: string
  modele: string
  annee: number
  
  // Compteurs
  km?: number
  heures?: number
  
  // Technique
  carburant?: string
  vin?: string
  ptac?: number
  poids?: number
  
  // Propriété
  proprietaire: string
  typeFinancement: TypeFinancement
  
  // Valeurs
  valeurAchat: number
  valeurActuelle: number
  coutMensuel?: number
  
  // Contrats
  dateDebut?: string
  dateFin?: string
  assurance?: number
  dateControleTechnique?: string
  dateVGP?: string
  
  // Statut
  statut: StatutEquipement
  
  // Divers
  notes?: string
  photoUrl?: string
  documentsUrls?: string[]
  
  createdAt: string
  updatedAt: string
}

export interface EquipementInput {
  nom: string
  type: TypeEquipement
  parentId?: string
  actifStructurel?: boolean
  immatriculation?: string
  marque: string
  modele: string
  annee: number
  km?: number
  heures?: number
  carburant?: string
  vin?: string
  ptac?: number
  poids?: number
  proprietaire: string
  typeFinancement: TypeFinancement
  valeurAchat: number
  valeurActuelle: number
  coutMensuel?: number
  dateDebut?: string
  dateFin?: string
  assurance?: number
  dateControleTechnique?: string
  dateVGP?: string
  statut?: StatutEquipement
  notes?: string
  photoUrl?: string
}

// ===================================
// INTERVENTIONS MAINTENANCE
// ===================================

export type TypeIntervention = 'entretien' | 'reparation' | 'diagnostic' | 'autre'
export type StatutIntervention = 'planifiee' | 'en_cours' | 'terminee' | 'annulee'

export interface ArticleUtilise {
  articleId: string
  code: string
  description: string
  quantite: number
  prixUnitaire: number
  coutTotal: number
  depotPrelevement: string
}

export interface InterventionMaintenance {
  id: string
  equipementId: string
  equipementNom: string
  type: TypeIntervention
  date: string
  km?: number
  heures?: number
  description: string
  travauxEffectues?: string
  articlesUtilises: ArticleUtilise[]
  coutPieces: number              // Calculé
  coutMainOeuvre: number
  coutTotal: number               // Calculé
  operateur: string
  statut: StatutIntervention
  notes?: string
  photosUrls?: string[]
  createdAt: string
  updatedAt: string
}

export interface InterventionMaintenanceInput {
  equipementId: string
  type: TypeIntervention
  date: string
  km?: number
  heures?: number
  description: string
  travauxEffectues?: string
  articlesUtilises?: ArticleUtilise[]
  coutMainOeuvre?: number
  operateur: string
  statut?: StatutIntervention
  notes?: string
}

// ===================================
// FACTURES FOURNISSEURS
// ===================================

export type StatutFactureFournisseur = 'en_attente' | 'payee'

export interface LigneFactureFournisseur {
  articleId: string
  code: string
  description: string
  quantite: number
  prixUnitaire: number
  tauxTVA: number
  totalHT: number
  totalTVA: number
  totalTTC: number
  depotDestination: string
}

export interface FactureFournisseur {
  id: string
  numero: string
  fournisseur: string
  date: string
  dateEcheance: string
  lignes: LigneFactureFournisseur[]
  totalHT: number
  totalTVA: number
  totalTTC: number
  statut: StatutFactureFournisseur
  datePaiement?: string
  moyenPaiement?: string
  referencePaiement?: string
  documentUrl?: string            // PDF facture
  mouvementsStockIds: string[]    // IDs mouvements créés
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface FactureFournisseurInput {
  numero: string
  fournisseur: string
  date: string
  dateEcheance: string
  lignes: LigneFactureFournisseur[]
  documentUrl?: string
  notes?: string
}

// ===================================
// ALERTES
// ===================================

export type TypeAlerte = 'stock_bas' | 'stock_rupture' | 'vgp_expire' | 'ct_expire'
export type GraviteAlerte = 'info' | 'warning' | 'critical'

export interface Alerte {
  id: string
  type: TypeAlerte
  gravite: GraviteAlerte
  titre: string
  message: string
  articleId?: string
  equipementId?: string
  dateCreation: string
  dateResolution?: string
  resolue: boolean
  actionsPrises?: string
}

// ===================================
// STATISTIQUES
// ===================================

export interface StatistiquesStock {
  valeurTotaleStock: number
  valeurParDepot: {
    [depot: string]: number
  }
  nombreArticles: number
  nombreAlertes: number
  mouvementsMois: {
    entrees: number
    sorties: number
    transferts: number
  }
}

export interface StatistiquesFlotte {
  nombreEquipements: number
  nombreVehicules: number
  nombreAccessoires: number
  valeurTotale: number
  coutMaintenanceMois: number
  nombreInterventionsMois: number
}

// ===================================
// DÉPÔTS (constantes)
// ===================================

export const DEPOTS = [
  'Atelier',
  'Porteur 26 T',
  'Porteur 32 T',
  'Semi Remorque'
] as const

export type Depot = typeof DEPOTS[number]

// ===================================
// OPÉRATEURS (constantes)
// ===================================

export const OPERATEURS = [
  'Axel',
  'Jérôme',
  'Sébastien',
  'Joffrey',
  'Fabien',
  'Angelo'
] as const

export type Operateur = typeof OPERATEURS[number]
