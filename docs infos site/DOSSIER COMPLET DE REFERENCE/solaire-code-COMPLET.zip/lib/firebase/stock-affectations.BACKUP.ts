import { db } from './config'
import { 
  collection, 
  addDoc, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  updateDoc,
  deleteDoc
} from 'firebase/firestore'
import { createMouvementStock } from './stock-mouvements'
import { getArticleStockById } from './stock-articles'

const COLLECTION = 'affectations_articles_embarques'

export interface AffectationEquipement {
  id: string
  equipementId: string
  equipementImmat: string
  articleId: string
  articleCode: string
  articleDescription: string
  quantite: number
  dateAffectation: string
  permanent: boolean // true = affectation permanente, false = temporaire
  notes?: string
  createdAt: string
  updatedAt: string
}

export type AffectationEquipementInput = Omit<AffectationEquipement, 'id' | 'createdAt' | 'updatedAt'>

/**
 * Créer une affectation article → équipement
 * Crée automatiquement un mouvement de transfert Atelier → Équipement
 */
export async function createAffectation(data: AffectationEquipementInput): Promise<string> {
  try {
    // Vérifier que l'article existe et a du stock
    const article = await getArticleStockById(data.articleId)
    if (!article) {
      throw new Error('Article non trouvé')
    }
    
    const stockAtelier = article.stockParDepot['Atelier'] || 0
    if (stockAtelier < data.quantite) {
      throw new Error(`Stock insuffisant à l'Atelier. Disponible: ${stockAtelier}, Demandé: ${data.quantite}`)
    }
    
    const affectation = {
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    
    const docRef = await addDoc(collection(db, COLLECTION), affectation)
    
    // Créer le mouvement de stock : Transfert Atelier → Équipement
    await createMouvementStock({
      articleId: data.articleId,
      type: 'transfert',
      quantite: data.quantite,
      date: data.dateAffectation,
      raison: `Affectation ${data.permanent ? 'permanente' : 'temporaire'} à ${data.equipementImmat}`,
      depotSource: 'Atelier',
      depotDestination: data.equipementImmat,
      equipementId: data.equipementId,
      operateur: 'Système'
    })
    
    return docRef.id
  } catch (error) {
    console.error('Erreur création affectation:', error)
    throw error
  }
}

/**
 * Récupérer toutes les affectations
 */
export async function getAllAffectations(): Promise<AffectationEquipement[]> {
  try {
    const q = query(collection(db, COLLECTION), orderBy('dateAffectation', 'desc'))
    const snapshot = await getDocs(q)
    
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as AffectationEquipement[]
  } catch (error) {
    console.error('Erreur récupération affectations:', error)
    return []
  }
}

/**
 * Récupérer les affectations d'un équipement
 */
export async function getAffectationsByEquipement(equipementId: string): Promise<AffectationEquipement[]> {
  try {
    const q = query(
      collection(db, COLLECTION),
      where('equipementId', '==', equipementId),
      orderBy('dateAffectation', 'desc')
    )
    const snapshot = await getDocs(q)
    
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as AffectationEquipement[]
  } catch (error) {
    console.error('Erreur récupération affectations équipement:', error)
    return []
  }
}

/**
 * Récupérer les affectations d'un article
 */
export async function getAffectationsByArticle(articleId: string): Promise<AffectationEquipement[]> {
  try {
    const q = query(
      collection(db, COLLECTION),
      where('articleId', '==', articleId),
      orderBy('dateAffectation', 'desc')
    )
    const snapshot = await getDocs(q)
    
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as AffectationEquipement[]
  } catch (error) {
    console.error('Erreur récupération affectations article:', error)
    return []
  }
}

/**
 * Récupérer une affectation par ID
 */
export async function getAffectationById(id: string): Promise<AffectationEquipement | null> {
  try {
    const affectationRef = doc(db, COLLECTION, id)
    const affectationSnap = await getDoc(affectationRef)
    
    if (!affectationSnap.exists()) {
      return null
    }
    
    return {
      id: affectationSnap.id,
      ...affectationSnap.data()
    } as AffectationEquipement
  } catch (error) {
    console.error('Erreur récupération affectation:', error)
    throw error
  }
}

/**
 * Mettre à jour une affectation
 * Si la quantité change, crée un mouvement de stock pour ajuster
 */
export async function updateAffectation(
  id: string,
  data: Partial<AffectationEquipementInput>
): Promise<void> {
  try {
    // Récupérer l'affectation actuelle
    const affectationActuelle = await getAffectationById(id)
    if (!affectationActuelle) {
      throw new Error('Affectation non trouvée')
    }
    
    // Si changement de quantité, créer mouvement d'ajustement
    if (data.quantite !== undefined && data.quantite !== affectationActuelle.quantite) {
      const difference = data.quantite - affectationActuelle.quantite
      
      if (difference > 0) {
        // Augmentation : Transférer depuis Atelier
        const article = await getArticleStockById(affectationActuelle.articleId)
        if (!article) {
          throw new Error('Article non trouvé')
        }
        
        const stockAtelier = article.stockParDepot['Atelier'] || 0
        if (stockAtelier < difference) {
          throw new Error(`Stock insuffisant à l'Atelier. Disponible: ${stockAtelier}, Demandé: ${difference}`)
        }
        
        await createMouvementStock({
          articleId: affectationActuelle.articleId,
          type: 'transfert',
          quantite: difference,
          date: new Date().toISOString(),
          raison: `Ajustement affectation ${affectationActuelle.equipementImmat} (${affectationActuelle.quantite} → ${data.quantite})`,
          depotSource: 'Atelier',
          depotDestination: affectationActuelle.equipementImmat,
          equipementId: affectationActuelle.equipementId,
          operateur: 'Système'
        })
      } else if (difference < 0) {
        // Diminution : Retourner à l'Atelier
        await createMouvementStock({
          articleId: affectationActuelle.articleId,
          type: 'transfert',
          quantite: Math.abs(difference),
          date: new Date().toISOString(),
          raison: `Ajustement affectation ${affectationActuelle.equipementImmat} (${affectationActuelle.quantite} → ${data.quantite})`,
          depotSource: affectationActuelle.equipementImmat,
          depotDestination: 'Atelier',
          equipementId: affectationActuelle.equipementId,
          operateur: 'Système'
        })
      }
    }
    
    const affectationRef = doc(db, COLLECTION, id)
    await updateDoc(affectationRef, {
      ...data,
      updatedAt: new Date().toISOString()
    })
  } catch (error) {
    console.error('Erreur mise à jour affectation:', error)
    throw error
  }
}

/**
 * Supprimer une affectation
 * Restitue automatiquement le stock à l'Atelier
 */
export async function deleteAffectation(id: string): Promise<void> {
  try {
    // Récupérer l'affectation avant suppression
    const affectation = await getAffectationById(id)
    if (!affectation) {
      throw new Error('Affectation non trouvée')
    }
    
    // Créer mouvement de retour vers l'Atelier
    await createMouvementStock({
      articleId: affectation.articleId,
      type: 'transfert',
      quantite: affectation.quantite,
      date: new Date().toISOString(),
      raison: `Suppression affectation ${affectation.equipementImmat}`,
      depotSource: affectation.equipementImmat,
      depotDestination: 'Atelier',
      equipementId: affectation.equipementId,
      operateur: 'Système'
    })
    
    await deleteDoc(doc(db, COLLECTION, id))
  } catch (error) {
    console.error('Erreur suppression affectation:', error)
    throw error
  }
}

/**
 * Récupérer le stock total embarqué d'un article (sur tous les véhicules)
 */
export async function getStockEmbarqueArticle(articleId: string): Promise<number> {
  try {
    const affectations = await getAffectationsByArticle(articleId)
    return affectations.reduce((total, aff) => total + aff.quantite, 0)
  } catch (error) {
    console.error('Erreur calcul stock embarqué:', error)
    return 0
  }
}

/**
 * Vérifier si un article est déjà affecté à un équipement
 */
export async function articleDejaAffecte(
  articleId: string,
  equipementId: string
): Promise<AffectationEquipement | null> {
  try {
    const affectations = await getAffectationsByEquipement(equipementId)
    return affectations.find(aff => aff.articleId === articleId) || null
  } catch (error) {
    console.error('Erreur vérification affectation:', error)
    return null
  }
}
